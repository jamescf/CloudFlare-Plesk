<html>
<head>
<script type="text/javascript">
<!--
window.location = "http://www.cloudflare.com/"
//-->
</script>
</head>
</html>