<?php

error_reporting(E_ERROR | E_WARNING | E_PARSE);

session_start(); // Session for the win?

if ($_REQUEST["logout"] == 1) {
    $_SESSION = array();
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
                  $params["path"], $params["domain"],
                  $params["secure"], $params["httponly"]
                  );
    }
    
    session_destroy();
    $uri = explode("?", $_SERVER["REQUEST_URI"], 2);
    ?><script>window.location = "<?= $uri[0] ?>"</script><?php
    exit(0);
}

require_once("myconfig.php");
if (is_file("cflicense.php")) {
    require_once("cflicense.php");
}

$_SESSION["domain_name"]      = CF_DOMAIN_NAME;
if (defined("CF_CUSTOMER_DOMAIN_KEY")) {
    // Guessing this is now a paid customer.
    $_SESSION["CF_CUSTOMER_DOMAIN_KEY"] = CF_CUSTOMER_DOMAIN_KEY;
}
?>

<!DOCTYPE html>
<html lang="en-US">
    <head>
        <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
        <meta http-equiv="Content-Language" content="en-us" />
        <![endif]-->
        <meta charset="UTF-8">
                
        <title>Performance, Security &amp; Apps for Any Website | CloudFlare | Sign up</title>

        <link rel="stylesheet" media="screen" href="../static/css/thirdparty.css"/>
        <link rel="stylesheet" media="screen" href="../static/css/cloudflare.core.css"/>
        <link rel="stylesheet" media="screen" href="../static/css/cloudflare.content.css"/>
        <link rel="stylesheet" media="screen" href="../static/css/cloudflare.validation.css"/>
        <link rel="stylesheet" media="screen" href="../static/css/cloudflare.component.css"/>
        <link rel="stylesheet" media="screen" href="../static/css/sign-up.css"/>
        <link rel="stylesheet" media="screen" href="../static/css/lightbox.css"/>
        <link rel="stylesheet" media="screen" href="../static/css/lightbox-ui.css"/>
        <link rel="stylesheet" href="../static/css/cloudflare_plesk.css" type="text/css" media="screen" title="no title" charset="utf-8">


<!-- Individual YUI CSS files --> 
<link rel="stylesheet" type="text/css" href="https://ajax.googleapis.com/ajax/libs/yui/2.9.0/build/container/assets/skins/sam/container.css"> 

<!-- Individual JS files --> 
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/yui/2.9.0/build/yahoo/yahoo-min.js"></script> 
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/yui/2.9.0/build/yahoo-dom-event/yahoo-dom-event.js"></script> 
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/yui/2.9.0/build/container/container-min.js"></script> 
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/yui/2.9.0/build/datasource/datasource-min.js"></script> 

<!-- Local Code --> 
<script src="../static/scripts/plesk.js"></script>
<script src="../static/scripts/dn.js"></script>
<script src="../static/scripts/lightbox.js"></script>

    </head>
    <body>
        <div id="SiteContainer" class="structural">

            <div class="background"></div> <!-- .background -->
            <div class="inner">
                <div id="SuperHeader" class="structural fixedWidth">
                    <div class="inner"></div> <!-- .inner -->
                </div> <!-- #SuperHeader.structural.fixedWidth -->
                <div id="Header" class="structural fixedWidth">
                    <div class="inner">

                        <div id="Logo" tooltip="CloudFlare is an awesome service for your website!">
                            <a href="https://www.cloudflare.com/" target="_self"><h1 class="ui-helper-hidden-accessible">CloudFlare</h1></a>
                        </div> <!-- #Logo -->
                   
                    </div> <!-- .inner -->
                </div> <!-- #Header.structural.fixedWidth -->
                <div id="BodyContent" class="structural fixedWidth clear standard plesk">

                    <div class="background">
                        <div class="middle"></div> <!-- .middle -->
                        <div class="top"></div> <!-- .top -->
                        <div class="bottom"></div> <!-- .bottom -->
                    </div> <!-- .background -->
                    <div class="inner">
                        <div class="section">
                            <br />
                            <div class="article">

<?php if (!$_SESSION["user_key"]) { ?>

<h2>Login to your CloudFlare account</h2>
<div class="highlight">
<table cellspacing="0" cellpadding="3" style="margin-bottom: 5px">

<tr>
          <td class="col1">Your Email: </td>
		  <td class="col2"><input class="input_text" type="text" id="USER_email" value="" /></td>

		  <td><div id="USER_email_error"></div></td>
	</tr>
	<tr id="cf_pass">
          <td class="col1">Password: </td>
          <td class="col2"><input class="input_text" type="password" id="USER_pass"></td>
    </tr>

<tr>
<td></td>
<td><span class="help forgot-password"><a href="https://www.cloudflare.com/forgot-password">I forgot my password</a></span></td>
</tr>

	<tr>
		<td class="col1"></td>
		<td colspan="2">        
            <div id="add_USER_record_button"><input type="submit" class="input-button" value="Login Now!" id="USER_submit" /></div>

            <span id="add_USER_record_status"></span>
        </td>
	</tr>
</table>

<div id="add_USER_status_bar" style="margin:0 -5px" class="cjt_status_bar"></div>
</div>
</div>

      <?php } else {  ?>

<?php

$have_cf = $_COOKIE["CF_HAVE_CF_PSA"];
if (!$have_cf) foreach ($_SESSION["recs"] as $rec) {
    if ($rec["on_cf"]) {
        $have_cf = TRUE;
        setcookie("CF_HAVE_CF_PSA", 1, time()+ 7776000, "/", URLHost);
        break;
    }
}

?>

      <?php if ($have_cf) { ?>

<!--<p class="cf_description">
Now that CloudFlare is activated, you can see quick statistics for your website and manage the basic CloudFlare settings right here from your control panel. Statistics take 24 hours to first appear and subsequently update once per day.  
</p>
-->
<p class="cf_description">
To access all of your reports and CloudFlare settings, log in to your <a href="https://www.cloudflare.com/login.html" target="_blank">CloudFlare.com</a> account.
</p>
<p class="cf_description">
Remember: You can activate and deactivate CloudFlare for each website by toggling between the orange and grey cloud.
</p>

    <?php if ((!$_COOKIE["CF_PSA_LIC"]) && (!$_SESSION["cf_zone"][0]["sub_status"] == "V")) { ?>

<p class="cf_description" id="cf_def_show_lic">
Purchased a CloudFlare license<image src="../static/images/Info_16x16.png" width="13" height="13" class="info-icon" onclick="showHelp('pro')"> from your hosting provider? <a href="javascript:void(0);" onclick="return handleShowLic(true);">Click to enable</a>.
</p>
<p id="cf_def_noshow_lic">
    Enter you CloudFlare license here: <input class="zone_lic" type="text" id="ZONE_lic" value="<?= CF_CUSTOMER_DOMAIN_KEY ?>" />
    <input type="submit" class="input-button" value="Submit Licence" id="ZONE_lic_submit" />
</p>

      <?php }  ?>

      <?php } else {  ?>
<h2>Enable CloudFlare</h2>
<p class="cf_description">
Choose which website you want to activate by clicking on the cloud. We will activate CloudFlare for the subdomain 'www' and you can choose the additional subdomains to activate. Note: Only CNAME records will show up in the record list below.
</p><p class="cf_description">
CloudFlare works differently than other site acceleration services (i.e. CDNs). You do not need to make any changes to your code. Instead, you choose which subdomains you want to be accelerated and protected by CloudFlare. Subdomains are designed as "on" or "off" CloudFlare by using an orange and gray cloud. 
</p>
<p class="cf_description" id="cf_def_show">
Have SSL on your website? You have two options. <a href="javascript:void(0);" onclick="return handleLearnMore(true);">Read more ...</a>
</p>
<p id="cf_def_noshow">
If you have SSL on your website, you have two options. If your SSL is on a separate subdomain, mark the subdomain by a gray cloud. Otherwise, you will have to upgrade to CloudFlare’s paid Pro service to ensure your site’s SSL continues to function as expected. You can learn more <a href="http://www.cloudflare.com/wiki/How_do_I_add_SSL_support_for_a_domain%3F" target="_blank">here</a>.
<br />
<a href="javascript:void(0);" onclick="return handleLearnMore(false);">[hide]</a>
</p>

<?php } ?>

<div id="user_records_div">
<?php if ($have_cf) {  ?>
	<h3>Your DNS Records | <a href="javascript:void(0);" onclick="return get_stats(false);">Analytics and Settings</a> | <a href="?logout=1">Log Out</a></h3>
<?php } else {  ?>
    <h3>Your DNS Records | <a href="?logout=1">Log Out</a></h3>
<?php }  ?>
   <table width="1000" class="DNSEditor DNSEditor-review" id="websiteSettings-DNSEditor" align="bottom">
        <thead>
        <tr align="left">
<th><strong>Type</strong></th>
<th width="200"><strong>Name</strong></th>
<th width="400"><strong>Record</strong></th>
<th><strong>CloudFlare Status</strong></th>
        </tr>
        </thead>
        <tbody>
		<?php foreach($_SESSION["recs"] as $rec): ?>
		<tr class="DNSEditor-textRow">
			<td valign="bottom"><?= $rec["type"] ?></td>
			<td valign="bottom" class="DNSEditor-column-recordName"><strong><?= $rec["name"] ?></strong></td>
            <td valign="bottom"><?= $rec["content"] ?></td>
<?php if ($rec["on_cf"]): ?>
				
				<td align="center" id="<?= $rec["name"] ?>" class="cloudflare_status cloudflare_enabled" title="Enabled"><img data-name='<?= $rec["name"] ?>' src="../static/images/solo_cloud-55x25.png" onclick="return zone_change_status('<?= $rec["name"] ?>', '<?= $rec["content"] ?>')" /></td>
			
<?php else: ?>

				<td align="center" id="<?= $rec["name"] ?>" class="cloudflare_status cloudflare_disabled" title="Disabled"><img data-name='<?= $rec["name"] ?>' src="../static/images/solo_cloud_off-55x25.png" onclick="return zone_change_status('<?= $rec["name"] ?>', '<?= $rec["content"] ?>')" /></td>

<?php endif; ?>

		</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<div id="records_legend">
		<h5>Legend</h5>
		<table>
			<tr>
				<td><img src="../static/images/solo_cloud-55x25.png" width="33" height="15" /></td>
				<td>CloudFlare enabled</td>
			</tr>
			<tr>
				<td><img src="../static/images/solo_cloud_off-55x25.png" width="33" height="15" /></td>
				<td>CloudFlare NOT enabled</td>
			</tr>
		</table>
	</div>
</div>


<div id="help_div"></div>

</div><!-- end add_record_and_zone_table -->


<script type="text/javascript">
RECS = <?= json_encode($zone_info["recs"]) ?>
</script>

      <?php }  ?>

<script type="text/javascript">
//<![CDATA[

var CPANEL_CONTROLLED_DOMAINS =  <?= json_encode(array(CF_DOMAIN_NAME)) ?>;
var CF_AVAILABLE_RECS = <?= json_encode($_SESSION["recs"]) ?>;
var DOM_ID = <?= json_encode(CF_DOMAIN_ID) ?>;
var USER_API_KEY = <?= json_encode($_SESSION["user"]["user_api_key"]) ?>;
var USER_KEY = <?= json_encode($_SESSION["user_key"]) ?>;
var USER_EMAIL = <?= json_encode($_SESSION["user"]["cloudflare_email"]) ?>;
var USER_NAME = <?= json_encode(CF_USER) ?>;
var CF_ON_CLOUD_MESSAGE = "";
var CURRENT_ZONE_NAME = <?= json_encode(CF_DOMAIN_NAME) ?>;
var CF_USER_API_ENDPOINT = <?= json_encode(CF_USER_API_ENDPOINT) ?>;
var CF_NEED_UPDATE = <?= ($_SESSION["need_update"] === TRUE)? 1: 0; ?>;

//]]>
</script>



                            </div> <!-- .article -->
                        </div> <!-- .section -->


                    <div class="clear"></div> <!-- .clear -->
                    </div> <!-- .inner -->
                </div> <!-- #BodyContent.structural.fixedWidth.standard -->
                <div id="Footer" class="structural fixedWidth standard">
                    <div class="inner">
                        <div class="section">
                            <div id="PublicFooter" class="structural fixedWidth standard">

                            <div id="PublicFooter-upperright"><div id="smt-lang-selector"></div></div>
                            <div id="PublicFooter-lowerright">
                                <a id="TwitterLink" href="http://twitter.com/cloudflare" target="_blank"><div class="cf-icon service twitter"></div></a>
                                <a id="FacebookLink" href="http://www.facebook.com/CloudFlare?ref=ts" target="_blank"><div class="cf-icon service facebook"></div></a>
                                <div id="PublicFooter-copyright"><span>&copy; CloudFlare, Inc.</span></div>
                            </div>
                            <div id="PublicFooter-navigation">
                                <div class="PublicFooter-navigation-group">

                                    <h5>Using CloudFlare</h5>
                                    <ul>
                                        <li><a href="https://www.cloudflare.com/overview.html">Overview</a></li>
                                        <li><a href="https://www.cloudflare.com/plans.html">Features &amp; pricing</a></li>
                                        <li><a href="https://www.cloudflare.com/apps/">Apps</a></li>
                                        <li><a href="https://www.cloudflare.com/tour.html">Tour</a></li>
                                        <li><a href="https://www.cloudflare.com/sign-up.html">Sign up</a></li>
                                    </ul>
                                </div>
                                <div class="PublicFooter-navigation-group">
                                    <h5>Community</h5>
                                    <ul>
                                        <li><a href="https://www.cloudflare.com/testimonials.html">Testimonials</a></li>
                                        <li><a href="http://blog.cloudflare.com">CloudFlare blog</a></li>
                                        <li><a href="http://twitter.com/cloudflare" target="_blank">Twitter</a></li>
                                        <li><a href="http://www.facebook.com/CloudFlare?ref=ts" target="_blank">Facebook</a></li>
                                        <li><a href="https://www.cloudflare.com/web-badges.html">Web Badges</a></li>
                                    </ul>
                                </div>
                                <div class="PublicFooter-navigation-group">

                                    <h5>Support</h5>
                                    <ul>
                                        <li><a href="https://www.cloudflare.com/help.html">Help center</a></li>
                                        <li><a href="https://www.cloudflare.com/system-status.html">System status</a></li>
                                        <li><a href="https://www.cloudflare.com/hosting-partners.html">Hosting partners</a></li>
                                        <li><a href="http://support.cloudflare.com/cgi/discussion/new">Contact us</a></li>

                                    </ul>
                                </div>
                                <div class="PublicFooter-navigation-group">
                                    <h5>About us</h5>
                                    <ul>
                                        <li><a href="https://www.cloudflare.com/people.html">Our team</a></li>
                                        <li><a href="https://www.cloudflare.com/press.html">Press center</a></li>

                                        <li><a href="https://www.cloudflare.com/terms.html">Terms of service</a></li>
                                        <li><a href="https://www.cloudflare.com/security-policy.html">Privacy &amp; security</a></li>
                                        <li><a href="https://www.cloudflare.com/careers.html">Careers</a></li>
                                    </ul>
                                </div>
                            </div>

                            <div class="clear"></div>
                        </div> <!-- #PublicFooter.structural.fixedWidth.standard -->
                        </div> <!-- .section -->
                    </div> <!-- .inner -->
                </div> <!-- #Footer.structural.fixedWidth.standard -->
                <div id="SubFooter" class="structural fixedWidth">
                </div> <!-- #SubFooter.structural.fixedWidth -->

            </div> <!-- .inner -->
        </div> <!-- #SiteContainer.structural -->
        <div id="FixedContent" class="structural">
            <ul id="Notifications"></ul> <!-- #Notifications -->
            <ul id="GlobalTabs">
            </ul> <!-- #GlobalTabs -->
        </div> <!-- #FixedContent.structural -->

        <div id="HiddenContent" class="ui-helper-hidden ui-helper-hidden-accessible">
        </div> <!-- #HiddenContent -->

        <script type="text/javascript" src="../static/scripts/thirdparty.js"></script>
        <script type="text/javascript" src="../static/scripts/cloudflare.core.js"></script>
        <script type="text/javascript" src="../static/scripts/cloudflare.ui.js"></script>
        <script type="text/javascript" src="../static/scripts/cloudflare.client.js"></script>
       
    </body>
</html>
