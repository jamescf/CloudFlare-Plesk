/*******************************************************************************
 *
 * CloudFlare Core Framework Functions
 * 
 * @author Christopher Joel
 * 
 * Copyright 2010 CloudFlare, Inc.
 * 
 ******************************************************************************/
 
(function($) {
    
    $.cf = {
        
        logType: {
            
            debug: "[ D ]",
            warning: "[ W ]",
            error: "[ E ]"
            
        },
        
        log: function(message, type) {
            
            type = type ? type : $.cf.logType.debug;
            
            try {
                
                console.log(type + " " + message);
            } catch(e) {
                
                // Console.log not supported...
            }
        },
        
        noteType: {
            
            alert: 'alert',
            message: 'message',
            warning: 'warning',
            error: 'error'
            
        },
        
        notify: function(message, type, timeout) {
            
            if (!message) return;

            type = type ? type : $.cf.noteType.message;
            
            timeout = timeout ? (timeout != -1 ? timeout * 1000 : timeout) : 10000;
            
            var note = $('<li class="note ' + type + '"><h1>' + type.toUpperCase() + '</h1><p>' + message + '</p></li>');
            
            $('#Notifications').prepend(note);
            
            note.hide().slideDown(
                400,
                function() {
                    
                    if(timeout != -1) {
                        
                        setTimeout(
                            function() {
                                
                                note.slideUp(
                                    400,
                                    function() {
                                        
                                        note.remove();
                                        
                                    }
                                );
                            },
                            timeout
                        );
                    }
                }
            );
        },
        
        clearNotifications: function() {
            
            var currentNotes = $('#Notifications > .note:not(.note.dying)');
            
            currentNotes.addClass('dying');
            
            currentNotes.fadeOut(
                400,
                function() {
                    
                    currentNotes.remove();
                }
            )
        },
        
        mouseX: -1,
        mouseY: -1,
        
 /*
  * Insert an <option> list into a <select> tag
  * Clears any existing children of the <select>
  */
        buildOptions: function(selectTarget, options) {
            var $select = $(selectTarget),
                html = '', attrs,
                buildOption = function(key, label){
                    attrs = ' value="'+key+'"' + (key == options.selected ? ' selected="true" checked="true"' : '');
                    html += '<option'+attrs+'>'+label+'</option>';
                };

            $select.is(':not([multiple])') && options.placeholder && buildOption('', options.placeholder);
            options.data && $.each(options.data, buildOption);
            $select.append(html);
        },

        modalStateEnabled: false,
        loadModalDialog: function(params, options) {
            
            options = $.extend(
                {
                    title: "Untitled Dialog",
                    buttons: {
                        Okay: function() {
                            
                            $('#ModalDialog').dialog('close');
                            
                        }
                    },
                    modal: true,
                    position: 'center',
                    draggable: false,
                    resizable: false,
                    width: 500,
                    maxHeight: 600,
                    open: function(event) {
                        
                        $('.ui-dialog:has(#ModalDialog)').hide().children().wrapAll($('<div class="inner"></div>'));
                        $('.ui-widget-overlay').hide().fadeIn(600);
                        
                    },
                    beforeClose: function(event){
                        
                        var ev_self = this;

                        event.preventDefault();
                        
                        $('.ui-dialog:has(#ModalDialog)').css(
                            {
                                marginTop: '0',
                                opacity: '1'
                            }
                        ).show().animate(
                            {
                                marginTop: '-20px',
                                opacity: '0'
                            },
                            400,
                            'easeOutExpo',
                            function() {
                                
                                $('.ui-widget-overlay').fadeOut(
                                    200,
                                    function() {
                                        
                                        $.cf.modalStateEnabled = false;
                                        
                                        $('#ModalDialog').dialog('destroy').remove();
                                        $('#ModalComponent').remove();

                                        options.close && options.close.call(ev_self, event);
                                    }
                                );
                                
                            }
                        );
                    },
                    close: function(event) {
                        
                        event.preventDefault();
                        
                    },
                    contentReady: function(event) {

                    }
                },
                options
            );
            
            params = $.extend(
                {
                    type: 'default'
                },
                params
            );
            
            var notifyError = function() {
                
                $.cf.notify('There was an error launching a modal dialog. Please try again, and if the problem persists, contact <a href="mailto:support@cloudflare.com">support@cloudflare.com</a>!', $.cf.noteType.error);
                
            };
            
            // support object and array formats for options.buttons
            $.each(options.buttons, function(key, props) {
                var isFn = $.isFunction( props ),
                    callback = (isFn ? props : props.click) || $.noop,
                    clickFn = function() {

                        callback.apply(this, arguments);
                        $('#ModalComponent').triggerHandler('modalbutton', {name: isFn ? key : props.name});
                    };

                options.buttons[key] = isFn ? clickFn : {

                    text: props.text,
                    click: clickFn
                };
            });
            
            if(!$.cf.modalStateEnabled) {
                
                $.cf.modalStateEnabled = true;
                
                $.ajax(
                    {
                        url: '/ajax/modal-dialog.html',
                        dataType: 'html',
                        type: 'POST',
                        data: params,
                        error: notifyError,
                        success: function(html, status, xhr) {
                            
                            try {
                                
                                $('#HiddenContent').append(html);
                                
                                
                            } catch(e) {
                                
                                $.cf.log('There was an error creating a DOM node from the retrieved HTML!', $.cf.logType.error);
                                notifyError();
                                
                            }
                            
                            $('#ModalComponent').bind(
                                'contentready',
                                function(event) {
                                    
                                    $('#ModalDialog').dialog('option', 'position', 'center');
                                    $('.ui-dialog:has(#ModalDialog)').css(
                                        {
                                            marginTop: '40px',
                                            opacity: '0'
                                        }
                                    ).show().animate(
                                        {
                                            marginTop: '0',
                                            opacity: '1'
                                        },
                                        400,
                                        'easeOutExpo'
                                    );

                                    options.contentReady && options.contentReady(event);
                                }
                            ).bind(
                                'modalclose',
                                function(event) {
                                    
                                    $('#ModalDialog').dialog('close');
                                }
                            );
                            
                            $('#ModalDialog').dialog(options);
                            
                            $('#ModalComponent').triggerHandler('modalready');
                        }
                    }
                );
            }
        }
    };
    
    $.extend(
        $.fn,
        {  
            tooltip: function(options) {
                
                options = $.extend(
                    {
                        backgroundColor: '#3c5466',
                        textCSS: {
                            color: '#ffffff'
                        },
                        text: null,
                        offset: 10,
                        delay: 500,
                        width: null,
                        showOn: 'mouseenter',
                        hideOn: 'mouseleave',
                        forceMouse: false,
                        autoPointer: true,
                        align: 'center',
                        shadow: true,
                        attributes: [
                            'tooltip',
                            'alt',
                            'value',
                            'href',
                            'rel'
                        ],
                        customClass: null,
                        customContent: function(tip){}
                    },
                    options
                );
                
                this.each(
                    function(i, e) {
                        
                        var target = $(e),
                            tipText = options.text ? options.text : (function() {
                            
                            for(var i = 0; i < options.attributes.length; i++) {
                                
                                if(target.attr(options.attributes[i]) != undefined) {
                                    
                                    return target.attr(options.attributes[i]);
                                }
                            }
                        })();
                        
                        var tooltip,
                            left,
                            top,
                            timer,
                            custom,
                            visible = false;
                        
                        target.data(
                            'tooltip', 
                            {
                                showOn: options.showOn,
                                hideOn: options.hideOn,
                                showTip: function(event) {
                                    
                                    if(!visible) {
                                        timer = setTimeout(
                                            function() {
                                                
                                                if($.contains(document, target.get(0))) {
                                                    
                                                    tooltip = $('<div class="tooltip"></div>').appendTo('body').css(
                                                        {
                                                            width: options.width ? options.width + 'px' : null,
                                                            opacity: 0
                                                        }
                                                    ).hide();
                                                    
                                                    if(options.shadow) {
                                                        
                                                        tooltip.addClass('shadow');
                                                    }
                                                    
                                                    if(options.extraClass) {
                                                        
                                                        tooltip.addClass(options.extraClass);
                                                    }
                                                    
                                                    $('<div class="tip"><p>' + tipText + '</p></div>').appendTo(tooltip).css(
                                                        $.extend(
                                                            {
                                                                background: options.backgroundColor
                                                            },
                                                            options.textCSS
                                                        )
                                                    );
                                                    
                                                    if(options.customContent) {
                                                        
                                                        custom = $.isFunction(options.customContent) ? options.customContent(tooltip.children().first()) : options.customContent;
                                                        
                                                        if(custom instanceof jQuery) {
                                                            
                                                            custom.appendTo(tooltip.children().first());
                                                        }
                                                    }
                                                    
                                                    if(options.forceMouse) {
                                                        
                                                        left = $.cf.mouseX - tooltip.outerWidth() / 2;
                                                        top = $.cf.mouseY + options.offset;
                                                    } else {
                                                        
                                                        top = target.offset().top + (target.outerHeight() + options.offset);

                                                        switch(options.align) {
                                                            default:
                                                            case 'center':
                                                                
                                                                left = target.offset().left + (target.outerWidth() / 2 - tooltip.outerWidth() / 2);
                                                                
                                                                break;
                                                            case 'left':
                                                                
                                                                left = target.offset().left;
                                                                
                                                                break;
                                                            case 'right':
                                                                
                                                                left = target.offset().left + target.outerWidth() - tooltip.outerWidth();
                                                                
                                                                break;

                                                            case 'right-margin-top':

                                                                left = target.offset().left + target.outerWidth();
                                                                top = target.offset().top;

                                                                break;
                                                        }
                                                        
                                                    }
                                                    
                                                    
                                                    if(!$.browser.msie) {
                                                        
                                                        var pointerLeft;
                                                        
                                                        if(options.autoPointer) {
                                                            
                                                            if($.cf.mouseX && $.cf.mouseX < (left + 8)) {
                                                                
                                                                pointerLeft = 8;
                                                            } else if($.cf.mouseX > (left + tooltip.outerWidth() - 16)) {
                                                                
                                                                pointerLeft = tooltip.outerWidth() - 16;
                                                            } else if($.cf.mouseX) {
                                                                
                                                                pointerLeft = $.cf.mouseX - left - 5;
                                                            } else {
                                                                
                                                                pointerLeft = tooltip.outerWidth() / 2 - 4;
                                                            }
                                                            
                                                        } else {
                                                            
                                                            switch(options.align) {
                                                                default:
                                                                case 'center':
                                                                    
                                                                    pointerLeft = tooltip.outerWidth() / 2 - 4;
                                                                    break;
                                                                case 'left':
                                                                    
                                                                    pointerLeft = 8;
                                                                    break;
                                                                case 'right':
                                                                    
                                                                    pointerLeft = tooltip.outerWidth() - 16;
                                                                    break;
                                                            }
                                                            
                                                        }
                                                        
                                                        
                                                        $('<div class="pointer"></div>').prependTo(tooltip).css(
                                                            {
                                                                left: pointerLeft + 'px',
                                                                background: options.backgroundColor
                                                            }
                                                        );
                                                    }
                                                    
                                                    tooltip.css(
                                                        {
                                                            top: (top + 10) + 'px',
                                                            left: left + 'px'
                                                        }
                                                    ).show().animate(
                                                        {
                                                            opacity: 1,
                                                            top: top + 'px'
                                                        },
                                                        200
                                                    );
                                                    
                                                    if(custom) {
                                                        
                                                        custom.trigger('visible');
                                                    }
                                                } else {
                                                    
                                                    $.cf.log("Tooltip's designated target was not attached to the DOM! Aborting..", $.cf.logType.warning);
                                                    target.mouseleave();
                                                }
                                            },
                                            options.delay
                                        );
                                        
                                        visible = true;
                                    }
                                },
                                hideTip: function(event) {
                                    
                                    if(visible) {
                                        
                                        if(timer) {
                                            clearTimeout(timer);
                                        }
                                        
                                        if(tooltip != null) {
                                            tooltip.stop().animate(
                                                {
                                                    opacity: 0,
                                                    top: (top - 10) + 'px'
                                                },
                                                200,
                                                function() {
                                                    tooltip.remove();
                                                    tooltip = null;
                                                    
                                                    if(options.forceMouse) {
                                                        
                                                        target.clearTooltip();
                                                    }
                                                }
                                            );
                                        }
                                        
                                        visible = false;
                                    }
                                }
                            }
                        );
                        
                        if(options.forceMouse) {
                            
                            target.bind(
                                target.data('tooltip').hideOn + ' remove',
                                target.data('tooltip').hideTip
                            ).data('tooltip').showTip();
                        } else {
                        
                            target.bind(
                                target.data('tooltip').showOn,
                                target.data('tooltip').showTip
                            ).bind(
                                target.data('tooltip').hideOn + ' remove',
                                target.data('tooltip').hideTip
                            );
                        }
                    }
                )
                
                return this;
            },
            clearTooltip: function() {
                
                this.each(
                    function(i, e) {
                        
                        var target = $(e);
                        
                        if(target.data('tooltip')) {
                            
                            target.data('tooltip').hideTip();
                            
                            target.unbind(
                                target.data('tooltip').showOn,
                                target.data('tooltip').showTip
                            ).unbind(
                                target.data('tooltip').hideOn + ' remove',
                                target.data('tooltip').hideTip
                            );
                        }
                    }
                );
                
                return this;
            },
            placeholder: function() {
                
                /* DEPRECATED - FIX!
                this.each(
                    function(i, e) {
                        
                        var target = $(e);
                        
                        var targetHasValue = function() {
                            
                            return target.val() && target.val() != "";
                        }
                        
                        if(target.attr('placeholder') && target.is('input[type="text"]')) {
                            
                            var placeholderText = target.attr('placeholder');
                            var usePlaceholder = false;
                            
                            target.bind(
                                'keyup',
                                function(event) {
                                    
                                    if(targetHasValue()) {
                                        
                                        usePlaceholder = false;
                                    } else {
                                        
                                        usePlaceholder = true;
                                    }
                                }
                            ).bind(
                                'blur',
                                function(event) {
                                    
                                    $.cf.log('Should add placeholder?');
                                    if(usePlaceholder) {
                                        $.cf.log('Adding placeholder!');
                                        target.addClass('placeholder');
                                        target.val(placeholderText);
                                    }
                                }
                            ).bind(
                                'focus',
                                function(event) {
                                    
                                    if(usePlaceholder) {
                                        
                                        target.removeClass('placeholder');
                                        target.val("");
                                    }
                                }
                            );
                        }
                        
                        if(!targetHasValue()) {
                            
                            target.keyup().blur();
                        }
                    }
                );
                */
            },
            copyToClipboard: function(options) {
                
                options = $.extend(
                    {
                        caption: "Press 'control/command + c' to copy:",
                        copyTarget: null,
                        copyText: null,
                        attributes: [
                            'clipboard',
                            'alt',
                            'value',
                            'href',
                            'rel'
                        ],
                        tooltipOptions: {}
                    },
                    options
                );
                
                this.each(
                    function(i, e) {
                        
                        var target = $(this),
                            copyText = false;
                        
                        if(!options.copyText) {
                            
                            var copyTarget = options.copyTarget || target;
                            
                            $.each(
                                options.attributes,
                                function(i, a) {
                                    
                                    if(copyTarget.attr(a)) {
                                        
                                        options.copyText = copyTarget.attr(a);
                                        return false;
                                    }
                                }
                            );
                        }
                        
                        copyText = options.copyText || "Undefined";
                        
                        target.tooltip(
                            $.extend(
                                {
                                    delay: 150
                                },
                                options.tooltipOptions,
                                {
                                    text: options.caption,
                                    customContent: function() {
                                        return $('<input class="clipboard" type="text" value="' + copyText + '" />').bind(
                                            'visible',
                                            function(e) {
                                                
                                                this.select();
                                            }
                                        );
                                    }
                                }
                            )
                        );
                    }
                );
            }
        }
    );
    
    $(document).bind(
        'mousemove',
        function(event) {
            $.cf.mouseX = event.pageX;
            $.cf.mouseY = event.pageY;
        }
    );
})(jQuery);
