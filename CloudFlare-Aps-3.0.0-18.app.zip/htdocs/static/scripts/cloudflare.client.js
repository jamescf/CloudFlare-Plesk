/*******************************************************************************
 *
 * CloudFlare UI Toggle Selector
 * 
 * @author Christopher Joel
 * 
 * Copyright 2010 CloudFlare, Inc.
 * 
 ******************************************************************************/

(function($) {
    
    $.extend(
        $.cf,
        {
            clientType: {
                
                ie: "Internet Explorer",
                gecko: "Gecko",
                webkit: "Webkit",
                opera: "Opera",
                unknown: "Unknown"
                
            },
            
            resolveClient: function() {
                
                if($.browser.msie)
                    return $.cf.clientType.ie;
                
                if($.browser.mozilla)
                    return $.cf.clientType.gecko;
                
                if($.browser.webkit || $.browser.safari)
                    return $.cf.clientType.webkit;
                    
                if($.browser.opera)
                    return $.cf.clientType.opera;
                    
                return $.cf.clientType.unknown;
                
            },
            
            resolveClientUpgradeURL: function() {
                
                switch($.cf.resolveClient()) {
                    case $.cf.clientType.ie:
                        return "http://www.microsoft.com/windows/internet-explorer/default.aspx";
                    default:
                    case $.cf.clientType.mozilla:
                        return "http://www.mozilla.com/en-US/firefox/personal.html";
                    case $.cf.clientType.opera:
                        return "http://www.opera.com/browser/";
                    case $.cf.clientType.webkit:
                        return "http://www.google.com/chrome";
                }
                
            },
            
            clientStatus: {
                
                unknown: "Unknown",
                standard: "Standard",
                deprecated: "Deprecated",
                obsolete: "Obsolete"
                
            },
            
            resolveClientStatus: function() {
                
                switch($.cf.resolveClient()) {
                    
                    case $.cf.clientType.ie: {
                        
                        var version = parseInt($.browser.version.substr(0, 2));
                        
                        if(version > 7) {
                            return $.cf.clientStatus.standard;
                        } else if(version > 6) {
                            return $.cf.clientStatus.deprecated;
                        } else {
                            return $.cf.clientStatus.obsolete;
                        }
                        
                        break;
                    }
                    
                    case $.cf.clientType.gecko: {
                        
                        var major = parseInt($.browser.version.substr(0, 1));
                        var minor = parseInt($.browser.version.substr(2, 1));
                        var revision;
                        
                        try {
                            revision = parseInt($.browser.version.substr(4, 1));
                        } catch(e) {
                            revision = 0;
                        }
                        
                        if(major > 0) {
                            if(minor > 7) {
                                if(minor > 8 && revision > 0) {
                                    return $.cf.clientStatus.standard;
                                } else {
                                    return $.cf.clientStatus.deprecated;
                                }
                            } else if(major > 1) {
                                
                                return $.cf.clientStatus.standard;
                            } else {
                                return $.cf.clientStatus.obsolete;
                            }
                        } else {
                            return $.cf.clientStatus.obsolete;
                        }
                        
                        break;
                    }
                    
                    case $.cf.clientType.webkit: {
                        
                        var version = parseInt($.browser.version.substr(0, 3));
                        
                        if(version > 500)
                            return $.cf.clientStatus.standard;
                        else if(version > 400)
                            return $.cf.clientStatus.deprecated;
                        else
                            return $.cf.clientStatus.obsolete;
                        
                        break;
                    }
                    
                    case $.cf.clientType.opera: {
                        
                        var version = parseInt($.browser.version.substr(0, 2));
                        
                        if(version > 9) {
                            return $.cf.clientStatus.standard;
                        } else if(version > 8) {
                            return $.cf.clientStatus.deprecated;
                        } else {
                            return $.cf.clientStatus.obsolete;
                        }
                        
                        break;
                    }
                }
                
                return $.cf.clientStatus.unknown;
                
            },
            
            clientTier: {
                
                // Full support for modern web standards, including support for HTML5 & CSS3 (i.e. Firefox 3.5+ & Webkit.. IE9?)
                one: 1,
                // Modest support for web standards, but nothing cutting edge (i.e. IE8-ish, Firefox 3, Opera 9)
                two: 2,
                // Moderately quirky or unreliable behavior (i.e. IE7, Firefox 2, old Safari)
                three: 3,
                // Totally unreliable and thus unsupported browsers (i.e. IE6)
                four: 4,
                // If we get this, well.. who knows?
                unknown: -1
                
            },
            
            resolveClientTier: function() {
                
                var client = $.cf.resolveClient();
                var status = $.cf.resolveClientStatus();
                
                if(
                    status == $.cf.clientStatus.standard &&
                    (
                        client == $.cf.clientType.webkit || 
                        client == $.cf.clientType.gecko ||
                        client == $.cf.clientType.opera
                    )
                ) {
                    return $.cf.clientTier.one;
                }
                
                if(
                    status == $.cf.clientStatus.deprecated &&
                    (
                        client == $.cf.clientType.gecko ||
                        client == $.cf.clientType.webkit
                    ) ||
                    status == $.cf.clientStatus.standard &&
                    client == $.cf.clientType.ie
                ) {
                    return $.cf.clientTier.two;
                }
                
                if(
                    status == $.cf.clientStatus.deprecated &&
                    (
                        client == $.cf.clientType.ie ||
                        client == $.cf.clientType.opera ||
                        client == $.cf.clientType.unknown
                    ) || status == $.cf.clientStatus.obsolete &&
                    (
                        client == $.cf.clientType.gecko ||
                        client == $.cf.clientType.webkit
                    )
                ) {
                   return $.cf.clientTier.three;
                }
                
                if(
                    status == $.cf.clientStatus.obsolete
                ) {
                    return $.cf.clientTier.four;
                }
                
                return $.cf.clientTier.unknown;
                
            },
            
            clientValue: function(options) {
                
                options = $.extend(
                    {
                        key: null,
                        value: null,
                        domain: null,
                        path: '/',
                        expires: 1,
                        secure: true
                    },
                    options
                );
                
                var result = null;
                
                if(options.key != null) {
                    
                    if(options.value) {
                        
                        document.cookie = options.key + '=' + encodeURIComponent(options.value) + '; expires=' + (new Date((new Date()).getTime() + options.expires * 24 * 60 * 60 * 1000)).toUTCString() + '; path=' + options.path + (options.domain != null ? '; domain=' + options.domain : '') + (options.secure ? '; secure' : '');
                        
                    } else {
                        
                        if(document.cookie && document.cookie != '') {
                            
                            var cookies = document.cookie.split(';');
                            
                            $.each(
                                cookies,
                                function(i, c) {
                                    
                                    if($.trim(c).substr(0, options.key.length + 1) == options.key + "=") {
                                        
                                        result = decodeURIComponent($.trim(c).substr(options.key.length + 1));
                                        return false;
                                        
                                    }
                                }
                            );
                        }
                    }
                }
                
                return result;
                
            },
            
            promptChromeFrame: function() {
                        
                try {
                    
                    $.getScript(
                        'http://ajax.googleapis.com/ajax/libs/chrome-frame/1/CFInstall.min.js', 
                        function() {
                            
                            $('body').prepend('<div id="ChromeFrameInstaller"><div class="background"></div><iframe id="ChromeFrameInstallerFrame"></iframe></div>');
                            
                            $('div#ChromeFrameInstaller > div.background').css('opacity', '0.5');
                            $('html').css('overflow', 'hidden');
                            
                            CFInstall.check(
                                {
                                    node: 'ChromeFrameInstallerFrame'
                                }
                            );
                            
                            $.cf.clientValue({ key: 'ChromeFramePrompted', value: 1 });
                            
                        }
                    );
                    
                } catch(e) {
                    
                    $.cf.log("Can't load CFInstall!", $.cf.logType.error);
                    
                }
            },
            
            invalidateClient: function() {
                
                $('a.chromeFrameInstallLauncher').live(
                    'click',
                    function() {
                        
                        $.cf.clearNotifications();
                        
                        $.cf.promptChromeFrame();
                        
                    }
                );
                
                switch($.cf.resolveClientTier()) {
                    
                    case $.cf.clientTier.one: {
                        break;
                    }
                    case $.cf.clientTier.two: {
                        break;
                    }
                    case $.cf.clientTier.three: {
                        
                        if($.cf.clientValue({ key: 'ChromeFramePrompted' }) == null) {
                            
                            $.cf.notify('Your current browser may not display CloudFlare correctly. We highly recommend that you <a href="' + $.cf.resolveClientUpgradeURL() + '" target="_blank">upgrade your browser</a>' + ($.cf.resolveClient() == $.cf.clientType.ie ? ', or <a href="javascript:void(0);" class="chromeFrameInstallLauncher">install Chrome Frame</a>,' : '') + ' before continuing!', $.cf.noteType.warning, 20);
                            
                        }
                        
                        break;
                    }
                    case $.cf.clientTier.four: {
                        
                        $.cf.notify('Your current browser will not display CloudFlare correctly! Please <a href="' + $.cf.resolveClientUpgradeURL() + '" target="_blank">upgrade your browser</a>' + ($.cf.resolveClient() == $.cf.clientType.ie ? ', or <a href="javascript:void(0);" class="chromeFrameInstallLauncher">install Chrome Frame</a>,' : '') + ' before continuing!', $.cf.noteType.error, -1);
                        
                        break;
                    }
                }
            }
            
        }
    );

    (function(){

        var resolveIsMobile = function(userAgent){
            return /android|avantgo|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(userAgent) ||
                /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|e\-|e\/|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(di|rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|xda(\-|2|g)|yas\-|your|zeto|zte\-/i.test(userAgent.substr(0,4));
        };

        $.cf.isMobile = resolveIsMobile(navigator.userAgent||navigator.vendor||window.opera||"");

    })();
    
})(jQuery);
