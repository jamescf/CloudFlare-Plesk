/*******************************************************************************
 *
 * CloudFlare Core Framework Functions
 * 
 * @author Christopher Joel
 * 
 * Copyright 2010 CloudFlare, Inc.
 * 
 ******************************************************************************/
 
(function($) {
    
    $.cf = {
        
        logType: {
            
            debug: "[ D ]",
            warning: "[ W ]",
            error: "[ E ]"
            
        },
        
        log: function(message, type) {
            
            type = type ? type : $.cf.logType.debug;
            
            try {
                
                console.log(type + " " + message);
            } catch(e) {
                
                // Console.log not supported...
            }
        },
        
        noteType: {
            
            alert: 'alert',
            message: 'message',
            warning: 'warning',
            error: 'error'
            
        },
        
        notify: function(message, type, timeout) {
            
            if (!message) return;

            type = type ? type : $.cf.noteType.message;
            
            timeout = timeout ? (timeout != -1 ? timeout * 1000 : timeout) : 10000;
            
            var note = $('<li class="note ' + type + '"><h1>' + type.toUpperCase() + '</h1><p>' + message + '</p></li>');
            
            $('#Notifications').prepend(note);
            
            note.hide().slideDown(
                400,
                function() {
                    
                    if(timeout != -1) {
                        
                        setTimeout(
                            function() {
                                
                                note.slideUp(
                                    400,
                                    function() {
                                        
                                        note.remove();
                                        
                                    }
                                );
                            },
                            timeout
                        );
                    }
                }
            );
        },
        
        clearNotifications: function() {
            
            var currentNotes = $('#Notifications > .note:not(.note.dying)');
            
            currentNotes.addClass('dying');
            
            currentNotes.fadeOut(
                400,
                function() {
                    
                    currentNotes.remove();
                }
            )
        },
        
        mouseX: -1,
        mouseY: -1,
        
 /*
  * Insert an <option> list into a <select> tag
  * Clears any existing children of the <select>
  */
        buildOptions: function(selectTarget, options) {
            var $select = $(selectTarget),
                html = '', attrs,
                buildOption = function(key, label){
                    attrs = ' value="'+key+'"' + (key == options.selected ? ' selected="true" checked="true"' : '');
                    html += '<option'+attrs+'>'+label+'</option>';
                };

            $select.is(':not([multiple])') && options.placeholder && buildOption('', options.placeholder);
            options.data && $.each(options.data, buildOption);
            $select.append(html);
        },

        modalStateEnabled: false,
        loadModalDialog: function(params, options) {
            
            options = $.extend(
                {
                    title: "Untitled Dialog",
                    buttons: {
                        Okay: function() {
                            
                            $('#ModalDialog').dialog('close');
                            
                        }
                    },
                    modal: true,
                    position: 'center',
                    draggable: false,
                    resizable: false,
                    width: 500,
                    maxHeight: 600,
                    open: function(event) {
                        
                        $('.ui-dialog:has(#ModalDialog)').hide().children().wrapAll($('<div class="inner"></div>'));
                        $('.ui-widget-overlay').hide().fadeIn(600);
                        
                    },
                    beforeClose: function(event){
                        
                        var ev_self = this;

                        event.preventDefault();
                        
                        $('.ui-dialog:has(#ModalDialog)').css(
                            {
                                marginTop: '0',
                                opacity: '1'
                            }
                        ).show().animate(
                            {
                                marginTop: '-20px',
                                opacity: '0'
                            },
                            400,
                            'easeOutExpo',
                            function() {
                                
                                $('.ui-widget-overlay').fadeOut(
                                    200,
                                    function() {
                                        
                                        $.cf.modalStateEnabled = false;
                                        
                                        $('#ModalDialog').dialog('destroy').remove();
                                        $('#ModalComponent').remove();

                                        options.close && options.close.call(ev_self, event);
                                    }
                                );
                                
                            }
                        );
                    },
                    close: function(event) {
                        
                        event.preventDefault();
                        
                    },
                    contentReady: function(event) {

                    }
                },
                options
            );
            
            params = $.extend(
                {
                    type: 'default'
                },
                params
            );
            
            var notifyError = function() {
                
                $.cf.notify('There was an error launching a modal dialog. Please try again, and if the problem persists, contact <a href="mailto:support@cloudflare.com">support@cloudflare.com</a>!', $.cf.noteType.error);
                
            };
            
            // support object and array formats for options.buttons
            $.each(options.buttons, function(key, props) {
                var isFn = $.isFunction( props ),
                    callback = (isFn ? props : props.click) || $.noop,
                    clickFn = function() {

                        callback.apply(this, arguments);
                        $('#ModalComponent').triggerHandler('modalbutton', {name: isFn ? key : props.name});
                    };

                options.buttons[key] = isFn ? clickFn : {

                    text: props.text,
                    click: clickFn
                };
            });
            
            if(!$.cf.modalStateEnabled) {
                
                $.cf.modalStateEnabled = true;
                
                $.ajax(
                    {
                        url: '/ajax/modal-dialog.html',
                        dataType: 'html',
                        type: 'POST',
                        data: params,
                        error: notifyError,
                        success: function(html, status, xhr) {
                            
                            try {
                                
                                $('#HiddenContent').append(html);
                                
                                
                            } catch(e) {
                                
                                $.cf.log('There was an error creating a DOM node from the retrieved HTML!', $.cf.logType.error);
                                notifyError();
                                
                            }
                            
                            $('#ModalComponent').bind(
                                'contentready',
                                function(event) {
                                    
                                    $('#ModalDialog').dialog('option', 'position', 'center');
                                    $('.ui-dialog:has(#ModalDialog)').css(
                                        {
                                            marginTop: '40px',
                                            opacity: '0'
                                        }
                                    ).show().animate(
                                        {
                                            marginTop: '0',
                                            opacity: '1'
                                        },
                                        400,
                                        'easeOutExpo'
                                    );

                                    options.contentReady && options.contentReady(event);
                                }
                            ).bind(
                                'modalclose',
                                function(event) {
                                    
                                    $('#ModalDialog').dialog('close');
                                }
                            );
                            
                            $('#ModalDialog').dialog(options);
                            
                            $('#ModalComponent').triggerHandler('modalready');
                        }
                    }
                );
            }
        }
    };
    
    $.extend(
        $.fn,
        {  
            tooltip: function(options) {
                
                options = $.extend(
                    {
                        backgroundColor: '#3c5466',
                        textCSS: {
                            color: '#ffffff'
                        },
                        text: null,
                        offset: 10,
                        delay: 500,
                        width: null,
                        showOn: 'mouseenter',
                        hideOn: 'mouseleave',
                        forceMouse: false,
                        autoPointer: true,
                        align: 'center',
                        shadow: true,
                        attributes: [
                            'tooltip',
                            'alt',
                            'value',
                            'href',
                            'rel'
                        ],
                        customClass: null,
                        customContent: function(tip){}
                    },
                    options
                );
                
                this.each(
                    function(i, e) {
                        
                        var target = $(e),
                            tipText = options.text ? options.text : (function() {
                            
                            for(var i = 0; i < options.attributes.length; i++) {
                                
                                if(target.attr(options.attributes[i]) != undefined) {
                                    
                                    return target.attr(options.attributes[i]);
                                }
                            }
                        })();
                        
                        var tooltip,
                            left,
                            top,
                            timer,
                            custom,
                            visible = false;
                        
                        target.data(
                            'tooltip', 
                            {
                                showOn: options.showOn,
                                hideOn: options.hideOn,
                                showTip: function(event) {
                                    
                                    if(!visible) {
                                        timer = setTimeout(
                                            function() {
                                                
                                                if($.contains(document, target.get(0))) {
                                                    
                                                    tooltip = $('<div class="tooltip"></div>').appendTo('body').css(
                                                        {
                                                            width: options.width ? options.width + 'px' : null,
                                                            opacity: 0
                                                        }
                                                    ).hide();
                                                    
                                                    if(options.shadow) {
                                                        
                                                        tooltip.addClass('shadow');
                                                    }
                                                    
                                                    if(options.extraClass) {
                                                        
                                                        tooltip.addClass(options.extraClass);
                                                    }
                                                    
                                                    $('<div class="tip"><p>' + tipText + '</p></div>').appendTo(tooltip).css(
                                                        $.extend(
                                                            {
                                                                background: options.backgroundColor
                                                            },
                                                            options.textCSS
                                                        )
                                                    );
                                                    
                                                    if(options.customContent) {
                                                        
                                                        custom = $.isFunction(options.customContent) ? options.customContent(tooltip.children().first()) : options.customContent;
                                                        
                                                        if(custom instanceof jQuery) {
                                                            
                                                            custom.appendTo(tooltip.children().first());
                                                        }
                                                    }
                                                    
                                                    if(options.forceMouse) {
                                                        
                                                        left = $.cf.mouseX - tooltip.outerWidth() / 2;
                                                        top = $.cf.mouseY + options.offset;
                                                    } else {
                                                        
                                                        top = target.offset().top + (target.outerHeight() + options.offset);

                                                        switch(options.align) {
                                                            default:
                                                            case 'center':
                                                                
                                                                left = target.offset().left + (target.outerWidth() / 2 - tooltip.outerWidth() / 2);
                                                                
                                                                break;
                                                            case 'left':
                                                                
                                                                left = target.offset().left;
                                                                
                                                                break;
                                                            case 'right':
                                                                
                                                                left = target.offset().left + target.outerWidth() - tooltip.outerWidth();
                                                                
                                                                break;

                                                            case 'right-margin-top':

                                                                left = target.offset().left + target.outerWidth();
                                                                top = target.offset().top;

                                                                break;
                                                        }
                                                        
                                                    }
                                                    
                                                    
                                                    if(!$.browser.msie) {
                                                        
                                                        var pointerLeft;
                                                        
                                                        if(options.autoPointer) {
                                                            
                                                            if($.cf.mouseX && $.cf.mouseX < (left + 8)) {
                                                                
                                                                pointerLeft = 8;
                                                            } else if($.cf.mouseX > (left + tooltip.outerWidth() - 16)) {
                                                                
                                                                pointerLeft = tooltip.outerWidth() - 16;
                                                            } else if($.cf.mouseX) {
                                                                
                                                                pointerLeft = $.cf.mouseX - left - 5;
                                                            } else {
                                                                
                                                                pointerLeft = tooltip.outerWidth() / 2 - 4;
                                                            }
                                                            
                                                        } else {
                                                            
                                                            switch(options.align) {
                                                                default:
                                                                case 'center':
                                                                    
                                                                    pointerLeft = tooltip.outerWidth() / 2 - 4;
                                                                    break;
                                                                case 'left':
                                                                    
                                                                    pointerLeft = 8;
                                                                    break;
                                                                case 'right':
                                                                    
                                                                    pointerLeft = tooltip.outerWidth() - 16;
                                                                    break;
                                                            }
                                                            
                                                        }
                                                        
                                                        
                                                        $('<div class="pointer"></div>').prependTo(tooltip).css(
                                                            {
                                                                left: pointerLeft + 'px',
                                                                background: options.backgroundColor
                                                            }
                                                        );
                                                    }
                                                    
                                                    tooltip.css(
                                                        {
                                                            top: (top + 10) + 'px',
                                                            left: left + 'px'
                                                        }
                                                    ).show().animate(
                                                        {
                                                            opacity: 1,
                                                            top: top + 'px'
                                                        },
                                                        200
                                                    );
                                                    
                                                    if(custom) {
                                                        
                                                        custom.trigger('visible');
                                                    }
                                                } else {
                                                    
                                                    $.cf.log("Tooltip's designated target was not attached to the DOM! Aborting..", $.cf.logType.warning);
                                                    target.mouseleave();
                                                }
                                            },
                                            options.delay
                                        );
                                        
                                        visible = true;
                                    }
                                },
                                hideTip: function(event) {
                                    
                                    if(visible) {
                                        
                                        if(timer) {
                                            clearTimeout(timer);
                                        }
                                        
                                        if(tooltip != null) {
                                            tooltip.stop().animate(
                                                {
                                                    opacity: 0,
                                                    top: (top - 10) + 'px'
                                                },
                                                200,
                                                function() {
                                                    tooltip.remove();
                                                    tooltip = null;
                                                    
                                                    if(options.forceMouse) {
                                                        
                                                        target.clearTooltip();
                                                    }
                                                }
                                            );
                                        }
                                        
                                        visible = false;
                                    }
                                }
                            }
                        );
                        
                        if(options.forceMouse) {
                            
                            target.bind(
                                target.data('tooltip').hideOn + ' remove',
                                target.data('tooltip').hideTip
                            ).data('tooltip').showTip();
                        } else {
                        
                            target.bind(
                                target.data('tooltip').showOn,
                                target.data('tooltip').showTip
                            ).bind(
                                target.data('tooltip').hideOn + ' remove',
                                target.data('tooltip').hideTip
                            );
                        }
                    }
                )
                
                return this;
            },
            clearTooltip: function() {
                
                this.each(
                    function(i, e) {
                        
                        var target = $(e);
                        
                        if(target.data('tooltip')) {
                            
                            target.data('tooltip').hideTip();
                            
                            target.unbind(
                                target.data('tooltip').showOn,
                                target.data('tooltip').showTip
                            ).unbind(
                                target.data('tooltip').hideOn + ' remove',
                                target.data('tooltip').hideTip
                            );
                        }
                    }
                );
                
                return this;
            },
            placeholder: function() {
                
                /* DEPRECATED - FIX!
                this.each(
                    function(i, e) {
                        
                        var target = $(e);
                        
                        var targetHasValue = function() {
                            
                            return target.val() && target.val() != "";
                        }
                        
                        if(target.attr('placeholder') && target.is('input[type="text"]')) {
                            
                            var placeholderText = target.attr('placeholder');
                            var usePlaceholder = false;
                            
                            target.bind(
                                'keyup',
                                function(event) {
                                    
                                    if(targetHasValue()) {
                                        
                                        usePlaceholder = false;
                                    } else {
                                        
                                        usePlaceholder = true;
                                    }
                                }
                            ).bind(
                                'blur',
                                function(event) {
                                    
                                    $.cf.log('Should add placeholder?');
                                    if(usePlaceholder) {
                                        $.cf.log('Adding placeholder!');
                                        target.addClass('placeholder');
                                        target.val(placeholderText);
                                    }
                                }
                            ).bind(
                                'focus',
                                function(event) {
                                    
                                    if(usePlaceholder) {
                                        
                                        target.removeClass('placeholder');
                                        target.val("");
                                    }
                                }
                            );
                        }
                        
                        if(!targetHasValue()) {
                            
                            target.keyup().blur();
                        }
                    }
                );
                */
            },
            copyToClipboard: function(options) {
                
                options = $.extend(
                    {
                        caption: "Press 'control/command + c' to copy:",
                        copyTarget: null,
                        copyText: null,
                        attributes: [
                            'clipboard',
                            'alt',
                            'value',
                            'href',
                            'rel'
                        ],
                        tooltipOptions: {}
                    },
                    options
                );
                
                this.each(
                    function(i, e) {
                        
                        var target = $(this),
                            copyText = false;
                        
                        if(!options.copyText) {
                            
                            var copyTarget = options.copyTarget || target;
                            
                            $.each(
                                options.attributes,
                                function(i, a) {
                                    
                                    if(copyTarget.attr(a)) {
                                        
                                        options.copyText = copyTarget.attr(a);
                                        return false;
                                    }
                                }
                            );
                        }
                        
                        copyText = options.copyText || "Undefined";
                        
                        target.tooltip(
                            $.extend(
                                {
                                    delay: 150
                                },
                                options.tooltipOptions,
                                {
                                    text: options.caption,
                                    customContent: function() {
                                        return $('<input class="clipboard" type="text" value="' + copyText + '" />').bind(
                                            'visible',
                                            function(e) {
                                                
                                                this.select();
                                            }
                                        );
                                    }
                                }
                            )
                        );
                    }
                );
            }
        }
    );
    
    $(document).bind(
        'mousemove',
        function(event) {
            $.cf.mouseX = event.pageX;
            $.cf.mouseY = event.pageY;
        }
    );
})(jQuery);

/*******************************************************************************
 *
 * CloudFlare UI Toggle Selector
 * 
 * @author Christopher Joel
 * 
 * Copyright 2010 CloudFlare, Inc.
 * 
 ******************************************************************************/

(function($) {
    
    $.extend(
        $.cf,
        {
            clientType: {
                
                ie: "Internet Explorer",
                gecko: "Gecko",
                webkit: "Webkit",
                opera: "Opera",
                unknown: "Unknown"
                
            },
            
            resolveClient: function() {
                
                if($.browser.msie)
                    return $.cf.clientType.ie;
                
                if($.browser.mozilla)
                    return $.cf.clientType.gecko;
                
                if($.browser.webkit || $.browser.safari)
                    return $.cf.clientType.webkit;
                    
                if($.browser.opera)
                    return $.cf.clientType.opera;
                    
                return $.cf.clientType.unknown;
                
            },
            
            resolveClientUpgradeURL: function() {
                
                switch($.cf.resolveClient()) {
                    case $.cf.clientType.ie:
                        return "http://www.microsoft.com/windows/internet-explorer/default.aspx";
                    default:
                    case $.cf.clientType.mozilla:
                        return "http://www.mozilla.com/en-US/firefox/personal.html";
                    case $.cf.clientType.opera:
                        return "http://www.opera.com/browser/";
                    case $.cf.clientType.webkit:
                        return "http://www.google.com/chrome";
                }
                
            },
            
            clientStatus: {
                
                unknown: "Unknown",
                standard: "Standard",
                deprecated: "Deprecated",
                obsolete: "Obsolete"
                
            },
            
            resolveClientStatus: function() {
                
                switch($.cf.resolveClient()) {
                    
                    case $.cf.clientType.ie: {
                        
                        var version = parseInt($.browser.version.substr(0, 2));
                        
                        if(version > 7) {
                            return $.cf.clientStatus.standard;
                        } else if(version > 6) {
                            return $.cf.clientStatus.deprecated;
                        } else {
                            return $.cf.clientStatus.obsolete;
                        }
                        
                        break;
                    }
                    
                    case $.cf.clientType.gecko: {
                        
                        var major = parseInt($.browser.version.substr(0, 1));
                        var minor = parseInt($.browser.version.substr(2, 1));
                        var revision;
                        
                        try {
                            revision = parseInt($.browser.version.substr(4, 1));
                        } catch(e) {
                            revision = 0;
                        }
                        
                        if(major > 0) {
                            if(minor > 7) {
                                if(minor > 8 && revision > 0) {
                                    return $.cf.clientStatus.standard;
                                } else {
                                    return $.cf.clientStatus.deprecated;
                                }
                            } else if(major > 1) {
                                
                                return $.cf.clientStatus.standard;
                            } else {
                                return $.cf.clientStatus.obsolete;
                            }
                        } else {
                            return $.cf.clientStatus.obsolete;
                        }
                        
                        break;
                    }
                    
                    case $.cf.clientType.webkit: {
                        
                        var version = parseInt($.browser.version.substr(0, 3));
                        
                        if(version > 500)
                            return $.cf.clientStatus.standard;
                        else if(version > 400)
                            return $.cf.clientStatus.deprecated;
                        else
                            return $.cf.clientStatus.obsolete;
                        
                        break;
                    }
                    
                    case $.cf.clientType.opera: {
                        
                        var version = parseInt($.browser.version.substr(0, 2));
                        
                        if(version > 9) {
                            return $.cf.clientStatus.standard;
                        } else if(version > 8) {
                            return $.cf.clientStatus.deprecated;
                        } else {
                            return $.cf.clientStatus.obsolete;
                        }
                        
                        break;
                    }
                }
                
                return $.cf.clientStatus.unknown;
                
            },
            
            clientTier: {
                
                // Full support for modern web standards, including support for HTML5 & CSS3 (i.e. Firefox 3.5+ & Webkit.. IE9?)
                one: 1,
                // Modest support for web standards, but nothing cutting edge (i.e. IE8-ish, Firefox 3, Opera 9)
                two: 2,
                // Moderately quirky or unreliable behavior (i.e. IE7, Firefox 2, old Safari)
                three: 3,
                // Totally unreliable and thus unsupported browsers (i.e. IE6)
                four: 4,
                // If we get this, well.. who knows?
                unknown: -1
                
            },
            
            resolveClientTier: function() {
                
                var client = $.cf.resolveClient();
                var status = $.cf.resolveClientStatus();
                
                if(
                    status == $.cf.clientStatus.standard &&
                    (
                        client == $.cf.clientType.webkit || 
                        client == $.cf.clientType.gecko ||
                        client == $.cf.clientType.opera
                    )
                ) {
                    return $.cf.clientTier.one;
                }
                
                if(
                    status == $.cf.clientStatus.deprecated &&
                    (
                        client == $.cf.clientType.gecko ||
                        client == $.cf.clientType.webkit
                    ) ||
                    status == $.cf.clientStatus.standard &&
                    client == $.cf.clientType.ie
                ) {
                    return $.cf.clientTier.two;
                }
                
                if(
                    status == $.cf.clientStatus.deprecated &&
                    (
                        client == $.cf.clientType.ie ||
                        client == $.cf.clientType.opera ||
                        client == $.cf.clientType.unknown
                    ) || status == $.cf.clientStatus.obsolete &&
                    (
                        client == $.cf.clientType.gecko ||
                        client == $.cf.clientType.webkit
                    )
                ) {
                   return $.cf.clientTier.three;
                }
                
                if(
                    status == $.cf.clientStatus.obsolete
                ) {
                    return $.cf.clientTier.four;
                }
                
                return $.cf.clientTier.unknown;
                
            },
            
            clientValue: function(options) {
                
                options = $.extend(
                    {
                        key: null,
                        value: null,
                        domain: null,
                        path: '/',
                        expires: 1,
                        secure: true
                    },
                    options
                );
                
                var result = null;
                
                if(options.key != null) {
                    
                    if(options.value) {
                        
                        document.cookie = options.key + '=' + encodeURIComponent(options.value) + '; expires=' + (new Date((new Date()).getTime() + options.expires * 24 * 60 * 60 * 1000)).toUTCString() + '; path=' + options.path + (options.domain != null ? '; domain=' + options.domain : '') + (options.secure ? '; secure' : '');
                        
                    } else {
                        
                        if(document.cookie && document.cookie != '') {
                            
                            var cookies = document.cookie.split(';');
                            
                            $.each(
                                cookies,
                                function(i, c) {
                                    
                                    if($.trim(c).substr(0, options.key.length + 1) == options.key + "=") {
                                        
                                        result = decodeURIComponent($.trim(c).substr(options.key.length + 1));
                                        return false;
                                        
                                    }
                                }
                            );
                        }
                    }
                }
                
                return result;
                
            },
            
            promptChromeFrame: function() {
                        
                try {
                    
                    $.getScript(
                        'http://ajax.googleapis.com/ajax/libs/chrome-frame/1/CFInstall.min.js', 
                        function() {
                            
                            $('body').prepend('<div id="ChromeFrameInstaller"><div class="background"></div><iframe id="ChromeFrameInstallerFrame"></iframe></div>');
                            
                            $('div#ChromeFrameInstaller > div.background').css('opacity', '0.5');
                            $('html').css('overflow', 'hidden');
                            
                            CFInstall.check(
                                {
                                    node: 'ChromeFrameInstallerFrame'
                                }
                            );
                            
                            $.cf.clientValue({ key: 'ChromeFramePrompted', value: 1 });
                            
                        }
                    );
                    
                } catch(e) {
                    
                    $.cf.log("Can't load CFInstall!", $.cf.logType.error);
                    
                }
            },
            
            invalidateClient: function() {
                
                $('a.chromeFrameInstallLauncher').live(
                    'click',
                    function() {
                        
                        $.cf.clearNotifications();
                        
                        $.cf.promptChromeFrame();
                        
                    }
                );
                
                switch($.cf.resolveClientTier()) {
                    
                    case $.cf.clientTier.one: {
                        break;
                    }
                    case $.cf.clientTier.two: {
                        break;
                    }
                    case $.cf.clientTier.three: {
                        
                        if($.cf.clientValue({ key: 'ChromeFramePrompted' }) == null) {
                            
                            $.cf.notify('Your current browser may not display CloudFlare correctly. We highly recommend that you <a href="' + $.cf.resolveClientUpgradeURL() + '" target="_blank">upgrade your browser</a>' + ($.cf.resolveClient() == $.cf.clientType.ie ? ', or <a href="javascript:void(0);" class="chromeFrameInstallLauncher">install Chrome Frame</a>,' : '') + ' before continuing!', $.cf.noteType.warning, 20);
                            
                        }
                        
                        break;
                    }
                    case $.cf.clientTier.four: {
                        
                        $.cf.notify('Your current browser will not display CloudFlare correctly! Please <a href="' + $.cf.resolveClientUpgradeURL() + '" target="_blank">upgrade your browser</a>' + ($.cf.resolveClient() == $.cf.clientType.ie ? ', or <a href="javascript:void(0);" class="chromeFrameInstallLauncher">install Chrome Frame</a>,' : '') + ' before continuing!', $.cf.noteType.error, -1);
                        
                        break;
                    }
                }
            }
            
        }
    );

    (function(){

        var resolveIsMobile = function(userAgent){
            return /android|avantgo|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(userAgent) ||
                /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|e\-|e\/|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(di|rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|xda(\-|2|g)|yas\-|your|zeto|zte\-/i.test(userAgent.substr(0,4));
        };

        $.cf.isMobile = resolveIsMobile(navigator.userAgent||navigator.vendor||window.opera||"");

    })();
    
})(jQuery);

/*******************************************************************************
 *
 * CloudFlare Media-related Functions
 * 
 * @author Christopher Joel
 * 
 * Copyright 2010 CloudFlare, Inc.
 * 
 ******************************************************************************/

(function($) {
    
    $.fn.embedFlash = function(options) {
        
        options = $.extend({
            
            container: this,
            source: "",
            width: "640",
            height: "480",
            cssClass: "",
            flashvars: {},
            params: {},
            attributes: {},
            version: "9.0.0",
            expressInstall: "flash/expressInstall.swf",
            success: function() {},
            error: function() {}
            
        }, options);
        
        if(options.source != "") {
            
            options.flashvars = $.extend(
                {}, options.flashvars
            );
            
            options.params = $.extend(
                {
                    
                    "allowscriptaccess"	: "always",
                    "allowfullscreen"	: "true"
                    
                }, options.params
            );
            
            options.attributes = $.extend (
                {}, options.attributes
            );
            
            options.attributes["class"] = options.cssClass;
            
            var flashID = this.first().attr('id');
            
            swfobject.embedSWF(
                options.source, 
                flashID, 
                options.width, 
                options.height, 
                options.version, 
                options.expressInstall, 
                options.flashvars, 
                options.params, 
                options.attributes, 
                function(result) {
                    
                    if(result.success) {
                        
                        options.success($('#' + flashID));
                        
                    } else {
                        
                        options.error();
                        
                    }
                }
            );
        }
        
        return this;
        
    }
    
    
    $._cfVimeoOptions = {};
    
    $._cfVimeoLoaded = function(elementID) {
        
        var options = $._cfVimeoOptions[elementID];
        
        clearTimeout(options._loadTimeout);
        
        var moogaloop = document.getElementById(elementID);
        
        var videoDetails = {
            
            duration: parseInt(moogaloop.api_getDuration()),
            element: moogaloop
            
        };
        
        moogaloop.api_addEventListener("onPlay", "$._cfVideoOptions." + elementID + ".onPlay");
        moogaloop.api_addEventListener("onFinish", "$._cfVideoOptions." + elementID + ".onFinish");
        
        $._cfVimeoOptions[elementID].onLoad(videoDetails);
        
    };
    
    $.fn.embedVimeo = function(options) {
        
        options = $.extend({
            
            container: this,
            autoPlay: true,
            clipID: null,
            onLoad: function() { },
            onPlay: function() { },
            onFinish: function() { },
            onError: function() { },
            width: 640,
            height: 480,
            playerColor: 'e67300',
            customVars: {},
            customParams: {},
            customAttrs: {},
            timeout: 10000
            
        }, options);
        
        if(options.clipID) {
            
            $._cfVimeoOptions[options.container.attr('id')] = options;
            
            options.customVars = $.extend(
                {
                
                    "clip_id" : options.clipID,
                    "show_title" : 0,
                    "show_byline" : 0,
                    "show_portrait" : 0,
                    "color" : options.playerColor,
                    "fullscreen" : 1,
                    "autoplay" : options.autoPlay ? 1 : 0,
                    "js_api" : 1,
                    "js_onLoad" : "$._cfVimeoLoaded", 
                    "js_swf_id" : options.container.attr("id")
                
                }, options.customVars
            );
            
            options.customParams = $.extend(
                {
                    
                    "allowscriptaccess"	: "always",
                    "allowfullscreen"	: "true"
                    
                }, options.customParams
            );
            
            options.customAttrs = $.extend (
                {}, options.customAttrs
            );
            
            options.container.embedFlash(
                {
                    
                    source: "http://vimeo.com/moogaloop.swf", 
                    width: options.width, 
                    height: options.height, 
                    version: "9.0.0",
                    flashvars: options.customVars,
                    params: options.customParams,
                    attributes: options.customAttrs,
                    error: options.onError
                    
                }
            );
            
            options._loadTimeout = setTimeout(
                function() {
                    
                    options.onError();
                    
                },
                options.timeout
            );
            
        }
        
        return this;
        
    };
    
    $.fn.embedClippy = function(options) {
        
        options = $.extend({
            
            container: this,
            textToCopy: "",
            remove: false
            
        }, options);
        
        options.container.each(function(i, e) {
            
            $(e).embedFlash(
                {
                    source: "/flash/clippy.swf",
                    width: "110px",
                    height: "14px",
                    cssClass: "flash-clippy",
                    version: "9.0.0",
                    flashvars: {
                        text: options.textToCopy
                    },
                    params: {
                        bgcolor: "#FFFDE5"
                    }
                }
            );
        }); 
        
        return this;
        
    }
    
})(jQuery);
/*******************************************************************************
 *
 * CloudFlare Tracking Functions
 * 
 * @author Christopher Joel
 * 
 * Copyright 2010 CloudFlare, Inc.
 * 
 ******************************************************************************/

(function($) {
    
    $.extend(
        $.expr[':'], 
        {
            external: function(e) {
                return (e.host && e.host !== location.host) === true;
            },
            email: function(e) {
                return (e.href && e.href.substr(0, 7) === "mailto:");
            }
        }
    );

    $.fn.trackEvent = function(options) {
    
        options = $.extend(
            {
                events: 'click',
                bind: 'bind',
                category: this.nodeName,
                action: null,
                label: null,
                value: 1
            }, 
            options
        );
        
        var targets = this;
        
        var resolveLabel = function(element) {
            
            if(element.is('a') && element.attr('href') != "javascript:void(0);") {
                return element.attr('href');
            }
            else if(element.is('input')) {
                return element.val();
            }
            else if(element.attr('id')) {
                return element.attr('id');
            }
            else{
                return element.text();
            }
            
        }
        
        options.events = $.isArray(options.events) ? options.events : [options.events];
        
        $.each(
            options.events,
            function(i, e) {
                
                var events = e;
                var targetOptions = $.extend({}, options);
                
                targets[targetOptions.bind](
                    
                    events,
                    function(event) {
                        
                        targetOptions.action = targetOptions.action ? targetOptions.action : event;
                        targetOptions.label = targetOptions.label ? targetOptions.label : resolveLabel(targets);
                        
                        try {
                            _gaq.push(
                                [
                                    '_trackEvent', 
                                    targetOptions.category,
                                    targetOptions.action,
                                    targetOptions.label,
                                    targetOptions.value
                                ]
                            );
                        } catch(e) {
                            $.cf.log('Google Analytics appears to be missing! If you are not browsing offline, report this issue!', $.cf.logType.error);
                        }
                    }
                );
            }
        );
    
    };
    
})(jQuery);

    
(function($) {
    $.extend(
        $.cf,
        {
            countryHash: {
                unicodeCountry: {"AF":"Afghanistan","AX":"Aland Islands","AL":"Albania","DZ":"Algeria","AS":"American Samoa","AD":"Andorra","AO":"Angola","AI":"Anguilla","AQ":"Antarctica","AG":"Antigua and Barbuda","AR":"Argentina","AM":"Armenia","AW":"Aruba","AU":"Australia","AT":"Austria","AZ":"Azerbaijan","BS":"Bahamas","BH":"Bahrain","BD":"Bangladesh","BB":"Barbados","BY":"Belarus","BE":"Belgium","BZ":"Belize","BJ":"Benin","BM":"Bermuda","BT":"Bhutan","BO":"Bolivia, Plurinational State of","BA":"Bosnia and Herzegovina","BW":"Botswana","BV":"Bouvet Island","BR":"Brazil","IO":"British Indian Ocean Territory","BN":"Brunei Darussalam","BG":"Bulgaria","BF":"Burkina Faso","BI":"Burundi","KH":"Cambodia","CM":"Cameroon","CA":"Canada","CV":"Cape Verde","KY":"Cayman Islands","CF":"Central African Republic","TD":"Chad","CL":"Chile","CN":"China","CX":"Christmas Island","CC":"Cocos (Keeling) Islands","CO":"Colombia","KM":"Comoros","CG":"Congo","CD":"Congo, the Democratic Republic of the","CK":"Cook Islands","CR":"Costa Rica","CI":"Cote d'Ivoire","HR":"Croatia","CU":"Cuba","CY":"Cyprus","CZ":"Czech Republic","DK":"Denmark","DJ":"Djibouti","DM":"Dominica","DO":"Dominican Republic","EC":"Ecuador","EG":"Egypt","SV":"El Salvador","GQ":"Equatorial Guinea","ER":"Eritrea","EE":"Estonia","ET":"Ethiopia","FK":"Falkland Islands (Malvinas)","FO":"Faroe Islands","FJ":"Fiji","FI":"Finland","FR":"France","GF":"French Guiana","PF":"French Polynesia","TF":"French Southern Territories","GA":"Gabon","GM":"Gambia","GE":"Georgia","DE":"Germany","GH":"Ghana","GI":"Gibraltar","GR":"Greece","GL":"Greenland","GD":"Grenada","GP":"Guadeloupe","GU":"Guam","GT":"Guatemala","GG":"Guernsey","GN":"Guinea","GW":"Guinea-Bissau","GY":"Guyana","HT":"Haiti","HM":"Heard Island and McDonald Islands","VA":"Holy See (Vatican City State)","HN":"Honduras","HK":"Hong Kong","HU":"Hungary","IS":"Iceland","IN":"India","ID":"Indonesia","IR":"Iran, Islamic Republic of","IQ":"Iraq","IE":"Ireland","IM":"Isle of Man","IL":"Israel","IT":"Italy","JM":"Jamaica","JP":"Japan","JE":"Jersey","JO":"Jordan","KZ":"Kazakhstan","KE":"Kenya","KI":"Kiribati","KP":"Korea, Democratic People's Republic of","KR":"Korea, Republic of","KW":"Kuwait","KG":"Kyrgyzstan","LA":"Lao People's Democratic Republic","LV":"Latvia","LB":"Lebanon","LS":"Lesotho","LR":"Liberia","LY":"Libyan Arab Jamahiriya","LI":"Liechtenstein","LT":"Lithuania","LU":"Luxembourg","MO":"Macao","MK":"Macedonia, the former Yugoslav Republic of","MG":"Madagascar","MW":"Malawi","MY":"Malaysia","MV":"Maldives","ML":"Mali","MT":"Malta","MH":"Marshall Islands","MQ":"Martinique","MR":"Mauritania","MU":"Mauritius","YT":"Mayotte","MX":"Mexico","FM":"Micronesia, Federated States of","MD":"Moldova, Republic of","MC":"Monaco","MN":"Mongolia","ME":"Montenegro","MS":"Montserrat","MA":"Morocco","MZ":"Mozambique","MM":"Myanmar","NA":"Namibia","NR":"Nauru","NP":"Nepal","NL":"Netherlands","AN":"Netherlands Antilles","NC":"New Caledonia","NZ":"New Zealand","NI":"Nicaragua","NE":"Niger","NG":"Nigeria","NU":"Niue","NF":"Norfolk Island","MP":"Northern Mariana Islands","NO":"Norway","OM":"Oman","PK":"Pakistan","PW":"Palau","PS":"Palestinian Territory, Occupied","PA":"Panama","PG":"Papua New Guinea","PY":"Paraguay","PE":"Peru","PH":"Philippines","PN":"Pitcairn","PL":"Poland","PT":"Portugal","PR":"Puerto Rico","QA":"Qatar","RE":"Reunion","RO":"Romania","RU":"Russian Federation","RW":"Rwanda","BL":"Saint Barthelemy","SH":"Saint Helena, Ascension and Tristan da Cunha","KN":"Saint Kitts and Nevis","LC":"Saint Lucia","MF":"Saint Martin (French part)","PM":"Saint Pierre and Miquelon","VC":"Saint Vincent and the Grenadines","WS":"Samoa","SM":"San Marino","ST":"Sao Tome and Principe","SA":"Saudi Arabia","SN":"Senegal","RS":"Serbia","SC":"Seychelles","SL":"Sierra Leone","SG":"Singapore","SK":"Slovakia","SI":"Slovenia","SB":"Solomon Islands","SO":"Somalia","ZA":"South Africa","GS":"South Georgia and the South Sandwich Islands","ES":"Spain","LK":"Sri Lanka","SD":"Sudan","SR":"Suriname","SJ":"Svalbard and Jan Mayen","SZ":"Swaziland","SE":"Sweden","CH":"Switzerland","SY":"Syrian Arab Republic","TW":"Taiwan, Province of China","TJ":"Tajikistan","TZ":"Tanzania, United Republic of","TH":"Thailand","TL":"Timor-Leste","TG":"Togo","TK":"Tokelau","TO":"Tonga","TT":"Trinidad and Tobago","TN":"Tunisia","TR":"Turkey","TM":"Turkmenistan","TC":"Turks and Caicos Islands","TV":"Tuvalu","UG":"Uganda","UA":"Ukraine","AE":"United Arab Emirates","GB":"United Kingdom","US":"United States","UM":"United States Minor Outlying Islands","UY":"Uruguay","UZ":"Uzbekistan","VU":"Vanuatu","VE":"Venezuela, Bolivarian Republic of","VN":"Viet Nam","VG":"Virgin Islands, British","VI":"Virgin Islands, U.S.","WF":"Wallis and Futuna","EH":"Western Sahara","YE":"Yemen","ZM":"Zambia","ZW":"Zimbabwe"},
                countryUnicode: {"afghanistan":"AF","aland islands":"AX","albania":"AL","algeria":"DZ","american samoa":"AS","andorra":"AD","angola":"AO","anguilla":"AI","antarctica":"AQ","antigua and barbuda":"AG","argentina":"AR","armenia":"AM","aruba":"AW","australia":"AU","austria":"AT","azerbaijan":"AZ","bahamas":"BS","bahrain":"BH","bangladesh":"BD","barbados":"BB","belarus":"BY","belgium":"BE","belize":"BZ","benin":"BJ","bermuda":"BM","bhutan":"BT","bolivia, plurinational state of":"BO","bosnia and herzegovina":"BA","botswana":"BW","bouvet island":"BV","brazil":"BR","british indian ocean territory":"IO","brunei darussalam":"BN","bulgaria":"BG","burkina faso":"BF","burundi":"BI","cambodia":"KH","cameroon":"CM","canada":"CA","cape verde":"CV","cayman islands":"KY","central african republic":"CF","chad":"TD","chile":"CL","china":"CN","christmas island":"CX","cocos (keeling) islands":"CC","colombia":"CO","comoros":"KM","congo":"CG","congo, the democratic republic of the":"CD","cook islands":"CK","costa rica":"CR","cote d'ivoire":"CI","croatia":"HR","cuba":"CU","cyprus":"CY","czech republic":"CZ","denmark":"DK","djibouti":"DJ","dominica":"DM","dominican republic":"DO","ecuador":"EC","egypt":"EG","el salvador":"SV","equatorial guinea":"GQ","eritrea":"ER","estonia":"EE","ethiopia":"ET","falkland islands (malvinas)":"FK","faroe islands":"FO","fiji":"FJ","finland":"FI","france":"FR","french guiana":"GF","french polynesia":"PF","french southern territories":"TF","gabon":"GA","gambia":"GM","georgia":"GE","germany":"DE","ghana":"GH","gibraltar":"GI","greece":"GR","greenland":"GL","grenada":"GD","guadeloupe":"GP","guam":"GU","guatemala":"GT","guernsey":"GG","guinea":"GN","guinea-bissau":"GW","guyana":"GY","haiti":"HT","heard island and mcdonald islands":"HM","holy see (vatican city state)":"VA","honduras":"HN","hong kong":"HK","hungary":"HU","iceland":"IS","india":"IN","indonesia":"ID","iran, islamic republic of":"IR","iraq":"IQ","ireland":"IE","isle of man":"IM","israel":"IL","italy":"IT","jamaica":"JM","japan":"JP","jersey":"JE","jordan":"JO","kazakhstan":"KZ","kenya":"KE","kiribati":"KI","korea, democratic people's republic of":"KP","korea, republic of":"KR","kuwait":"KW","kyrgyzstan":"KG","lao people's democratic republic":"LA","latvia":"LV","lebanon":"LB","lesotho":"LS","liberia":"LR","libyan arab jamahiriya":"LY","liechtenstein":"LI","lithuania":"LT","luxembourg":"LU","macao":"MO","macedonia, the former yugoslav republic of":"MK","madagascar":"MG","malawi":"MW","malaysia":"MY","maldives":"MV","mali":"ML","malta":"MT","marshall islands":"MH","martinique":"MQ","mauritania":"MR","mauritius":"MU","mayotte":"YT","mexico":"MX","micronesia, federated states of":"FM","moldova, republic of":"MD","monaco":"MC","mongolia":"MN","montenegro":"ME","montserrat":"MS","morocco":"MA","mozambique":"MZ","myanmar":"MM","namibia":"NA","nauru":"NR","nepal":"NP","netherlands":"NL","netherlands antilles":"AN","new caledonia":"NC","new zealand":"NZ","nicaragua":"NI","niger":"NE","nigeria":"NG","niue":"NU","norfolk island":"NF","northern mariana islands":"MP","norway":"NO","oman":"OM","pakistan":"PK","palau":"PW","palestinian territory, occupied":"PS","panama":"PA","papua new guinea":"PG","paraguay":"PY","peru":"PE","philippines":"PH","pitcairn":"PN","poland":"PL","portugal":"PT","puerto rico":"PR","qatar":"QA","reunion":"RE","romania":"RO","russian federation":"RU","rwanda":"RW","saint barthelemy":"BL","saint helena, ascension and tristan da cunha":"SH","saint kitts and nevis":"KN","saint lucia":"LC","saint martin (french part)":"MF","saint pierre and miquelon":"PM","saint vincent and the grenadines":"VC","samoa":"WS","san marino":"SM","sao tome and principe":"ST","saudi arabia":"SA","senegal":"SN","serbia":"RS","seychelles":"SC","sierra leone":"SL","singapore":"SG","slovakia":"SK","slovenia":"SI","solomon islands":"SB","somalia":"SO","south africa":"ZA","south georgia and the south sandwich islands":"GS","spain":"ES","sri lanka":"LK","sudan":"SD","suriname":"SR","svalbard and jan mayen":"SJ","swaziland":"SZ","sweden":"SE","switzerland":"CH","syrian arab republic":"SY","taiwan, province of china":"TW","tajikistan":"TJ","tanzania, united republic of":"TZ","thailand":"TH","timor-leste":"TL","togo":"TG","tokelau":"TK","tonga":"TO","trinidad and tobago":"TT","tunisia":"TN","turkey":"TR","turkmenistan":"TM","turks and caicos islands":"TC","tuvalu":"TV","uganda":"UG","ukraine":"UA","united arab emirates":"AE","united kingdom":"GB","united states":"US","united states minor outlying islands":"UM","uruguay":"UY","uzbekistan":"UZ","vanuatu":"VU","venezuela, bolivarian republic of":"VE","viet nam":"VN","virgin islands, british":"VG","virgin islands, u.s.":"VI","wallis and futuna":"WF","western sahara":"EH","yemen":"YE","zambia":"ZM","zimbabwe":"ZW"},
                searchCountry: {"a":["Afghanistan","Aland Islands","Albania","Algeria","American Samoa","Andorra","Angola","Anguilla","Antarctica","Antigua and Barbuda","Argentina","Armenia","Aruba","Australia","Austria","Azerbaijan"],"af":["Afghanistan"],"afg":["Afghanistan"],"al":["Aland Islands","Albania","Algeria"],"ala":["Aland Islands"],"alb":["Albania"],"alg":["Algeria"],"am":["American Samoa"],"ame":["American Samoa"],"an":["Andorra","Angola","Anguilla","Antarctica","Antigua and Barbuda"],"and":["Andorra"],"ang":["Angola","Anguilla"],"ant":["Antarctica","Antigua and Barbuda"],"ar":["Argentina","Armenia","Aruba"],"arg":["Argentina"],"arm":["Armenia"],"aru":["Aruba"],"au":["Australia","Austria"],"aus":["Australia","Austria"],"az":["Azerbaijan"],"aze":["Azerbaijan"],"b":["Bahamas","Bahrain","Bangladesh","Barbados","Belarus","Belgium","Belize","Benin","Bermuda","Bhutan","Bolivia, Plurinational State of","Bosnia and Herzegovina","Botswana","Bouvet Island","Brazil","British Indian Ocean Territory","Brunei Darussalam","Bulgaria","Burkina Faso","Burundi"],"ba":["Bahamas","Bahrain","Bangladesh","Barbados"],"bah":["Bahamas","Bahrain"],"ban":["Bangladesh"],"bar":["Barbados"],"be":["Belarus","Belgium","Belize","Benin","Bermuda"],"bel":["Belarus","Belgium","Belize"],"ben":["Benin"],"ber":["Bermuda"],"bh":["Bhutan"],"bhu":["Bhutan"],"bo":["Bolivia, Plurinational State of","Bosnia and Herzegovina","Botswana","Bouvet Island"],"bol":["Bolivia, Plurinational State of"],"bos":["Bosnia and Herzegovina"],"bot":["Botswana"],"bou":["Bouvet Island"],"br":["Brazil","British Indian Ocean Territory","Brunei Darussalam"],"bra":["Brazil"],"bri":["British Indian Ocean Territory"],"bru":["Brunei Darussalam"],"bu":["Bulgaria","Burkina Faso","Burundi"],"bul":["Bulgaria"],"bur":["Burkina Faso","Burundi"],"c":["Cambodia","Cameroon","Canada","Cape Verde","Cayman Islands","Central African Republic","Chad","Chile","China","Christmas Island","Cocos (Keeling) Islands","Colombia","Comoros","Congo","Congo, the Democratic Republic of the","Cook Islands","Costa Rica","Cote d'Ivoire","Croatia","Cuba","Cyprus","Czech Republic"],"ca":["Cambodia","Cameroon","Canada","Cape Verde","Cayman Islands"],"cam":["Cambodia","Cameroon"],"can":["Canada"],"cap":["Cape Verde"],"cay":["Cayman Islands"],"ce":["Central African Republic"],"cen":["Central African Republic"],"ch":["Chad","Chile","China","Christmas Island"],"cha":["Chad"],"chi":["Chile","China"],"chr":["Christmas Island"],"co":["Cocos (Keeling) Islands","Colombia","Comoros","Congo","Congo, the Democratic Republic of the","Cook Islands","Costa Rica","Cote d'Ivoire"],"coc":["Cocos (Keeling) Islands"],"col":["Colombia"],"com":["Comoros"],"con":["Congo","Congo, the Democratic Republic of the"],"coo":["Cook Islands"],"cos":["Costa Rica"],"cot":["Cote d'Ivoire"],"cr":["Croatia"],"cro":["Croatia"],"cu":["Cuba"],"cub":["Cuba"],"cy":["Cyprus"],"cyp":["Cyprus"],"cz":["Czech Republic"],"cze":["Czech Republic"],"d":["Denmark","Djibouti","Dominica","Dominican Republic"],"de":["Denmark"],"den":["Denmark"],"dj":["Djibouti"],"dji":["Djibouti"],"do":["Dominica","Dominican Republic"],"dom":["Dominica","Dominican Republic"],"e":["Ecuador","Egypt","El Salvador","Equatorial Guinea","Eritrea","Estonia","Ethiopia"],"ec":["Ecuador"],"ecu":["Ecuador"],"eg":["Egypt"],"egy":["Egypt"],"el":["El Salvador"],"els":["El Salvador"],"eq":["Equatorial Guinea"],"equ":["Equatorial Guinea"],"er":["Eritrea"],"eri":["Eritrea"],"es":["Estonia"],"est":["Estonia"],"et":["Ethiopia"],"eth":["Ethiopia"],"f":["Falkland Islands (Malvinas)","Faroe Islands","Fiji","Finland","France","French Guiana","French Polynesia","French Southern Territories"],"fa":["Falkland Islands (Malvinas)","Faroe Islands"],"fal":["Falkland Islands (Malvinas)"],"far":["Faroe Islands"],"fi":["Fiji","Finland"],"fij":["Fiji"],"fin":["Finland"],"fr":["France","French Guiana","French Polynesia","French Southern Territories"],"fra":["France"],"fre":["French Guiana","French Polynesia","French Southern Territories"],"g":["Gabon","Gambia","Georgia","Germany","Ghana","Gibraltar","Greece","Greenland","Grenada","Guadeloupe","Guam","Guatemala","Guernsey","Guinea","Guinea-Bissau","Guyana"],"ga":["Gabon","Gambia"],"gab":["Gabon"],"gam":["Gambia"],"ge":["Georgia","Germany"],"geo":["Georgia"],"ger":["Germany"],"gh":["Ghana"],"gha":["Ghana"],"gi":["Gibraltar"],"gib":["Gibraltar"],"gr":["Greece","Greenland","Grenada"],"gre":["Greece","Greenland","Grenada"],"gu":["Guadeloupe","Guam","Guatemala","Guernsey","Guinea","Guinea-Bissau","Guyana"],"gua":["Guadeloupe","Guam","Guatemala"],"gue":["Guernsey"],"gui":["Guinea","Guinea-Bissau"],"guy":["Guyana"],"h":["Haiti","Heard Island and McDonald Islands","Holy See (Vatican City State)","Honduras","Hong Kong","Hungary"],"ha":["Haiti"],"hai":["Haiti"],"he":["Heard Island and McDonald Islands"],"hea":["Heard Island and McDonald Islands"],"ho":["Holy See (Vatican City State)","Honduras","Hong Kong"],"hol":["Holy See (Vatican City State)"],"hon":["Honduras","Hong Kong"],"hu":["Hungary"],"hun":["Hungary"],"i":["Iceland","India","Indonesia","Iran, Islamic Republic of","Iraq","Ireland","Isle of Man","Israel","Italy"],"ic":["Iceland"],"ice":["Iceland"],"in":["India","Indonesia"],"ind":["India","Indonesia"],"ir":["Iran, Islamic Republic of","Iraq","Ireland"],"ira":["Iran, Islamic Republic of","Iraq"],"ire":["Ireland"],"is":["Isle of Man","Israel"],"isl":["Isle of Man"],"isr":["Israel"],"it":["Italy"],"ita":["Italy"],"j":["Jamaica","Japan","Jersey","Jordan"],"ja":["Jamaica","Japan"],"jam":["Jamaica"],"jap":["Japan"],"je":["Jersey"],"jer":["Jersey"],"jo":["Jordan"],"jor":["Jordan"],"k":["Kazakhstan","Kenya","Kiribati","Korea, Democratic People's Republic of","Korea, Republic of","Kuwait","Kyrgyzstan"],"ka":["Kazakhstan"],"kaz":["Kazakhstan"],"ke":["Kenya"],"ken":["Kenya"],"ki":["Kiribati"],"kir":["Kiribati"],"ko":["Korea, Democratic People's Republic of","Korea, Republic of"],"kor":["Korea, Democratic People's Republic of","Korea, Republic of"],"ku":["Kuwait"],"kuw":["Kuwait"],"ky":["Kyrgyzstan"],"kyr":["Kyrgyzstan"],"l":["Lao People's Democratic Republic","Latvia","Lebanon","Lesotho","Liberia","Libyan Arab Jamahiriya","Liechtenstein","Lithuania","Luxembourg"],"la":["Lao People's Democratic Republic","Latvia"],"lao":["Lao People's Democratic Republic"],"lat":["Latvia"],"le":["Lebanon","Lesotho"],"leb":["Lebanon"],"les":["Lesotho"],"li":["Liberia","Libyan Arab Jamahiriya","Liechtenstein","Lithuania"],"lib":["Liberia","Libyan Arab Jamahiriya"],"lie":["Liechtenstein"],"lit":["Lithuania"],"lu":["Luxembourg"],"lux":["Luxembourg"],"m":["Macao","Macedonia, the former Yugoslav Republic of","Madagascar","Malawi","Malaysia","Maldives","Mali","Malta","Marshall Islands","Martinique","Mauritania","Mauritius","Mayotte","Mexico","Micronesia, Federated States of","Moldova, Republic of","Monaco","Mongolia","Montenegro","Montserrat","Morocco","Mozambique","Myanmar"],"ma":["Macao","Macedonia, the former Yugoslav Republic of","Madagascar","Malawi","Malaysia","Maldives","Mali","Malta","Marshall Islands","Martinique","Mauritania","Mauritius","Mayotte"],"mac":["Macao","Macedonia, the former Yugoslav Republic of"],"mad":["Madagascar"],"mal":["Malawi","Malaysia","Maldives","Mali","Malta"],"mar":["Marshall Islands","Martinique"],"mau":["Mauritania","Mauritius"],"may":["Mayotte"],"me":["Mexico"],"mex":["Mexico"],"mi":["Micronesia, Federated States of"],"mic":["Micronesia, Federated States of"],"mo":["Moldova, Republic of","Monaco","Mongolia","Montenegro","Montserrat","Morocco","Mozambique"],"mol":["Moldova, Republic of"],"mon":["Monaco","Mongolia","Montenegro","Montserrat"],"mor":["Morocco"],"moz":["Mozambique"],"my":["Myanmar"],"mya":["Myanmar"],"n":["Namibia","Nauru","Nepal","Netherlands","Netherlands Antilles","New Caledonia","New Zealand","Nicaragua","Niger","Nigeria","Niue","Norfolk Island","Northern Mariana Islands","Norway"],"na":["Namibia","Nauru"],"nam":["Namibia"],"nau":["Nauru"],"ne":["Nepal","Netherlands","Netherlands Antilles","New Caledonia","New Zealand"],"nep":["Nepal"],"net":["Netherlands","Netherlands Antilles"],"new":["New Caledonia","New Zealand"],"ni":["Nicaragua","Niger","Nigeria","Niue"],"nic":["Nicaragua"],"nig":["Niger","Nigeria"],"niu":["Niue"],"no":["Norfolk Island","Northern Mariana Islands","Norway"],"nor":["Norfolk Island","Northern Mariana Islands","Norway"],"o":["Oman"],"om":["Oman"],"oma":["Oman"],"p":["Pakistan","Palau","Palestinian Territory, Occupied","Panama","Papua New Guinea","Paraguay","Peru","Philippines","Pitcairn","Poland","Portugal","Puerto Rico"],"pa":["Pakistan","Palau","Palestinian Territory, Occupied","Panama","Papua New Guinea","Paraguay"],"pak":["Pakistan"],"pal":["Palau","Palestinian Territory, Occupied"],"pan":["Panama"],"pap":["Papua New Guinea"],"par":["Paraguay"],"pe":["Peru"],"per":["Peru"],"ph":["Philippines"],"phi":["Philippines"],"pi":["Pitcairn"],"pit":["Pitcairn"],"po":["Poland","Portugal"],"pol":["Poland"],"por":["Portugal"],"pu":["Puerto Rico"],"pue":["Puerto Rico"],"q":["Qatar"],"qa":["Qatar"],"qat":["Qatar"],"r":["Reunion","Romania","Russian Federation","Rwanda"],"re":["Reunion"],"reu":["Reunion"],"ro":["Romania"],"rom":["Romania"],"ru":["Russian Federation"],"rus":["Russian Federation"],"rw":["Rwanda"],"rwa":["Rwanda"],"s":["Saint Barthelemy","Saint Helena, Ascension and Tristan da Cunha","Saint Kitts and Nevis","Saint Lucia","Saint Martin (French part)","Saint Pierre and Miquelon","Saint Vincent and the Grenadines","Samoa","San Marino","Sao Tome and Principe","Saudi Arabia","Senegal","Serbia","Seychelles","Sierra Leone","Singapore","Slovakia","Slovenia","Solomon Islands","Somalia","South Africa","South Georgia and the South Sandwich Islands","Spain","Sri Lanka","Sudan","Suriname","Svalbard and Jan Mayen","Swaziland","Sweden","Switzerland","Syrian Arab Republic"],"sa":["Saint Barthelemy","Saint Helena, Ascension and Tristan da Cunha","Saint Kitts and Nevis","Saint Lucia","Saint Martin (French part)","Saint Pierre and Miquelon","Saint Vincent and the Grenadines","Samoa","San Marino","Sao Tome and Principe","Saudi Arabia"],"sai":["Saint Barthelemy","Saint Helena, Ascension and Tristan da Cunha","Saint Kitts and Nevis","Saint Lucia","Saint Martin (French part)","Saint Pierre and Miquelon","Saint Vincent and the Grenadines"],"sam":["Samoa"],"san":["San Marino"],"sao":["Sao Tome and Principe"],"sau":["Saudi Arabia"],"se":["Senegal","Serbia","Seychelles"],"sen":["Senegal"],"ser":["Serbia"],"sey":["Seychelles"],"si":["Sierra Leone","Singapore"],"sie":["Sierra Leone"],"sin":["Singapore"],"sl":["Slovakia","Slovenia"],"slo":["Slovakia","Slovenia"],"so":["Solomon Islands","Somalia","South Africa","South Georgia and the South Sandwich Islands"],"sol":["Solomon Islands"],"som":["Somalia"],"sou":["South Africa","South Georgia and the South Sandwich Islands"],"sp":["Spain"],"spa":["Spain"],"sr":["Sri Lanka"],"sri":["Sri Lanka"],"su":["Sudan","Suriname"],"sud":["Sudan"],"sur":["Suriname"],"sv":["Svalbard and Jan Mayen"],"sva":["Svalbard and Jan Mayen"],"sw":["Swaziland","Sweden","Switzerland"],"swa":["Swaziland"],"swe":["Sweden"],"swi":["Switzerland"],"sy":["Syrian Arab Republic"],"syr":["Syrian Arab Republic"],"t":["Taiwan, Province of China","Tajikistan","Tanzania, United Republic of","Thailand","Timor-Leste","Togo","Tokelau","Tonga","Trinidad and Tobago","Tunisia","Turkey","Turkmenistan","Turks and Caicos Islands","Tuvalu"],"ta":["Taiwan, Province of China","Tajikistan","Tanzania, United Republic of"],"tai":["Taiwan, Province of China"],"taj":["Tajikistan"],"tan":["Tanzania, United Republic of"],"th":["Thailand"],"tha":["Thailand"],"ti":["Timor-Leste"],"tim":["Timor-Leste"],"to":["Togo","Tokelau","Tonga"],"tog":["Togo"],"tok":["Tokelau"],"ton":["Tonga"],"tr":["Trinidad and Tobago"],"tri":["Trinidad and Tobago"],"tu":["Tunisia","Turkey","Turkmenistan","Turks and Caicos Islands","Tuvalu"],"tun":["Tunisia"],"tur":["Turkey","Turkmenistan","Turks and Caicos Islands"],"tuv":["Tuvalu"],"u":["Uganda","Ukraine","United Arab Emirates","United Kingdom","United States","United States Minor Outlying Islands","Uruguay","Uzbekistan"],"ug":["Uganda"],"uga":["Uganda"],"uk":["Ukraine"],"ukr":["Ukraine"],"un":["United Arab Emirates","United Kingdom","United States","United States Minor Outlying Islands"],"uni":["United Arab Emirates","United Kingdom","United States","United States Minor Outlying Islands"],"ur":["Uruguay"],"uru":["Uruguay"],"uz":["Uzbekistan"],"uzb":["Uzbekistan"],"v":["Vanuatu","Venezuela, Bolivarian Republic of","Viet Nam","Virgin Islands, British","Virgin Islands, U.S."],"va":["Vanuatu"],"van":["Vanuatu"],"ve":["Venezuela, Bolivarian Republic of"],"ven":["Venezuela, Bolivarian Republic of"],"vi":["Viet Nam","Virgin Islands, British","Virgin Islands, U.S."],"vie":["Viet Nam"],"vir":["Virgin Islands, British","Virgin Islands, U.S."],"w":["Wallis and Futuna","Western Sahara"],"wa":["Wallis and Futuna"],"wal":["Wallis and Futuna"],"we":["Western Sahara"],"wes":["Western Sahara"],"y":["Yemen"],"ye":["Yemen"],"yem":["Yemen"],"z":["Zambia","Zimbabwe"],"za":["Zambia"],"zam":["Zambia"],"zi":["Zimbabwe"],"zim":["Zimbabwe"]}
            },
            passwordHash: ["111111","11111111","112233","121212","123123","123456","1234567","12345678","131313","232323","654321","666666","696969","777777","7777777","8675309","987654","aaaaaa","abc123","abc123","abcdef","abgrtyu","access","access14","action","albert","alexis","amanda","amateur","andrea","andrew","angela","angels","animal","anthony","apollo","apples","arsenal","arthur","asdfgh","asdfgh","ashley","asshole","august","austin","badboy","bailey","banana","barney","baseball","batman","beaver","beavis","bigcock","bigdaddy","bigdick","bigdog","bigtits","birdie","bitches","biteme","blazer","blonde","blondes","blowjob","blowme","bond007","bonnie","booboo","booger","boomer","boston","brandon","brandy","braves","brazil","bronco","broncos","bulldog","buster","butter","butthead","calvin","camaro","cameron","canada","captain","carlos","carter","casper","charles","charlie","cheese","chelsea","chester","chicago","chicken","cocacola","coffee","college","compaq","computer","cookie","cooper","corvette","cowboy","cowboys","crystal","cumming","cumshot","dakota","dallas","daniel","danielle","debbie","dennis","diablo","diamond","doctor","doggie","dolphin","dolphins","donald","dragon","dreams","driver","eagle1","eagles","edward","einstein","erotic","extreme","falcon","fender","ferrari","firebird","fishing","florida","flower","flyers","football","forever","freddy","freedom","fucked","fucker","fucking","fuckme","fuckyou","gandalf","gateway","gators","gemini","george","giants","ginger","golden","golfer","gordon","gregory","guitar","gunner","hammer","hannah","hardcore","harley","heather","helpme","hentai","hockey","hooters","horney","hotdog","hunter","hunting","iceman","iloveyou","internet","iwantu","jackie","jackson","jaguar","jasmine","jasper","jennifer","jeremy","jessica","johnny","johnson","jordan","joseph","joshua","junior","justin","killer","knight","ladies","lakers","lauren","leather","legend","letmein","letmein","little","london","lovers","maddog","madison","maggie","magnum","marine","marlboro","martin","marvin","master","matrix","matthew","maverick","maxwell","melissa","member","mercedes","merlin","michael","michelle","mickey","midnight","miller","mistress","monica","monkey","monkey","monster","morgan","mother","mountain","muffin","murphy","mustang","naked","nascar","nathan","naughty","ncc1701","newyork","nicholas","nicole","nipple","nipples","oliver","orange","packers","panther","panties","parker","password","password","password1","password12","password123","patrick","peaches","peanut","pepper","phantom","phoenix","player","please","pookie","porsche","prince","princess","private","purple","pussies","qazwsx","qwerty","qwertyui","rabbit","rachel","racing","raiders","rainbow","ranger","rangers","rebecca","redskins","redsox","redwings","richard","robert","rocket","rosebud","runner","rush2112","russia","samantha","sammy","samson","sandra","saturn","scooby","scooter","scorpio","scorpion","secret","sexsex","shadow","shannon","shaved","sierra","silver","skippy","slayer","smokey","snoopy","soccer","sophie","spanky","sparky","spider","squirt","srinivas","startrek","starwars","steelers","steven","sticky","stupid","success","suckit","summer","sunshine","superman","surfer","swimming","sydney","taylor","tennis","teresa","tester","testing","theman","thomas","thunder","thx1138","tiffany","tigers","tigger","tomcat","topgun","toyota","travis","trouble","trustno1","tucker","turtle","twitter","united","vagina","victor","victoria","viking","voodoo","voyager","walter","warrior","welcome","whatever","william","willie","wilson","winner","winston","winter","wizard","xavier","xxxxxx","xxxxxxxx","yamaha","yankee","yankees","yellow","zxcvbn","zxcvbnm","zzzzzz"]
        }
    );
})(jQuery);
(function($) {
    
    $.extend(
        $.cf,
        {
            validation: {
                hasValue: function(value) {
                    return value !== null && value !== undefined && value !== '';
                },
                email: function(value) {
                    return /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i.test(value);
                },
                url: function(value) {
                    return /^(https?|ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(value);
                },
                date: function(value) {
                    return !/Invalid|NaN/.test(new Date(value));
                },
                dateISO: function(value) {
                    return /^\d{4}[\/-]\d{1,2}[\/-]\d{1,2}$/.test(value);
                },
                number: function(value) {
                    return /^-?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?$/.test(value);
                },
                digits: function(value) {
                    return /^\d+$/.test(value);
                },
                creditcard: function(value) {
                    
                    value = value.replace(/\D/g, '');
                    
                    if (!value || (/[^0-9-]+/.test(value) || (value.length < 14 || value.length > 18))) {
                        
                        return false;
                    }
                    
                    return true;
                    /*

                    var nCheck = 0,
                        nDigit = 0,
                        bEven = false;
                    
                    if(value.length == 16) {
                        for (var n = value.length - 1; n >= 0; n--) {
                            
                            var cDigit = value.charAt(n);
                            var nDigit = parseInt(cDigit, 10);
                            
                            if (bEven) {
                                if ((nDigit *= 2) > 9)
                                    nDigit -= 9;
                            }
                            
                            nCheck += nDigit;
                            bEven = !bEven;
                        }
                        
                        return (nCheck % 10) == 0;
                    }
                    
                    return false;
                    
                    */
                }
            },
            rating: {
                
                passwordStrength: function(value) {
                    
                    var lower = /[a-z]/.test(value),
                        upper = /[A-Z]/.test(value.substring(0, 1).toLowerCase() + value.substring(1)),
                        digit = /[0-9]/.test(value),
                        digits = /[0-9].*[0-9]/.test(value),
                        special = /[^a-zA-Z0-9]/.test(value),
                        same = /^(.)\1+$/.test(value);
                    
                    if(!value || value.length < 6 || $.inArray(value.toLowerCase(), $.cf.passwordHash) >= 0 || same) {
                        
                        return 0;
                    }
                    
                    if (((lower && upper && digit || lower && digit && special || upper && digit && special) && value.length>=8) || value.length>=20) {
                            
                        return 1;
                    }
                    
                    if ((lower && upper || lower && digit || upper && digit || lower && special || digit && special) && value.length>6) {
                        
                        return 0.66;
                    }
                    
                    
                    return 0.33;
                }
            },
            resolveCreditcardType: function(value) {
                
                value = value.replace(/\D/g, "");
                
                if(/^(51|52|53|54|55)/.test(value)) {
                    
                    return 'mastercard';
                }
                
                if(/^(4)/.test(value)) {
                    
                    return 'visa';
                }
                
                if(/^(34|37)/.test(value)) {
                    
                    return 'amex';
                }
                
                if(/^(6011)/.test(value)) {
                    
                    return 'discover';
                }
                
                return false;
            }
        }
    );
    
    $.extend(
        $.fn,
        {
            rateValue: function(options) {
                
                options = $.extend(
                    {
                        by: $.cf.rating.passwordStrength
                    },
                    options
                );
                
                this.each(
                    function(i, e) {
                        
                        var target = $(this);
                        
                        if(target.is('input[type="text"]') || target.is('input[type="password"]')) {
                            
                            var ratingIndicator = $('<div class="rating"></div>').insertAfter(target);
                            var ratingMask = $('<div class="mask"></div>').appendTo(ratingIndicator);
                            
                            target.bind(
                                'keyup blur',
                                function() {
                                    
                                    var rating = Math.min(options.by(target.val()), 1);
                                    
                                    ratingMask.fadeTo(100, Math.max(1 - Math.abs(rating), 0));
                                }
                            );
                            
                            target.bind(
                                'valid',
                                function() {
                                    
                                    ratingIndicator.removeClass('invalid');
                                }
                            );
                            
                            target.bind(
                                'invalid',
                                function() {
                                    
                                    ratingIndicator.addClass('invalid');
                                }
                            );
                        }
                    }
                );
            },
            valid: function(options) {
                
                options = $.extend(
                    {
                        iff: $.cf.validation.hasValue,
                        errorDisplayTarget: null
                    },
                    options
                );
                
                var errorTipSettings = { 'default': {
                    showOn: 'invalid',
                    hideOn: 'valid',
                    delay: 0,
                    offset: 0,
                    align: 'left',
                    backgroundColor: 'transparent',
                    textCSS: {
                        color: '#cc2929',
                        fontWeight: 'normal'
                    },
                    shadow: false,
                    autoPointer: false,
                    attributes: ['error'],
                    customContent: function(tip) {
                        
                        var text = tip.text();
                        tip.text('');
                        return $('<span class="cf-icon inline invalid"></span><span>' + text + '</span>');
                    }
                }};

                errorTipSettings['right-margin-top'] = $.extend(
                    {},
                    errorTipSettings['default'],
                    {
                        align: 'right-margin-top',
                        width: '210'
                    }
                );
                
                this.each(
                    function(i, e) {
                        
                        var target = $(this);
                        var tipTarget = options.errorDisplayTarget || target;
                        var resolveValue = function() {
                            
                            if(target.attr('type') == 'checkbox') {
                                return target.is(':checked');
                            } else {
                                return target.val();
                            }
                        }
                        
                        if(tipTarget != target) {
                            
                            tipTarget.attr('error', target.attr('error'));
                        }
                        
                        if(target.is('input') || target.is('textarea')) {
                            
                            var tipClass = /tooltip-([^ ]*)/.exec(target.attr('class'));
                            tipClass = tipClass && tipClass[1] in errorTipSettings ? tipClass[1] : 'default';

                            tipTarget.tooltip(errorTipSettings[tipClass]);
                            
                            target.data('validField', false);
                            
                            target.bind(
                                'keyup',
                                function(event) {
                                    
                                    var valid = options.iff(resolveValue());
                                    
                                    if(target.data('validField') && !valid) {
                                        
                                        target.data('validField', false).addClass('invalid');
                                        tipTarget.trigger('invalid');
                                    } else if(valid) {
                                        
                                        target.data('validField', true).removeClass('invalid');
                                        tipTarget.trigger('valid');
                                    }
                                }
                            );
                            
                            target.bind(
                                'blur',
                                function(event) {
                                    
                                    var valid = options.iff(resolveValue());
                                    
                                    if(valid) {
                                        
                                        target.data('validField', true).removeClass('invalid');
                                        tipTarget.trigger('valid');
                                    } else {
                                        
                                        target.data('validField', false).addClass('invalid');
                                        tipTarget.trigger('invalid');
                                    }
                                }
                            );
                        }
                    }
                );
                
                return this;
            },
            areValid: function() {
                
                var valid = true;
                
                this.blur();
                
                this.each(
                    function(i, e) {
                        
                        var target = $(this);
                        
                        if(target.data('validField') === false) {
                            return valid = false;
                        }
                    }
                );
                
                return valid;
            },
            resetValidation: function() {
                
                this.each(
                    function(i, e) {
                        
                        $(this).removeData('validField').removeClass('invalid').trigger('valid');
                    }
                )
            }
        }
    );
    
})(jQuery);

/*******************************************************************************
 *
 * CloudFlare UI core classes and utility methods.
 * 
 * @author Christopher Joel
 * 
 * Copyright 2010 CloudFlare, Inc.
 * 
 ******************************************************************************/

(function($) {

/*******************************************************************************
 *
 * Helper functions for determining dimensions, positions and other properties
 *
 ******************************************************************************/
    $.extend(
        $.cf,
        {
            windowProperties: function() {
                
                // TODO: X & Y are not reporting properly across all browsers..
                // TODO: Determine which properties to check based on cloudflare.client.js
                var width = 0;
                var height = 0;
                var x = 0;
                var y = 0;
                
                if (window.document.innerHeight && window.document.innerHeight > 0) {
                    width = window.document.innerWidth;
                    height = window.document.innerHeight;
                    x = window.pageXOffset;
                    y = window.pageYOffset;
                } else if (window.document.documentElement.clientHeight && window.document.documentElement.clientHeight > height) {
                    width = window.document.documentElement.clientWidth;
                    height = window.document.documentElement.clientHeight;
                    x = document.documentElement.scrollLeft;
                    y = document.documentElement.scrollTop;
                } else if (window.document.body.clientHeight && window.document.body.clientHeight > height) {
                    width = window.document.body.clientWidth;
                    height = window.document.body.clientHeight;
                    x = document.body.scrollLeft;
                    y = document.body.scrollTop;
                }
                
                return { width: width, height: height, x: x, y: y };
            },
            normalizeCSSMeasurement: function(measure) {
                
                measure = $.isFunction(measure) ? measure() : measure;
                
                if(typeof measure == 'number' || (typeof measure == 'string' && !(measure.substr(measure.length - 2, 2) == "px" || measure.substr(measure.length - 1, 1) == "%"))) {
                    
                    return measure + "px";
                    
                }
                
                return measure;
                
            },
            normalizeDigitalMeasurement: function(measure) {
                
                measure = $.isFunction(measure) ? measure() : measure;
                
                if(typeof measure == 'string') {
                    
                    if(measure.substr(measure.length - 2, 2) == "px") {
                        
                        return parseInt(measure.substr(0, measure.length - 2));
                        
                    } else if(measure.substr(measure.length - 1, 1) == "%") {
                        
                        return -1;
                        
                    }
                    
                    return parseInt(measure);
                    
                }
                
                return measure;
                
            }
        }
    );
    
    $.extend(
        $.fn,
        {
            margin: function() {
                
                var marginTop = this.css('marginTop').substr(0, this.css('marginTop').length - 2);
                var marginBottom = this.css('marginBottom').substr(0, this.css('marginBottom').length - 2);
                var marginLeft = this.css('marginLeft').substr(0, this.css('marginLeft').length - 2);
                var marginRight = this.css('marginRight').substr(0, this.css('marginRight').length - 2);
                
                return {
                    
                    top: marginTop,
                    bottom: marginBottom,
                    left: marginLeft,
                    right: marginRight,
                    horizontal: marginLeft + marginRight,
                    vertical: marginTop + marginBottom
                    
                };
            },
            
            marginalWidth: function() { return this.width() + this.margin().horizontal; },
            marginalInnerWidth: function() { return this.innerWidth() + this.margin().horizontal; },
            marginalOuterWidth: function() { return this.outerWidth() + this.margin().horizontal; },
            marginalHeight: function() { return this.height() + this.margin().vertical; },
            marginalInnerHeight: function() { return this.innerHeight() + this.margin().vertical; },
            marginalOuterHeight: function() { return this.outerHeight() + this.margin().vertical; },
            scrollTopMax: function() { return this.get(0).scrollHeight - this.innerHeight(); }
        }
    );
    
/*******************************************************************************
 *
 * CloudFlare Request & Multi-request
 *
 * Helper classes for containing information pertaining to ajax requests.
 * 
 ******************************************************************************/
    
    $.cf.Request = function(options) {
        
        $.extend(this, options);
        
    };
    
    $.cf.Request.prototype = {
        name: "",
        url: "",
        data: {},
        type: "GET",
        formatQuery: function(query) { 
            return query; 
        },
        formatResponse: function(response) { 
            this.lastResult = response; 
            return response; 
        },
        clone: function() {
            return $.extend({}, this);
        }
    };
    
    // TODO: Remove dependencies on this class, since it is useless...
    $.cf.MultiRequest = function(requests) {
        this.requests = requests ? requests : [];
    };
    
    $.cf.MultiRequest.prototype = {
        
        requests: [],
        addRequest: function(request) {
            if(request instanceof $.cf.Request) {
                
                this.requests.push(nameOrRequest);
                
            } else {
                
                this.requests.push(new $.cf.Request(request));
                
            }
        },
        clone: function() {
            return $.extend({}, this);
        }
    };

/*******************************************************************************
 *
 * CloudFlare Query
 *
 * The Query is an evolved version of the Request class, which acts as a
 * portable, fully self-contained AJAX mechanism to simplify and standardize
 * the calling of remote CloudFlare services. For the sake of simplicity, 
 * only JSON services are currently supported.
 * 
 ******************************************************************************/

    $.cf.Query = function(options) {
        var self = this;
        $.extend(self, options);
    };
    
    $.cf.Query.prototype = {
        id: "",
        url: "",
        data: {},
        type: "GET",
        async: true,
        cache: true,
        lastResponse: null,
        mapQuery: function(query) {
            return query.data;
        },
        mapResponse: function(response) {
            return response;
        },
        query: function(complete) {
            
            var self = this,
                atok = $('#ActionToken').length ? $('#ActionToken').val() : false;

            complete = complete ? complete : $.noop;

            if(self.url && self.url != "") {
                $.ajax(
                    {
                        url: self.url,
                        type: self.type,
                        async: self.async,
                        data: (function() {

                            var data = self.mapQuery(self);

                            if(atok) {
                                $.extend(
                                    data,
                                    {
                                        atok: atok
                                    }
                                );
                            }

                            return data;
                        })(),
                        dataType: 'json',
                        error: function() {
                            $.cf.log('There was an error making an AJAX call to ' + self.url, $.cf.logType.error);
                            complete(false);
                        },
                        success: function(json, status, xhr) {
                            
                            self.lastResponse = json;

                            if(json.result === 'error' && 'redirect' in json && json.redirect.details === 'invalid_atok') {

                                $.cf.notify('Your session needs to be refreshed, or your network settings have changed. Please refresh the page and try again. If the problem continues, please contact support!', $.cf.noteType.alert);
                                complete(false);
                            } else {

                                complete(self.mapResponse(json), self);
                            }
                        }
                    }
                );
            } else {
                
                complete(self.mapResponse(self.mapQuery(self)));
                
            }
        }
    };


/*******************************************************************************
 *
 * CloudFlare Widget
 * 
 * An abstract base class for all future CloudFlare UI Widgets.
 *
 ******************************************************************************/

    $.widget(
        'ui.cloudflareWidget',
        {
            invalidateOption: function(key) {
                
                var self = this;
                var property = '_invalidate' + key.substr(0, 1).toUpperCase() + key.substr(1, key.length - 1);
                
                if(property in self) {
                    
                    self[property]();
                    
                }
            }
        }
    );
    
})(jQuery);

/*******************************************************************************
 *
 * CloudFlare UI Billing Capture Widget
 * 
 * @author Jason Benterou
 * 
 * Copyright 2010 CloudFlare, Inc.
 * 
 ******************************************************************************/
 
(function($) {

    $.widget(
        'ui.billingCapture', 
        $.ui.cloudflareWidget,
        {
        
        // default options
        options: {
            
            // example prefill options:
            // - Name
            // - Country
            prefill: {},
            layout: 'default',
            compact: true,
            complete: $.noop
            
        },

        layouts: {

            'default': { },

            'dark': {
                tooltipClass: 'tooltip-right-margin-top'
            }
        },
        
        _create: function() {
            
            if (this.options) {
                
                var self = this;
                
                this.range = function range(x,y){ return x<=y ? [x].concat(range(x+1,y)) : [] };

                this.form = {
                    'Credit card information' : {
                        'CreditCard': {
                            label: 'Credit card #',
                            type: 'text',
                            'class': 'kilo creditcard required',
                            placeholder: 'xxxx xxxx xxxx xxxx',
                            error: 'This is not a valid credit card number',
                            context: 'Visa, Mastercard, AMEX, and Discover are accepted.'
                        },
                        'Name': {
                            label: 'Name on card',
                            type: 'text',
                            'class': 'mega required',
                            placeholder: 'e.g. John Q. Public',
                            error: 'The full name of the credit card owner is required'
                        },
                        'Expiration': {
                            label: 'Expiration date <span class="help">MM / YYY</span>',
                            type: 'expiration',
                            'class': 'required'
                        },
                        'CVV': {
                            label:'CVV / CVV2<span class="help cvv">(<a href="javascript:void(0)" tooltip="The CVV is a three or four digit number on the back of your credit or debit card">What\'s this?</a>)</span>',
                            type: 'text',
                            'class': 'milli required',
                            error: 'This is not a valid CVV'
                        }
                    },
                    'Billing address' : {
                        'Street': {
                            label: 'Street address',
                            type: 'text-double',
                            'class': 'mega',
                            error: 'You must provide a street address that is at least one line'
                        },
                        'City': {
                            label: 'City',
                            type: 'text',
                            'class': 'kilo',
                            error: 'You must indicate a valid city'
                        },
                        'State': {
                            label: 'State / province',
                            type: 'text',
                            'class': 'kilo',
                            error: 'You must indicate a state or province'
                        },
                        'Country': {
                            label: 'Country<span class="help country">(<a href="javascript:void(0)" tooltip="Your country of origin was predicted based on your IP address, but you can change it if it is incorrect">Why is this already filled?</a>)',
                            type: 'select',
                            'class': 'kilo',
                            placeholder: 'Select a country'
                        },
                        'Zip': {
                            label: 'Zip / postal code',
                            type: 'text',
                            'class': 'centi',
                            error: 'You must provide a valid zip or postal code'
                        },
                        'Tele': {
                            label: 'Telephone <span class="help">(optional)</span>',
                            type: 'text',
                            'class': 'kilo'
                        },
                        'CompanyName': {
                            label: 'Company Name <span class="help">(optional)</span>',
                            type: 'text',
                            'class': 'mega'
                        }
                    }
                };


                this.widgetElement = $('<div><a class="cancel" href="#">Cancel</a><form class="billing-capture" method="POST"></form></div>');
                this.formElement = this.widgetElement.find('form');

                this._buildForm();

                var countryControl = this.formElement.find('.billing-Country');

                $.cf.buildOptions(
                    countryControl,
                    {
                        data: $.cf.countryHash.unicodeCountry, 
                        placeholder: countryControl.attr('placeholder'),
                        selected: countryControl.data('selected')
                    }
                );

                this.formElement.find('select').combobox();
                this.formElement.find('select.billing-Country').combobox({
                    width: '235px'
                });


                this.register = new $.cf.Query(
                    {
                        url: '/ajax/account-management.html',
                        type: 'POST',
                        mapResponse: function(result) {
                            
                            if(result.result && result.result == 'success') {
                                
                                $.cf.notify('Billing information updated');
                                self._done();
                            } else if(result.result && result.result == 'error') {
                                
                                $.cf.notify(result.msg, $.cf.noteType.error);
                            } else {
                                
                                $.cf.notify('There was an error processing your request. If this problem persists, please contact us at <a href="mailto:help@cloudflare.com">help@cloudflare.com</a>', $.cf.noteType.error);
                            }
                            
                            return result;
                        }
                    }
                );

                this.doRegister = function() {

                    var f = function(key) {
                        return self.formElement.find('.billing-'+key);
                    };

                    $.extend(
                        this.register.data,
                        {
                            act: 'billing_set',
                            billing_first: f('Name').val().substring(0, f('Name').val().indexOf(' ')),
                            billing_last: $.trim(f('Name').val().substring(f('Name').val().indexOf(' ') + 1, f('Name').val().length)),
                            billing_addr1: f('StreetOne').val(),
                            billing_addr2: f('StreetTwo').val(),
                            billing_city: f('City').val(),
                            billing_state: f('State').val(),
                            billing_zip: f('Zip').val(),
                            billing_country: f('Country').val(),
                            billing_company: f('CompanyName').val(),
                            billing_tele: f('Tele').val(),
                            cc_card_number: f('CreditCard').val().replace(/\D/g, ''),
                            cc_card_exp_month: f('ExpirationMonth').val(),
                            cc_card_exp_year: f('ExpirationYear').val(),
                            cc_card_code: f('CVV').val()
                        }
                    );
                    
                    if(this.formElement.find('input').areValid()) {

                        this.register.query();
                        $.cf.notify('Updating your billing information...');
                    }
                };

                var onsubmit = function() {

                    self.doRegister();
                    return false;
                };

                this.formElement.bind('submit', onsubmit);
                this.formElement.find('.button').bind('click', onsubmit);

                this.widgetElement.find('.cancel').bind(
                    'click',
                    function() {

                        self._cancel();
                        return false;
                    }
                );

                this.widgetElement.hide().appendTo(this.element);
                
                //this.element.append(this.widgetElement);

                this.refresh();
                
                this.widgetElement.slideDown();

                this.enable();
            }
            
        },
    	
    	_buildForm: function() {

            var self = this,
                html = '';

            $.each(

                this.form,
                function(section, rows) {

                    var rowsHtml = '';
                    $.each(rows, function() {
                        rowsHtml += self._buildRow.apply(self, arguments);
                    });
                    html += '<h3>'+section+'</h3>' + '<div class="form' + (self.options.compact ? ' compact' : '') +'">' + rowsHtml + '</div>';
            });

            html += '<div class="row last">' +
                '<div class="cell float-right">' +
                    '<a class="button green" tabindex="1" href="#">' +
                        '<span class="label">Submit</span>' +
                    '</a>' +
                '</div>';

            this.formElement.append(html);

            var f = function(key) {
                return self.formElement.find('.billing-'+key);
            };

            f('Name').valid({
                iff: function(value) {
                    
                    return $.cf.validation.hasValue(value) && value.split(' ').length > 1;
                }
            });
            
            f('City').valid();
            f('State').valid();
            f('Country').valid();

            f('StreetOne').valid(
                {
                    errorDisplayTarget: f('StreetTwo')
                }
            );
            
            f('CreditCard').valid({ iff: $.cf.validation.creditcard });
            
            f('ExpirationYear').valid({
                iff: function(value) {
                    return $.cf.validation.number(value) && value.length == 4 && parseInt(value) > 2009;
                }
            });
            
            f('CVV').valid({
                iff: function(value) {
                    return $.cf.validation.number(value) && (value.length == 3 || value.length == 4);
                }
            });
            
            f('Zip').valid();
    	   
    	},

        _buildRow: function(key, data) {
            
            var html = '<div class="row">',
                cell = function(cl, text) {
                    return text ? '<div class="'+cl+' cell">'+text+'</div>' : '';
                },
                attr = function(key, val) {
                    return val ? key + '="' + val + '" ' : '';
                },
                option = function(n) {
                    return '<option value="'+n+'">'+n+'</option>';
                },
                tooltipClass = this.layouts[this.options.layout].tooltipClass || '',
                inputs = '';

            switch (data.type) {

                case 'expiration':
                    var y = new Date().getFullYear();
                    inputs = cell('input', '' +
                        '<select name="'+key+'Month" ' +
                        attr('class', 'billing-' + key + 'Month ' + data['class'] + ' ' + tooltipClass) +
                        attr('tabindex', '1') + '>' +
                        $.map(this.range(1,12), option).join('') +
                        '</select>') +
                        cell('input', '/') +
                        cell('input', '' +
                        '<select name="'+key+'Year" ' + 
                        attr('class', 'billing-' + key + 'Year ' + data['class'] + ' ' + tooltipClass) + 
                        attr('tabindex', '1') + '>' +
                        $.map(this.range(y, y+10), option).join('') +
                        '</select>');

                break;
                case 'select':
                    inputs = cell('input', '' +
                        '<select name="'+key+'" ' +
                            attr('class', 'billing-' + key + ' ' + data['class'] + ' ' +  tooltipClass) +
                            attr('placeholder', data.placeholder) +
                            attr('tabindex','1') + '>' +
                        '</select>');
                break;
                case 'text-double':
                    inputs = cell('input', '' +
                        '<input name="'+key+'One" ' +
                            attr('type', 'text') +
                            attr('class', 'billing-' + key + 'One ' +data['class'] + ' ' + tooltipClass) +
                            attr('placeholder', data.placeholder) +
                            attr('error', data.error) +
                            attr('tabindex', '1') +
                        '/>' +
                        '<input name="'+key+'Two" ' +
                            attr('type', 'text') +
                            attr('class', 'billing-' + key + 'Two ' +data['class'] + ' ' + tooltipClass) +
                            attr('tabindex', '1') +
                        '/>');

                break;
                case 'text':
                default:
                    inputs = cell('input', '' +
                        '<input name="'+key+'" ' +
                            attr('type', data.type) +
                            attr('class', 'billing-' + key + ' ' + data['class'] + ' ' + tooltipClass) +
                            attr('placeholder', data.placeholder) +
                            attr('error', data.error) +
                            attr('tabindex', '1') +
                        '/>');
                    break;
            }

            return '<div class="row">' +
                    cell('label', data.label) +
                    inputs +
                    cell('context', data.context) +
                '</div>';
        },
        
        refresh: function(instant) {
            
        },
        
        
        widget: function() {
            
            return this.widgetElement;
            
        },
        
        enable: function() {
            
            this.enabled = true;
            
        },
        
        disable: function() {
            
            this.enabled = false;
            
        },
        
        _cancel: function() {

            this.options.complete(false);

            this.destroy();
        },

        _done: function() {

            this.options.complete(true);

            this.destroy();
        },
            
        destroy: function() {

            $.Widget.prototype.destroy.apply(this, arguments); // default destroy

            this.widgetElement.remove();
            
        }
        
    });
    
})(jQuery);

/*******************************************************************************
 *
 * CloudFlare UI Table Tray Widget
 * 
 * @author Jason Benterou
 * 
 * Copyright 2010 CloudFlare, Inc.
 *
 * Creates a new table row (<tr>) with class cf-tray.
 *
 * If target is a <tr>, tray is inserted as a sibling
 * If target is a <tbody> or <table> with <tr> children,
 *  tray is appended as a new child
 * 
 ******************************************************************************/
 
(function($) {

    $.widget(
        'ui.rowTray', 
        $.ui.cloudflareWidget,
        {
        
        // default options
        options: {
            skeleton: '<td class="left"></td><td class="middle"></td><td class="right"></td>',

            onClose: function(e) {

                e.data.widget.hide();
            }
        },
        
        _create: function() {
            
            if (this.options) {
                
                var self = this,
                    el = this.element;
                    close = $('<div class="cf-tray-close cancel">close</div>');
                
                this.widgetElement = $(
                    '<tr class="cf-tray">' + this.options.skeleton + '</tr>'
                );

                this.widgetElement.find('.right').append(close);

                close.click({widget: this.widgetElement}, this.options.onClose);

                if (el.is('tr')) {

                    this.widgetElement.insertAfter(el);
                } else if (el.is('tbody') || el.is('table') && el.children('tr').length) {

                    this.widgetElement.appendTo(el);
                } else {

                    $('<table></table>').append(this.widgetElement).appendTo(el);
                }

                this.enable();

                return this.widgetElement;
            }
            
        },
        
        
        widget: function() {
            
            return this.widgetElement;
            
        },
        
        enable: function() {
            
            this.enabled = true;
            
        },
        
        disable: function() {
            
            this.enabled = false;
            
        },
        
        _cancel: function() {

            this.options.complete(false);

            this.destroy();
        },

        _done: function() {

            this.options.complete(true);

            this.destroy();
        },
            
        destroy: function() {

            $.Widget.prototype.destroy.apply(this, arguments); // default destroy

            this.widgetElement.remove();
            
        }
        
    });
    
})(jQuery);

/*******************************************************************************
 *
 * CloudFlare UI Toggle Selector
 * 
 * @author Christopher Joel
 * 
 * Copyright 2010 CloudFlare, Inc.
 * 
 ******************************************************************************/
 
(function($) {

    $.widget(
        'ui.toggleSelector', 
        $.ui.cloudflareWidget,
        {
        
        // default options
        options: {
            
            onLabel: "On",
            offLabel: "Off"
            
        },
        
        _create: function() {
            
            if (this.options) {
                
                var self = this;
                
                this.toggleElementStructure = $('<div><div class="left"><div></div></div><div class="right"><div></div></div><div class="fill"><div class="left"></div><div class="middle"><div class="left"></div><div class="middle"></div><div class="right"></div></div><div class="right"></div></div></div><ul><li class="left"></li><li class="right"></li></ul>');
                
                this._resolveToggleElement();
                
                if(this.elementIsCheckbox) {
                    
                    this.element.addClass('ui-helper-hidden-accessible');
                    this.checked = this.element.is(':checked');
                    
                } else {
                    
                    this.checked = false;
                    
                }
                
                this.toggleElement.addClass('cf-ui').addClass('toggle');
                this.toggleElement.append(this.toggleElementStructure);
                
                this.toggleElement.find('li').first().text(this.options.onLabel);
                this.toggleElement.find('li').last().text(this.options.offLabel);
                
                this.toggleElement.css(
                    {
                        width: (this.toggleElement.find('li').text().length) * 8 + 100 + "px"
                    }
                );
                
                this.toggleElement.find('div.fill > div.left, div.fill > div.right').css(
                    {
                        width: this.toggleElement.find('div.fill > div.left').width() + 5 + "px"
                    }
                );
                
                this.toggleElement.find('div.fill > div.middle').css(
                    {
                        width: this.toggleElement.find('div.fill > div.middle').width() - 10 + "px",
                        left: Math.floor(this.toggleElement.find('div.fill > div.left').width()) + "px",
                        right: Math.floor(this.toggleElement.find('div.fill > div.right').width()) + "px"
                    }
                );
                
                this.toggleElement.find('div.fill').css(
                    {
                        left: (this.toggleElement.width() - (this.toggleElement.find('div.fill > div.left').width() + this.toggleElement.find('div.fill > div.middle').width()) - 5) + "px"
                    }
                );
                
                this.toggleElement.bind(
                    'click', 
                    function() {
                        
                        if(self.enabled) {
                            
                            if(self.elementIsCheckbox) {
                                
                                self.element.click();
                                
                            } else {
                                
                                self.refresh();
                                
                            }
                            
                        }
                    }
                );
                
                if(this.elementIsCheckbox) {
                    
                    this.element.bind(
                        'change',
                        function() {
                            
                            if(self.enabled) {
                                
                                self.refresh();
                                
                            }
                            
                        }
                    );
                    
                }
                
                
                this.refresh();
                
                this.enable();
            }
            
        },
        
        _resolveToggleElement: function() {
            
            var self = this;
            
            if(self.element.is(':checkbox')) {
                
                self.elementIsCheckbox = true;
                self.toggleElement = self.element.after($('<div></div>')).next();
                
            } else {
                
                self.toggleElement = self.element;
                
            }
            
    	},
    	
    	_resolveChecked: function() {
    	   
    	   var self = this;
    	   
    	   if(self.elementIsCheckbox) {
    	       
    	       self.checked = self.element.is(':checked');
    	       
    	   } else {
    	       
    	       self.checked = !self.checked;
    	       
    	   }
    	   
    	},
        
        refresh: function(instant) {
            
            var self = this;
            
            self._resolveChecked();
            
            var leftFinal = this.checked ? 
                (-1 * this.toggleElement.find('div.fill > div.left').width()) + 5 + "px" :
                (this.toggleElement.width() - (this.toggleElement.find('div.fill > div.left').width() + this.toggleElement.find('div.fill > div.middle').width()) - 5) + "px";
            
            if(instant === true) {
                this.toggleElement.find('div.fill').stop().css(
                    {
                        left: leftFinal
                    }
                );
            } else {
                this.toggleElement.find('div.fill').stop().animate(
                    {
                        left: leftFinal
                    },
                    400,
                    'swing'
                );
            }
            
        },
        
        
        widget: function() {
            
            return this.toggleElement;
            
        },
        
        enable: function() {
            
            this.enabled = true;
            
        },
        
        disable: function() {
            
            this.enabled = false;
            
        },
        
        destroy: function() {
            
            
            //$.Widget.prototype.destroy.apply(this, arguments); // default destroy
            // now do other stuff particular to this widget
            
        }
        
    });
    
})(jQuery);

/*******************************************************************************
 *
 * CloudFlare UI Data List
 * 
 * @author Christopher Joel
 * 
 * Copyright 2010 CloudFlare, Inc.
 * 
 * @deprecated
 * 
 ******************************************************************************/

(function($) {
    
    $.widget('ui.dataList', {
        
        options: {
            
            effectDirection: 'right', // 'left' or 'right'
            buttons: [], // [{title: "Title", callback: Function}]
            expandTo: function(dataList, listItem) {
                
                var listItemContents = listItem.find('div.list-item')
                var heightOffset = (listItemContents.innerHeight() - listItemContents.height());
                var marginTop = listItemContents.css('marginTop');
                var marginBottom = listItemContents.css('marginBottom');
                
                var marginOffset = parseInt(marginTop.substr(0, marginTop.length - 2)) + parseInt(marginBottom.substr(0, marginBottom.length - 2));
                
                return dataList.height() - heightOffset - marginOffset - 1;
                
            },
            formatInner: function(inner, itemValue) {
                
                inner.text(itemValue);
                
            }
            
        },
        
        _internalSettings: {
            
            selfClasses: 'cf-ui data-list ul-corner-all',
            liClasses: 'list-item ui-corner-all',
            innerStub: '<div></div>'
            
        },
        
        _create: function() {
            
            var self = this;
            
            if(self.element.is('ul')) {
                
                self.element.wrap('<div></div>');
                self.element.wrap('<div class="list-container"></div>')
                
                self.dataList = self.element.parent().parent();
                self.dataList.append('<div class="viewport-container"><div class="viewport"></div></div>');
                self.dataList.addClass(self._internalSettings.selfClasses);
                
                self.listContainer = self.dataList.children('div.list-container');
                self.viewportContainer = self.dataList.children('div.viewport-container');
                self.viewportContainer.hide();
                
                self.expandedItemIndex = -1;
                self.lastSelectedIndex = self.selectedIndex = -1;
                self.lastSelectedItem = self.selectedItem = null;
                
                self.lastScrollTop = 0;
                self.itemExpanded = false;
                
                self.ieQuirks = $.msie && parseInt($.browser.version.substr(0, 1)) < 8 && parseInt($.browser.version.substr(0, 1)) > 5;
                
                self._formatListItems(self.element.find('li'));
                
                for(var i = 0; i < self.options.buttons.length; i++) {
                    
                    self._addButtonToItems(self.options.buttons[i].title, self.options.buttons[i].callback, self.element.children('li'));
                    
                }
                
            } else {
                
                self.destroy();
                
            }
            
        },
        
        _formatListItems: function(listItems) {
            
            var self = this;
            
            listItems.each(
                function(index, element) {
                    
                    var listItem = $(element);
                    
                    if(listItem.children().length > 0) {
                        
                        listItem.children().wrapAll('<div class="value"></div>');
                        
                    } else {
                        
                        var listItemContent = listItem.text();
                        listItem.empty();
                        listItem.append('<div class="value">' + listItemContent + '</div>');
                        
                    }
                    
                    listItem.children('div.value').wrap('<div class="list-item ui-corner-all"></div>');
                    listItem.children('div.list-item').append('<a class="hit"></a>')
                    listItem.children('div.list-item').append('<div class="buttons"></div>');
                    listItem.children('div.list-item').append('<div class="inner"></div>');
                    
                    var clickTarget = listItem.children('div.list-item').children('a.hit');
                    var hoverTarget = self.ieQuirks ? listItem.children('div.list-item').children('a.hit') : listItem.children('div.list-item');
                    
                    clickTarget.bind(
                        'click',
                        function() {
                            
                            self._selectItem(listItem);
                            
                        }
                    );
                    
                    hoverTarget.bind(
                        'mouseover',
                        function() {
                            
                            listItem.children().first().addClass('active');
                            
                        }
                    );
                    
                    hoverTarget.bind(
                        'mouseout',
                        function() {
                            
                            listItem.children().first().removeClass('active');
                            
                        }
                    );
                }
            );
            
            
        },
        
        _selectItem: function(listItem) {
            
            var self = this;
            
            self.lastSelectedIndex = self.selectedItem ? self.selectedItem.index() : -1;
            self.lastSelectedItem = self.selectedItem;
            
            self.selectedIndex = listItem.index();
            self.selectedItem = listItem;
            
            self._invalidateExpanded();
            
        },
        
        _invalidateExpanded: function() {
            
            var self = this;
            
            if(self.itemExpanded && self.lastSelectedItem != null) {
                
                self._collapseItem();
                
            } else {
                
                self._expandItem(
                    self.selectedItem, 
                    function(contents) {
                        
                        if(self.options.formatInner) {
                            
                            self.options.formatInner(
                                
                                contents.find('div.inner').first(),
                                contents.find('div.value')
                                
                            )
                            
                        }
                        
                    }
                );
                
            }
            
        },
        
        _expandItem: function(listItem, callback) {
            
            var self = this;
            
            var expandToHeight = self.options.expandTo(self.dataList, listItem);
            var listItemContents = listItem.children().first().clone(true);
            var listItemPosition = listItem.position();            
            var listItemTop = listItemPosition.top - parseInt(self.listContainer.scrollTop()) - 4;
            var listItemViewport = self.viewportContainer.children('div.viewport');
            var clickTarget = listItemContents.find('a.hit').first();
            
            self.expandedItemIndex = listItem.index();
            self.lastScrollTop = self.listContainer.scrollTop();
            self.lastItemTop = listItemTop;
            
            self.viewportContainer.show();
            self.listContainer.fadeOut(150);
            
            listItemViewport.stop(true, true).empty();
            
            listItemViewport.css(
                {
                    left: '0px',
                    top: (listItemTop + 'px'),
                    width: '100%'
                }
            ).append(listItemContents);
            
            listItemViewport.animate(
                {
                    top: '0px'
                },
                400,
                function() {
                    
                    listItemContents.animate(
                        {
                            height: expandToHeight
                        },
                        400,
                        function() {
                            
                            if(callback) {
                                
                                listItemContents.find('div.inner').first().css(
                                    {
                                        // mmm i can has magic number? 24!
                                        height: (listItemContents.height() - 24) + "px"
                                    }
                                );
                                
                                callback(listItemContents);
                                
                            }
                            
                        }
                    );
                    
                }
            );
            
            self.itemExpanded = true;
            
        },
        
        _collapseItem: function(callback) {
            
            var self = this;
            
            var listItemViewport = self.viewportContainer.children('div.viewport').first();
            var listItemContent = listItemViewport.children().first();
            var listItemInner = listItemViewport.children().first().children('div.inner');
            
            
            listItemInner.fadeOut(150, function() {
                
                listItemInner.remove();
                    
                    listItemContent.animate(
                    {
                        height: '16px'
                    },
                    
                    400,
                    
                    function() {}
                    
                );
                
                listItemViewport.animate(
                    {
                        top: self.lastItemTop + 'px'
                    },
                    400,
                    function() {
                        
                        
                        self.listContainer.fadeIn(300, function() {
                            
                            listItemViewport.empty().css(
                                {
                                    
                                    width: '0px'
                                    
                                }
                            );
                            
                            self.viewportContainer.hide();
                            
                            if(callback != null && callback != undefined) {
                                
                                callback();
                                
                            }
                            
                        
                        });
                        
                        self.listContainer.scrollTop(self.lastScrollTop);
                        
                    }
                );
                
            })
            
            
            
            self.itemExpanded = false;
            
            
        },
        
        _destroyItem: function(listItem) {
            
            var self = this;
            
            var listItemContents = listItem.children().first().clone();
            var listItemPosition = listItem.position();            
            var listItemTop = listItemPosition.top - parseInt(self.listContainer.scrollTop()) - 4;
            var listItemViewport = self.viewportContainer.children('div.viewport');
            
            listItemViewport.stop(true, true).empty();
            
            listItemViewport.css(
                {
                    left: '0px',
                    top: (listItemTop + 'px'),
                    width: '100%'
                }
            ).append(listItemContents);
            
            self.viewportContainer.show();
            
            listItem.css(
                
                {
                    visibility: 'hidden'
                }
                
            );
            
            listItem.slideUp(250, function() {
                
                self.viewportContainer.hide();
                listItem.remove();
                
            });
            
            listItemViewport.animate(
                (
                    self.options.effectDirection == 'left' ?
                    {
                        left: '-150%'
                    } :
                    {
                        left: '150%'
                    }
                ),
                250
            );
            
        },
        
        _addButtonToItems: function(title, callback, items) {
            
            var self = this;
            
            items.each(function(index, element) {
                
                var listItem = $(element);
                var elementValue = listItem.find('div.value').first();
                
                var button = $('<a href="javascript:void(0);" class="list-item-button">' + title + '</a>');
                
                button.button();
                button.css({
                    
                    fontSize: '12px'
                    
                });
                
                button.bind(
                    'click',
                    function() {
                        
                        callback(listItem.index(), elementValue);
                        
                    }
                );
                
                listItem.find('div.buttons').eq(0).append(button);
                
            });
            
        },
        
        _addButtonToContents: function(index, contents) {
            
            var self = this;
            
            var buttonContainer = contents.find('div.buttons').first();
            
            buttonContainer.empty();
            
            for(var i = 0; i < self.options.buttons.length; i++) {
                
                var title = self.options.buttons[i].title;
                var callback = self.options.buttons[i].callback;
                
                var button = $('<a href="javascript:void(0);" class="list-item-button">' + title + '</a>');
            
                button.button();
                button.css({
                    
                    fontSize: '12px'
                    
                });
                
                button.bind(
                    'click',
                    function() {
                        
                        callback(index, contents.find('div.value').first());
                        
                    }
                );
                
                buttonContainer.append(button);
                
            }
            
        },
        
        getIndexOfValue: function(value) {
            
            var self = this;
            var result = false;
            
            var items = self.element.children('li');
            
            for(var i = 0; !result && i < items.length; i++) {
                
                result = items.eq(i).find('div.value').first().text() == value;
                
            }
            
            return result ? i - 1 : -1;
            
        },
        
        addItem: function(value) {
            
            var self = this;
            
            var listItem = $('<li>' + value + '</li>');
            
            self.element.append(listItem);
            self._formatListItems(listItem);
            
            for(var i = 0; i < self.options.buttons.length; i++) {
                
                self._addButtonToItems(self.options.buttons[i].title, self.options.buttons[i].callback, listItem);
                
            }
            
            var listItemContents = listItem.children().first().clone();
            var listItemPosition = listItem.position();            
            var listItemTop = listItemPosition.top - parseInt(self.listContainer.scrollTop()) - 4;
            var listItemViewport = self.viewportContainer.children('div.viewport');
            
            listItemViewport.stop(true, true).empty();
            
            listItemViewport.css(
                {
                    left: self.options.effectDirection == 'left' ? '-150%' : '150%',
                    top: (listItemTop + 'px'),
                    width: '100%'
                }
            ).append(listItemContents);
            
            self.viewportContainer.show();
            
            listItem.css(
                
                {
                    visibility: 'hidden'
                }
                
            );
            
            self.listContainer.animate(
                {
                    scrollTop: self.element.height() - self.listContainer.height()
                },
                200,
                function() {
                    
                    listItemViewport.animate(
                        (
                            {
                                left: '0px'
                            }
                        ),
                        250,
                        function() {
                            
                            self.viewportContainer.hide();
                            listItem.css(
                                {
                                    visibility: 'visible'
                                }
                            );
                        }
                    );
                }
            );
            
            self.listContainer.scrollTop();
            
        },
        
        addUniqueItem: function(value) {
            
            var self = this;
            
            if(self.getIndexOfValue(value) == -1) {
                
                self.addItem(value);
                
            }
            
        },
        
        removeItem: function(value) {
            
            var self = this;
            
            var valueIndex = self.getIndexOfValue(value);
            
            if(valueIndex != -1) {
                
                self.removeItemAt(valueIndex);
                
            }
            
            
        },
        
        removeItemAt: function(index) {
            
            
            var self = this;
            var listItem = self.element.children('li').eq(index);
            
            if(self.itemExpanded) {
                
                self._collapseItem(function() {
                    
                    self._destroyItem(listItem);
                    
                });
                
            } else {
                
                self._destroyItem(listItem);
                
            }
            
            
        },
        
        destroy: function() {
            
            
            
        }
    
    });
    
})(jQuery);
/*******************************************************************************
 *
 * CloudFlare UI Marked Selector
 * 
 * @author Christopher Joel
 * 
 * Copyright 2010 CloudFlare, Inc.
 * 
 ******************************************************************************/

(function($) {
    
    $.widget(
        'ui.markedSelector', 
        {
            
            options: {
                
                activeClass: 'active',
                activeIndex: null,
                animated: true
                
            },
            
            _create: function() {
                
                var self = this;
                
                if(self.element.is('ul')) {
                    
                    self.selector = $('<div class="markerContainer"></div>');
                    self.element.prepend(self.selector);
                    
                    self.element.addClass(self._resolveWidgetClasses());
                    
                    self.activeMarker = null;
                    self.hoverMarker = null;
                    
                    self.element.children('li.' + self.options.activeClass).addClass('active');
                    self.options.activeClass = self.options.activeClass == 'active' ? 'active' : 'active ' + self.options.activeClass;
                                        
                    self.element.children('li').bind(
                        'mouseenter',
                        function(event) {
                            
                            var item = $(event.currentTarget);
                            
                            if(item.is('li:not(.active)')) {
                                
                                var marginLeft = parseInt(item.css('marginLeft').substr(0, item.css('marginLeft').length - 2));
                                var marginTop = parseInt(item.css('marginTop').substr(0, item.css('marginTop').length - 2));
                                
                                if(self.hoverMarker == null) {
                                    
                                    self.hoverMarker = self._resolveMarker();
                                    self.hoverMarker.addClass('hover marker');
                                    
                                    self.selector.prepend(self.hoverMarker);
                                    
                                    self.hoverMarker.css(
                                        {
                                            left: item.position().left + marginLeft + 'px',
                                            top: item.position().top + marginTop + 'px',
                                            width: item.outerWidth() + 'px',
                                            height: item.outerHeight() + 'px'
                                        }
                                    );
                                    
                                    self.hoverMarker.hide().fadeIn(200);
                                }
                                
                                self.hoverMarker.stop(false).animate(
                                    {
                                        left: item.position().left + marginLeft + 'px',
                                        top: item.position().top + marginTop + 'px',
                                        width: item.outerWidth() + 'px',
                                        height: item.outerHeight() + 'px',
                                        opacity: 1
                                    },
                                    200
                                );
                            } else {
                                
                                self._killHoverMarker();
                            }
                        }
                    ).bind(
                        'click',
                        function(event) {
                            
                            var item = $(event.currentTarget);
                            
                            if(item.is('li')) {
                                
                                self.selectItem(item);
                                
                            }
                        }
                    );
                    
                    self.element.bind(
                        
                        'mouseleave',
                        function(event) {
                            
                            var item = $(event.currentTarget);
                            
                            if(item.is('ul')) {
                                
                                self._killHoverMarker();
                            }
                        }
                    );
                    
                    if(self.options.activeIndex != null) {
                        
                        self.selectItem(self.options.activeIndex);
                        
                    } else {
                
                        self.element.children('li.active').each(
                            function(i, e) {
                                
                                self.selectItem(e);
                                
                            }
                        );
                    }
                    
                } else {
                    
                    self.destroy();
                }
            },
            
            _resolveWidgetClasses: function() {
                
                var self = this;
                
                return 'cf-ui selector' + (self.options.extraClass && self.options.extraClass != '' ? self.options.extraClass : '');
            },
            
            _resolveMarker: function() {
                
                return $('<div></div>');
            },
            
            _killHoverMarker: function() {
                
                var self = this;
                
                if(self.hoverMarker != null) {
                    
                    var deadMarker = self.hoverMarker;
                    self.hoverMarker = null;
                    
                    deadMarker.stop().fadeOut(
                        200, 
                        function() {
                            
                            deadMarker.remove();
                            
                        }
                    );
                }
            },
            
            selectItem: function(item) {
                
                var self = this;
                var item = typeof item == 'number' ? self.element.children('li').eq(item) : $(item);
                var index = typeof item == 'number' ? item : item.index() - self.element.children('li').index();

                self.element.children('li').not(item).removeClass(self.options.activeClass);
                item.addClass(self.options.activeClass);

                var marginLeft = parseInt(item.css('marginLeft').substr(0, item.css('marginLeft').length - 2));
                var marginTop = parseInt(item.css('marginTop').substr(0, item.css('marginTop').length - 2));
                
                if(self.activeMarker == null) {
                    
                    self.activeMarker = self._resolveMarker();
                    self.activeMarker.addClass('active marker');
                    
                    self.selector.prepend(self.activeMarker);
                    
                    self.activeMarker.css(
                        {
                            left: item.position().left + marginLeft + 'px',
                            top: item.position().top + marginTop + 'px',
                            width: item.outerWidth() + 'px',
                            height: item.outerHeight() + 'px'
                        }
                    );
                    
                    self.activeMarker.hide().fadeIn(200);
                }
                
                if(self.options.animated) {
                    
                    self.activeMarker.stop(false).animate(
                        {
                            left: item.position().left + marginLeft + 'px',
                            top: item.position().top + marginTop + 'px',
                            width: item.outerWidth() + 'px',
                            height: item.outerHeight() + 'px',
                            opacity: 1
                        },
                        200,
                        function() {
                            self._trigger(
                                'selected',
                                $.Event('selected'),
                                {
                                    item: item,
                                    index: index
                                }
                            );
                        }
                    );
                } else {
                    
                    self.activeMarker.stop(false).css(
                        {
                            left: item.position().left + marginLeft + 'px',
                            top: item.position().top + marginTop + 'px',
                            width: item.outerWidth() + 'px',
                            height: item.outerHeight() + 'px',
                            opacity: 1
                        }
                    );
                    
                    self._trigger(
                        'selected',
                        $.Event('selected'),
                        {
                            item: item,
                            index: index
                        }
                    );
                }
                
                self._killHoverMarker();
                
                self.selectedItem = item;
                
            },
            
            deselect: function() {
                
                var item = self.selectedItem;
                
                var deadMarker = self.activeMarker;
                self.activeMarker = null;
                
                deadMarker.fadeOut(200, function() {
                    
                    deadMarker.remove();
                    
                });
                
                self.selectedItem = null;
                
            },
            
            destroy: function() {
                
                
                
            }
        }
    );
    
    
    $.widget('ui.markedNavigation', $.ui.markedSelector, {
        
        _create: function() {
            
            $.ui.markedSelector.prototype._create.apply(this, arguments);
            
        },
        
        _resolveWidgetClasses: function() {
            
            return $.ui.markedSelector.prototype._resolveWidgetClasses.apply(this, arguments) + ' navigation';
            
        },
        
        _resolveMarker: function() {
            
            return $('<div><div class="left"></div><div class="right"></div></div>');
            
        }
        
    });
    
})(jQuery);
/*******************************************************************************
 *
 * CloudFlare UI Dashboard Module
 * 
 * @author Christopher Joel
 * 
 * Copyright 2010 CloudFlare, Inc.
 * 
 ******************************************************************************/
 
(function($) {
    
    $.widget(
        'ui.dashboardModule',
        $.ui.cloudflareWidget,
        {
            options: {
                
                width: 320,
                height: 240,
                title: "Untitled Module",
                loading: false
                
            },
            
            _setOption: function(key, value) {
                
                var self = this;
                
                self.options[key] = value;
                
                self.invalidateOption(key);
                
            },
            
            _create: function() {
                
                var self = this;
                
                if(self.element.is('div')) {
                    
                    self.element.addClass('cf-ui new-dashboard-module');
                    
                    self.content = self.element.children();
                    
                    if(self.content.length > 0) {
                        
                        self.content.wrapAll('<div class="content"><div class="inner"></div></div>');
                        
                    } else {
                        
                        self.element.append('<div class="content"><div class="inner></div></div>');
                        
                    }
                    
                    self.overlay = $('<div class="overlay"><div class="inner"></div></div>').appendTo(self.element);
                    self.overlay.hide();
                    
                    self.loadingActivated = false;
                    
                    self._invalidateWidth(true);
                    self._invalidateHeight(true);
                    self._invalidateLoading(true);
                    self._invalidateTitle();
                    
                    return true;
                    
                }
                    
                self.destroy();
                return false;
                
            },
            
            destroy: function() {
                
                var self = this;
                
                self.element.removeClass('cf-ui new-dashboard-module');
                self.overlay.remove();
                self.content.detach();
                self.element.empty().append(self.content);
                
            },
            
            _activateLoading: function() {
                
                var self = this;
                
                if(!self.loadingActivated) {
                    
                    self.overlay.children().first().append('<p>Loading...</p>');
                    self.loadingActivated = true;
                    
                }
            },
            
            _deactivateLoading: function() {
                
                var self = this;
                
                if(self.loadingActivated) {
                    
                    self.overlay.children().first().empty();
                    self.loadingActivated = false;
                    
                }
            },
            
            _invalidateLoading: function(instant) {
                
                var self = this;
                
                if(instant) {
                    
                    self.options.loading ? self.overlay.show() : self.overlay.hide();
                    
                } else {
                    
                    self.options.loading ? self.overlay.stop().fadeIn(400) : self.overlay.stop().fadeOut(400);
                    
                }
                
                self.options.loading ? self._activateLoading() : self._deactivateLoading();
                
            },
            
            _invalidateWidth: function(instant) {
                
                var self = this;
                
                self._invalidateDimensions(instant);
                
            },
            
            _invalidateHeight: function(instant) {
                
                var self = this;
                
                self._invalidateDimensions(instant);
                
            },
            
            _invalidateDimensions: function(instant) {
                
                var self = this;
                
                var options = {
                    width: $.cf.normalizeCSSMeasurement(self.options.width),
                    height: $.cf.normalizeCSSMeasurement(self.options.height)
                };
                
                instant ? self.element.css(options) : self.element.animate(options, 200);
                
            },
            
            _invalidateTitle: function() {
                // Abstract...
            }
        }
    );
    
    $.widget(
        'ui.panel',
        $.ui.dashboardModule,
        {
            options: {
                filters: [],
                controls: []
            },
            _create: function() {
                
                var self = this;
                
                self.loaderID = 'PanelLoader-' + (self.options.title.replace(/ /g, '_')) + '-' + Math.floor(((new Date()).getTime() * Math.random()));
                
                $.ui.dashboardModule.prototype._create.apply(this, arguments)
                
                self.element.addClass('panel')
                self.titleBar = $('<div class="titleBar"><div class="inner"></div></div>').prependTo(self.element);
                self.title = $('<div class="title"><h1></h1></div>').appendTo(self.titleBar.children().first());
                self.controls = $('<div class="controls"></div>').appendTo(self.titleBar.children().first());
                
                self._invalidateTitle();
                self._invalidateControls();
            },
            
            _invalidateTitle: function() {
                
                var self = this;
                
                if(self.title) {
                    
                    self.title.children().first().text(self.options.title);
                    
                }
            },
            
            _invalidateControls: function() {
                
                var self = this;
                
                self.controls.empty();
                
                $.each(
                    self.options.controls,
                    function(i, c) {
                        
                        $(c).appendTo(self.controls);
                        
                        if($(c).is('select')) {
                            $(c).combobox();
                        }
                    }
                );
            },
            
            _activateLoading: function() {
                
                var self = this;
                
                if(!self.loadingActivated) {
                    
                    self.overlay.children().first().append($('<div id="' + self.loaderID + '"></div>'));
                    
                    $('#' + self.loaderID).embedFlash(
                        {
                            source: '/media/flash/cloudflare.loader.swf', 
                            width: 138, 
                            height: 62, 
                            cssClass: 'flashLoader', 
                            params: {
                                wmode: "transparent"
                            }
                        }
                    );
                    
                    self.loadingActivated = true;
                    
                }
            },
            
            _deactivateLoading: function() {
                
                var self = this;
                
                if(self.loadingActivated) {
                    
                    swfobject.removeSWF(self.loaderID);
                    $('div#' + self.loaderID).remove();
                    
                    self.loadingActivated = false;
                    
                }
            }
        }
    );
})(jQuery);
/*******************************************************************************
 *
 * CloudFlare UI Dashboard
 * 
 * @author Christopher Joel
 * 
 * Copyright 2010 CloudFlare, Inc.
 * 
 * TODO: Dashboard needs to be rebuilt with more abstraction and custom sorting
 * functionality.
 * 
 ******************************************************************************/

(function($) {
/*
    
    $.widget('ui.dashboardModule', {
        
        options: {
            
            width: 320,
            height: 240,
            title: "Untitled Module",
            loading: false
            
        },
        
        _internalSettings: {
            
            selfClasses: 'cf-ui dashboard-module',
            innerStub: '<div class="head"><div class="title"></div></div><div class="overlay"><div class="background scale9"><div class="top"><div class="left"></div><div class="middle"></div><div class="right"></div></div><div class="center"><div class="left"></div><div class="middle"></div><div class="right"></div></div><div class="bottom"><div class="left"></div><div class="middle"></div><div class="right"></div></div><img src="/media/images/ui/module/module-background-center.png" width="100%" height="100%" /></div></div><div class="content"><div class="background scale9"><div class="top"><div class="left"></div><div class="middle"></div><div class="right"></div></div><div class="center"><div class="left"></div><div class="middle"></div><div class="right"></div></div><div class="bottom"><div class="left"></div><div class="middle"></div><div class="right"></div></div><img src="/media/images/ui/module/module-content-background-center.png" width="100%" height="100%" /></div><div class="body"></div></div><div class="background scale9"><div class="top"><div class="left"></div><div class="middle"></div><div class="right"></div></div><div class="center"><div class="left"></div><div class="middle"></div><div class="right"></div></div><div class="bottom"><div class="left"></div><div class="middle"></div><div class="right"></div></div><img src="/media/images/ui/module/module-background-center.png" width="100%" height="100%" /></div>'
            
        },
        
        _create: function() {
            
            var self = this;
            
            if(self.element.is('div')) {
                
                if(self.element.children().length == 0) {
                    
                    self.moduleContents = self.element.text();
                    
                } else {
                    
                    self.moduleContents = self.element.children();
                    self.moduleContents.detach();
                    
                }
                
                self.element.empty();
                
                self.element.append($(self._internalSettings.innerStub));
                self.element.addClass(self._internalSettings.selfClasses);
                
                self.moduleLoadingOverlay = self.element.find('div.overlay');
                self.moduleLoadingOverlayAttached = true;
                self.moduleLoadingFlashContainerID = 'DashboardLoader-' + self.options.title.replace(/ /g, '_') + '-' + (new Date()).getTime();
                
                self._detachLoadingOverlay();
                
                self.element.find('div.head div.title').text(self.options.title);
                self.element.find('div.content div.body').append(self.moduleContents);
                
                self._invalidateDimensions(true);
                self._invalidateLoading(true);
                
                
            } else {
                
                self.destroy();
                
            }
            
        },
        
        _setOption: function(key, value) {
            
            $.Widget.prototype._setOption.apply(this, arguments);
            
            var self = this;
            
            self._invalidateDimensions();
            self._invalidateLoading();
            
        },
        
        _invalidateDimensions: function(instant) {
            
            var self = this;
            
            instant = instant || ($.browser.msie && parseInt($.browser.version.substr(0, 1)) < 8 && parseInt($.browser.version.substr(0, 1)) > 5);
            
            if(instant) {
                
                self.element.css(
                    {
                        width: self.options.width < 200 ? 200 : (self.options.width + 'px'),
                        height: self.options.height < 150 ? 150 : (self.options.height + 'px')
                    }
                );
                
                if($.browser.msie && parseInt($.browser.version.substr(0, 1)) <= 7 && parseInt($.browser.version.substr(0, 1)) >= 6) {
                    
                    self.element.find('div.body').width(self.element.find('div.body').width());
                    self.element.find('div.body').height(self.element.find('div.body').height());
                    
                }
                
            } else {
                
                self.element.stop(false).animate(
                    {
                        width: self.options.width < 200 ? 200 : (self.options.width + 'px'),
                        height: self.options.height < 150 ? 150 : (self.options.height + 'px')
                    },
                    700,
                    "swing"
                );
                
            }
            
        },
        
        _attachLoadingOverlay: function() {
            
            var self = this;
            
            if(!self.moduleLoadingOverlayAttached) {
                
                self.moduleLoadingOverlay.append($('<div id="' + self.moduleLoadingFlashContainerID + '"></div>'));
                        
                self.element.prepend(self.moduleLoadingOverlay);
                
                $('#' + self.moduleLoadingFlashContainerID).embedFlash(
                    {
                        source: '/media/flash/cloudflare.loader.swf', 
                        width: 138, 
                        height: 62, 
                        cssClass: 'flashLoader', 
                        params: {
                            wmode: "transparent"
                        }
                    }
                );
                
                self.moduleLoadingOverlayAttached = true;
                
                self.element.addClass('loading');
                
            }
            
        },
        
        _detachLoadingOverlay: function() {
            
            var self = this;
            
            if(self.moduleLoadingOverlayAttached) {
                
                swfobject.removeSWF(self.moduleLoadingFlashContainerID);
                $('div#' + self.moduleLoadingFlashContainerID).remove();
                
                self.moduleLoadingOverlay.stop().hide().detach();
                
                self.moduleLoadingOverlayAttached = false;
                
                self.element.removeClass('loading');
                
            }
            
        },
        
        _invalidateLoading: function(instant) {
            
            var self = this;
            
            if(self.options.loading) {
                
                self._attachLoadingOverlay();
                
                if(instant) {
                    
                    self.moduleLoadingOverlay.show();
                    
                } else {
                    
                    self.moduleLoadingOverlay.fadeIn(700);
                    
                }
                
            } else {
                
                if(instant) {
                    
                    self._detachLoadingOverlay();
                    
                } else {
                    
                    self.moduleLoadingOverlay.fadeOut(
                        700, 
                        function() {
                            
                            self._detachLoadingOverlay();
                            
                        }
                    );
                    
                }
                
            }
                        
        },
        
        destroy: function() {
            
            
            
        }
        
        
    });

*/

/*******************************************************************************
 *
 * CloudFlare UI Dashboard
 * 
 ******************************************************************************/


    $.widget('ui.dashboard', {
        
        options: {
            
            cellWidth: 320,
            cellHeight: 240,
            sortable: false
            
        },
        
        _internalSettings: {
            
            selfClasses: 'cf-ui dashboard',
            placeholderClasses: '',
            outerStub: '<div></div>'
            
        },
        
        _create: function() {
            
            var self = this;
            
            if(self.element.is('ul')) {
                
                self.element.wrap('<div></div>');
                self.dashboard = self.element.parent();
                
            } else {
                
                self.dashboard = self.element;
                
            }
            
            if(self.dashboard.children('ul').length == 0) {
                
                self.dashboard.prepend('<ul></ul>');
                
            }
            
            self.dashboard.addClass(self._internalSettings.selfClasses);
            
            self.sortable = self.dashboard.children().first();
            self.sortableInstantiated = false;
            
            self.sortable.children('li').addClass(self._moduleContainerClasses());
            
            self.invalidate();
            
            
        },
        
        _invalidateSortable: function() {
            
            var self = this;
            
            if(self.options.sortable && self.sortable && !self.sortableInstantiated) {
                
                self.sortable.sortable(
                    {
                        
                        placeholder: self._modulePlaceholderClasses(),
                        tolerance: 'pointer',
                        forceHelperSize: true,
                        forcePlaceholderSize: true,
                        revert: 200,
                        helper: function(event, element) {
                            
                            return element.clone().css('opacity', 0.5);
                            
                        }
                    }
                );
                
                self.sortableInstantiated = true;
                
            } else if(!self.options.sortable && self.sortable && self.sortableInstantiated) {
                
                self.sortable.sortable('destroy');
                
                self.sortableInstantiated = false;
                
            }
            
        },
        
        _invalidateMeasurements: function() {
            
            var self = this;
            
            self.sortable.children('li.module').css(
                {
                    
                    width: self._moduleContainerWidth() + 'px',
                    height: self._moduleContainerHeight() + 'px'
                    
                }
            );
            
            self.dashboard.css(
                {
                    
                    width: self._dashboardWidth() + 'px',
                    height: self._dashboardHeight() + 'px'
                    
                }
            );
            
        },
        
        _moduleContainerClasses: function() {
            
            return 'module';
            
        },
        
        _modulePlaceholderClasses: function() {
            
            var self = this;
            
            return self._moduleContainerClasses() + ' placeholder';
            
        },
        
        _dashboardWidth: function() {
            
            var self = this;
            
            return self.dashboard.parent().width() - (self.dashboard.outerWidth() - self.dashboard.width());
            
        },
        
        _dashboardHeight: function() {
            
            var self = this;
            
            return Math.ceil(self.sortable.children('li.module').length / Math.floor(self._dashboardWidth() / (self._moduleMeasuredWidth()))) * self._moduleMeasuredHeight();
            
        },
        
        _moduleContainerWidth: function() {
            
            var self = this;
            
            if(self.sortable.children('li.module').length > 0) {
                
                var module = self.sortable.children('li.module').first();
                var marginLeft = module.css('marginLeft');
                var marginRight = module.css('marginLeft');
                var marginOffset = parseInt(marginLeft.substr(0, marginLeft.length - 2)) + parseInt(marginRight.substr(0, marginRight.length - 2));
                
                return self.options.cellWidth - marginOffset;
                
            } else {
                
                return 0;
                
            }
            
        },
        
        _moduleContainerHeight: function() {
            
            var self = this;
            
            if(self.sortable.children('li.module').length > 0) {
                
                var module = self.sortable.children('li.module').first();
                var marginTop = module.css('marginTop');
                var marginBottom = module.css('marginBottom');
                var marginOffset = parseInt(marginTop.substr(0, marginTop.length - 2)) + parseInt(marginBottom.substr(0, marginBottom.length - 2));
                
                return self.options.cellHeight - marginOffset;
                
            } else {
                
                return 0;
                
            }
            
        },
        
        _moduleMeasuredWidth: function() {
            
            var self = this;
            
            if(self.sortable.children('li.module').length > 0) {
                
                var module = self.sortable.children('li.module').first();
                var marginLeft = module.css('marginLeft');
                var marginRight = module.css('marginLeft');
                var marginOffset = parseInt(marginLeft.substr(0, marginLeft.length - 2)) + parseInt(marginRight.substr(0, marginRight.length - 2));
                
                return module.outerWidth() + marginOffset;
                
            } else {
                
                return 0;
                
            }
        
        },
        
        _moduleMeasuredHeight: function() {
            
            var self = this;
            
            if(self.sortable.children('li.module').length > 0) {
                
                var module = self.sortable.children('li.module').first();
                var marginTop = module.css('marginTop');
                var marginBottom = module.css('marginBottom');
                var marginOffset = parseInt(marginTop.substr(0, marginTop.length - 2)) + parseInt(marginBottom.substr(0, marginBottom.length - 2));
                
                return module.outerHeight() + marginOffset;
                
            } else {
                
                return 0;
                
            }
            
        },
        
        invalidate: function() {
            
            var self = this;
            
            self._invalidateSortable();
            self._invalidateMeasurements();
            
        },
        
        addModule: function(moduleContent) {
            
            var self = this;
            
            var listItem = $('<li></li>');
            console.log('add');
            listItem.prepend(moduleContent);
            listItem.addClass(self._moduleContainerClasses());
            
            self.sortable.append(listItem);
            
            self._invalidateMeasurements();
            
        },
        
        destroy: function() {
            
            
            
        }
    
    });
    
/*******************************************************************************
 *
 * CloudFlare UI Generic Dashboard
 * 
 ******************************************************************************/

    $.widget('ui.genericDashboard', $.ui.dashboard, {
        
        _create: function() {
            
            $.ui.dashboard.prototype._create.apply(this, arguments);
            
            var self = this;
            
            self.dashboard.addClass('generic cf-ui-corner-all-six');
            
            self.invalidate();
            
        },
        
        _moduleContainerClasses: function() {
            
            return 'generic cf-ui-corner-all-four ' + $.ui.dashboard.prototype._moduleContainerClasses.apply(this, arguments);
            
        }
        
    });

})(jQuery);
/*******************************************************************************
 *
 * CloudFlare UI List Item Renderers
 * 
 * @author Christopher Joel
 * 
 * Copyright 2010 CloudFlare, Inc.
 * 
 ******************************************************************************/

(function($) {

    $.widget(
        'ui.listItemRenderer',
        $.ui.cloudflareWidget,
        {
            options: {
                data: { label: "I has no data!" }
            },
            
            _create: function() {
                
                var self = this;
                
                if(self.element.is('li')) {
                    
                    self.element.addClass('cf-ui list-item-renderer');
                    if (self.options.disabled) {
                        self.element.addClass('disabled');
                    }
                    self.element.data('itemRenderer', self.widgetName);
                    self._invalidateStructure();
                    self._invalidateData();
                    
                } else {
                    
                    return false;
                    
                }
            },
            
            _invalidateStructure: function() {
                
                var self = this;
                
                self.element.empty();
                self.element.append('<a><span class="label"></span></a>');
                
            },
            
            _invalidateData: function() {
                
                var self = this;
                
                for(var i in self.options.data) {
                    self.element.find('.' + i).empty().text(self.options.data[i]);
                }
            }
        }
    );
    
    $.widget(
        'ui.nullItemRenderer',
        $.ui.listItemRenderer,
        {
            _create: function() {
                
                $.ui.listItemRenderer.prototype._create.apply(this, arguments);
                
                var self = this;
                
                self.element.addClass('null-item-renderer');
                
            },
            _invalidateStructure: function() {
                
                var self = this;
                
                self.element.empty();
                self.element.append('<span class="label"></span>');
                
            }
        }
    );
    
    
    $.widget(
        'ui.comboboxItemRenderer',
        $.ui.listItemRenderer,
        {
            _create: function() {
                
                $.ui.listItemRenderer.prototype._create.apply(this, arguments);
                
                var self = this;
                
                self.element.addClass('combobox-item-renderer');
                
            }
        }
    );
    
    $.widget(
        'ui.comboboxCriticalItemRenderer',
        $.ui.comboboxItemRenderer,
        {
            _create: function() {
                
                $.ui.comboboxItemRenderer.prototype._create.apply(this, arguments);
                
                var self = this;
                
                self.element.addClass('critical');
                
            }
        }
    );
    
    $.widget(
        'ui.comboboxDisabledItemRenderer',
        $.ui.comboboxItemRenderer,
        {
            _create: function() {
                
                var self = this;

                self.options.disabled = true;

                $.ui.comboboxItemRenderer.prototype._create.apply(this, arguments);

            }
        }
    );
    
    $.widget(
        'ui.lookingGlassItemRenderer',
        $.ui.listItemRenderer,
        {
            _create: function() {
                
                $.ui.listItemRenderer.prototype._create.apply(this, arguments);
                
                var self = this;
                
                self.element.addClass('looking-glass-item-renderer');
                
            },
            _invalidateStructure: function() {
                
                var self = this;
                
                self.element.empty();
                self.element.append('<a><span class="label"></span></a><span class="summary"></span>');
                
            }
        }
    );
    
    $.widget(
        'ui.actionableListItemRenderer',
        $.ui.listItemRenderer,
        {
            options: $.extend(
                {
                    buttons: []
                },
                $.ui.listItemRenderer.prototype.options
            ),
            _create: function() {
                
                $.ui.listItemRenderer.prototype._create.apply(this, arguments);
                
                var self = this;
                
                self.element.addClass('actionable-item-renderer');
                self._invalidateButtons();
                
            },
            _invalidateStructure: function() {
                
                var self = this;
                
                self.element.empty();
                
                self.buttonContainer = $('<ul class="buttons"></ul>').appendTo(self.element);
                
            },
            _invalidateButtons: function() {
                
                var self = this;
                
                $.each(
                    self.options.buttons,
                    function(i, b) {
                        self.buttonContainer.append(
                            $('<li class="button ' + b.title + '"><a>' + b.title + '</a></li>').tooltip(
                                {
                                    text: b.tip,
                                    delay: 1000
                                }
                            ).bind(
                                'click',
                                function(event) {
                                    
                                    event.stopImmediatePropagation();
                                    
                                    self.triggerAction(
                                        b.title,
                                        event
                                    );
                                }
                            )
                        );
                    }
                );
            },
            triggerAction: function(action, event) {
                
                var self = this;
                
                if(action) {
                    
                    event = event ? event : $.Event('itemaction');
                    
                    self._trigger(
                        'itemaction',
                        event,
                        {
                            action: action,
                            item: self.element,
                            data: self.options.data
                        }
                    );
                }
            },
            destroy: function() {
                
                var self = this;
                
                self.buttonContainer.find('li').each(
                    function(i, b) {
                        $(b).clearTooltip();
                    }
                );
            }
        }
    );
    
    $.widget(
        'ui.threatListItemRenderer',
        $.ui.actionableListItemRenderer,
        {
            options: {
                buttons: [
                    {
                        title: 'block',
                        tip: 'Block this visitor and override CloudFlare defaults'
                    },
                    {
                        title: 'trust',
                        tip: 'Trust this visitor and override CloudFlare defaults'
                    },
                    {
                        title: 'dismiss',
                        tip: 'Dismiss this alert'
                    }
                ]
            },
            _create: function() {
                
                $.ui.actionableListItemRenderer.prototype._create.apply(this, arguments);
                
                var self = this;
                
                self.element.addClass('threat-item-renderer');
                
            },
            _invalidateStructure: function() {
                
                $.ui.actionableListItemRenderer.prototype._invalidateStructure.apply(this, arguments);
                
                var self = this;
                
                self.inner = $('<a></a>').appendTo(self.element);
                self.outer = self.element;
                
                self.propertySection = $('<div class="splitter properties"></div>').appendTo(self.inner);
                self.priority = $('<div class="group priority"><div class="cf-icon inner priority white"></div></div>').appendTo(self.propertySection).tooltip({text: "This is a high priority threat alert"});
                self.category = $('<div class="group category label"></div>').appendTo(self.propertySection);
                self.threatScore = $('<div class="group threatScore label"></div>').appendTo(self.propertySection).tooltip({text: "The level of threat posed by this visitor"});
                
                self.dateSection = $('<div class="splitter date"></div>').appendTo(self.inner);
                self.date = $('<span class="label date"></span>').appendTo(self.dateSection).tooltip({text: "Date of last visit to one of your websites"});
                
                self.idSection = $('<div class="splitter id"></div>').appendTo(self.inner);
                self.idType = $('<span class="strong label id-type"></span>').appendTo(self.idSection);
                self.idValue = $('<span class="label id-value"></span>').appendTo(self.idSection);
                
                self.countrySection = $('<div class="splitter country"></div>').appendTo(self.inner);
                
                self.statusSection = $('<div class="splitter status"></div>').appendTo(self.inner);
                self.pathway = $('<div class="group pathway"></div>').appendTo(self.statusSection);
                self.status = $('<span class="strong label status"></span>').appendTo(self.statusSection);
                    
            },
            _invalidateData: function() {
                
                var self = this;
                
                if(self.options.data.priority) {
                    self.element.addClass('priority');
                } else {
                    self.element.removeClass('priority');
                }
                
                var categoryValues = (function(unformatted) {
                    
                    if(typeof unformatted == 'string') {
                        
                        unformatted = unformatted.toUpperCase();
                    }
                    
                    switch(unformatted) {
                        case 'BZ':
                            return {
                                label: "Botnet Zombie",
                                tip: "Visitor exhibits behavior consistent with a machine infected with a virus"
                            }
                        case 'RB':
                            return {
                                label: "Rule Breaker",
                                tip: "Visitor broke rules such as crawling too fast or ignoring robots.txt"
                            };
                        case 'H':
                            return {
                                label: "Harvester",
                                tip: "Visitor was caught stealing email addresses on other sites"
                            };
                        case 'WS':
                            return {
                                label: "Web Spammer",
                                tip: "Visitor was caught posting comment / blog spam on other sites"
                            };
                        case 'XA':
                            return {
                                label: "Exploit Attacker",
                                tip: "Visitor was caught attempting to hack other sites"
                            };
                        case 'SE':
                            return {
                                label: "Search Engine",
                                tip: null
                            };
                        // Special case for custom rules
                        case 'CR':
                            return {
                                label: "Custom Rule",
                                tip: "This rule was created by you and can be edited on the Threat Control page"
                            };
                        default:
                            return {
                                label: "Unidentified threat",
                                tip: "We were unable to retrieve specific information about this threat at this time"
                            };
                    }
                    
                })(self.options.data.category);
                
                self.category.clearTooltip();
                self.category.text(categoryValues.label.toUpperCase());
                
                if(categoryValues.tip) {
                    self.category.tooltip(
                        {
                            text: categoryValues.tip,
                            width: 350
                        }
                    );
                }
                
                if(self.options.data.threatScore) {
                    
                    self.threatScore.show();
                    self.threatScore.text(self.options.data.threatScore);
                } else {
                    
                    self.threatScore.hide();
                }
                
                if(self.options.data.date) {
                    
                    self.date.text(new Date(self.options.data.date * 1000).toDateString());
                } else {
                    
                    self.date.text(self.options.data.dateString);
                }
                
                self.idType.text(self.options.data.idFormat.toUpperCase() + ": ");
                self.idValue.empty().clearTooltip();
                
                var idLabel = self.options.data.id;
                switch(self.options.data.idFormat.toLowerCase()) {
                    case "country":
                        self.idValue.append('<div class="cf-icon flag ' + self.options.data.id.toLowerCase() + '"></div>');
                        self.idValue.tooltip(
                            {
                                text: $.cf.countryHash.unicodeCountry[self.options.data.id.toUpperCase()],
                                offset: 11
                            }
                        );
                        break;
                    case "ip":
                        // Hackity hack... this is bad because an itemrenderer should
                        // not make assumptions about arbitrary data it is *not* expecting..
                        if(!self.options.data.hasOwnProperty('grp')) {
                            
                            //self.idValue.tooltip({text: "The IP address of this visitor"});
                        }

                        if(idLabel.length > 19) idLabel = idLabel.substring(0, 19) + '...';

                    case "ip range":
                        
                        self.idValue.text(idLabel);
                        if(!self.options.data.hasOwnProperty('grp')) {
                            
                            //self.idValue.tooltip({text: "The IP address of this visitor"});
                            //$.cf.log('Text: ' + self.idValue.text());
                            self.idValue.copyToClipboard(
                                {
                                    copyText: self.options.data.id
                                }
                            );
                        }
                        break;
                    default:
                        break;
                }
                
                if(self.options.data.country) {
                    
                    self.countrySection.show();
                    self.countrySection.empty().append('<div class="cf-icon flag ' + self.options.data.country.toLowerCase() + '"></div>');
                    self.countrySection.clearTooltip().tooltip(
                        {
                            text: "Country of origin: " + $.cf.countryHash.unicodeCountry[self.options.data.country.toUpperCase()],
                            offset: 11
                        }
                    );
                } else {
                    
                    self.countrySection.hide();
                }
                
                self.pathway.empty();
                
                var pathwayValues = function(pathway) {
                    
                    switch(pathway) {
                        case 4:
                            return {
                                label: "BLOCKED",
                                tip: "This entity has been blocked by you"
                            };
                        case 3:
                            return {
                                label: "TRUSTED",
                                tip: "This entity has been trusted by you"
                            };
                        case 2:
                            return {
                                label: "LEFT MESSAGE",
                                tip: "Visitor was challenged, passed the CAPTCHA and left you a message"
                            };
                        case 1:
                            return {
                                label: "PASSED CAPTCHA",
                                tip: "Visitor was challenged but passed the CAPTCHA"
                            };
                        case 0:
                            return {
                                label: "CHALLENGED",
                                tip: "Visitor was presented with a CAPTCHA but did not pass it"
                            };
                        case -1:
                            return {
                                label: "NOT CHALLENGED",
                                tip: "Increase your security settings to challenge potential threats like this one"
                            };
                        default:
                            return null;
                    }
                };
                
                if(pathwayValues(self.options.data.pathway)) {
                    
                    self.status.text(pathwayValues(self.options.data.pathway).label.toUpperCase());
                    self.status.tooltip(
                        {
                            text: pathwayValues(self.options.data.pathway).tip,
                            offset: 10
                        }
                    );
                    
                    switch(self.options.data.pathway) {
                        // Custom path for block
                        case 4:
                            
                            $('<div class="cf-icon list inner shield white"></div>').prependTo(self.pathway).tooltip(
                                {
                                    text: pathwayValues(4).tip,
                                    offset: 13
                                }
                            );
                            
                            break;
                        // Custom path for trust
                        case 3:
                            
                            $('<div class="cf-icon list inner check white"></div>').prependTo(self.pathway).tooltip(
                                {
                                    text: pathwayValues(3).tip,
                                    offset: 13
                                }
                            );
                            
                            break;
                        case 2:
                            
                            $('<div class="cf-icon list inner mail white"></div>').prependTo(self.pathway).tooltip(
                                {
                                    text: "Message: \"" + self.options.data.messages[0] + "\"",
                                    width: 300,
                                    offset: 13
                                }
                            );
                            
                        case 1:
                            
                            $('<div class="cf-icon list inner check white"></div>').prependTo(self.pathway).tooltip(
                                {
                                    text: "Visitor passed the CAPTCHA",
                                    offset: 13
                                }
                            );
                            
                        case 0:
                            
                            $('<div class="cf-icon list inner shield white"></div>').prependTo(self.pathway).tooltip(
                                {
                                    text: "Visitor was challenged",
                                    offset: 13
                                }
                            );
                            
                            break;
                        case -1:
                            $('<div class="cf-icon list inner door white"></div>').prependTo(self.pathway).tooltip(
                                {
                                    text: "Visitor was not challenged",
                                    offset: 13
                                }
                            );
                            
                            break;
                        default:
                            break;
                    }
                }
                
                
            },
            destroy: function() {
                
                $.ui.actionableListItemRenderer.prototype.destroy.apply(this, arguments);
                
                var self = this;
                self.inner.find('div').clearTooltip(); // TODO: Might want to optimize by doing this piecewise.
            }
        }
    );
    
    $.widget(
        'ui.customRuleItemRenderer',
        $.ui.threatListItemRenderer,
        {
            _create: function() {
                
                var self = this;
                $.extend(
                    self.options,
                    {
                        buttons: [
                            {
                                title: 'block',
                                tip: 'Add this entity to your Block List'
                            },
                            {
                                title: 'unblock',
                                tip: 'Remove this entity from your Block List'
                            },
                            {
                                title: 'trust',
                                tip: 'Add this entity to your Trust List'
                            },
                            {
                                title: 'untrust',
                                tip: 'Remove this entity from your Trust List'
                            }
                        ]
                    }
                );
                
                self.element.addClass('custom-rule-item-renderer');
                
                $.ui.threatListItemRenderer.prototype._create.apply(this, arguments);
                self._invalidateData();
            },
            _invalidateData: function() {
                
                var self = this;
                
                self.options.data.category = 'CR';
                
                switch(self.options.data.grp) {
                    case "ctry":
                        self.options.data.idFormat = "Country";
                        break;
                    case "ipr":
                        self.options.data.idFormat = "IP Range";
                        break;
                    default:
                        self.options.data.idFormat = "IP";
                        break;
                }
                
                self.date.clearTooltip().tooltip(
                    {
                        text: "Date this rule was created"
                    }
                );
                
                self.options.data.id = self.options.data.key;
                self.options.data.dateString = self.options.data.edate;
                
                
                
                $.ui.threatListItemRenderer.prototype._invalidateData.apply(this, arguments);
                
                if(self.options.data.rule.toLowerCase() == 'wl') {
                    
                    // Trust item renderer...
                    self.element.removeClass('blocked');
                    self.options.data.pathway = 3;
                    self.buttonContainer.children('.unblock, .trust').hide();
                    self.buttonContainer.children('.block, .untrust').show();
                } else {
                    
                    // Block item renderer...
                    self.element.addClass('blocked');
                    self.options.data.pathway = 4;
                    self.buttonContainer.children('.unblock, .trust').show();
                    self.buttonContainer.children('.block, .untrust').hide();
                }
            }
        }
    );
    
    
})(jQuery);

/*******************************************************************************
 *
 * CloudFlare UI List
 * 
 * @author Christopher Joel
 * 
 * Copyright 2010 CloudFlare, Inc.
 * 
 ******************************************************************************/

(function($) {
    
    $.widget(
        'ui.list',
        $.ui.cloudflareWidget,
        {
            
            options: {
                itemRenderer: 'listItemRenderer',
                nullItemRenderer: 'nullItemRenderer',
                title: "",
                icon: "",
                dataProvider: [],
                filters: [],
                addItemAnimation: function(item, complete) {
                    item.show();
                    complete();
                },
                removeItemAnimation: function(item, complete) {
                    item.hide();
                    complete();
                }
            },
            
            _setOption: function(key, value) {
                
                var self = this;
                
                // TODO: Switch to CloudFlare Widget's auto option invalidation...
                self.options[key] = value;
                
                switch(key) {
                    
                    case 'itemRenderer': {
                        self._invalidateItemRenderer();
                        break;
                    }
                    case 'icon':
                    case 'title': {
                        self._invalidateTitle();
                        break;
                    }
                    case 'dataProvider': {
                        self._invalidateDataProvider();
                        break;
                    }
                    case 'filters': {
                        self._invalidateFilters();
                        break;
                    }
                }
                
            },
            
            _create: function() {
                
                var self = this;
                
                if(self.element.is('ul')) {
                    
                    self.selectedIndex = -1;
                    self.hoverIndex = -1;
                    
                    self.unfilteredItemCount = 0;
                    
                    self.element.addClass('cf-ui list');
                    self.title = $('<li class="title"><span class="icon"></span><span class="label"></span></li>').addClass(self.options.title.toLowerCase().split(' ').join('-')).appendTo(self.element);
                    
                    self.element.bind(
                        'blur mouseleave',
                        function(event) {
                            
                            self.highlight(-1);
                        }
                    );
                    
                    self._invalidateTitle();
                    self._invalidateDataProvider();
                    
                } else {
                    
                    return false;
                    
                }
            },
            
            _invalidateTitle: function() {
                
                var self = this;
                
                if(self.options.title && self.options.title != "") {
                    
                    self.title.find('span.label').text(self.options.title);
                    self.title.find('span.icon').addClass(self.options.iconClass);
                    
                } else {
                    
                    self.title.hide();
                    
                }
            },
            
            _invalidateDataProvider: function() {
                
                var self = this;
                
                self.empty();
                
                if(self.options.dataProvider.length > 0) {
                    
                    for(var i = 0; i < self.options.dataProvider.length; i++) {
                        
                        self.addItem(self.options.dataProvider[i], null, true, false);
                    }
                } else {
                    
                    self._invalidateItemRenderer();
                    
                }
            },
            
            _invalidateFilters: function() {
                
                var self = this;
                
                self.unfilteredItemCount = 0;
                
                self.element.children(self._resolveItemSelector()).each(
                    function(i, e) {
                        
                        var show = true;
                        var item = $(e);
                        
                        $.each(
                            self.options.filters,
                            function(i, f) {
                                show = show && f(item[item.data('itemRenderer')]('option', 'data'));
                            }
                        );
                        
                        if(show) {
                            item.show();
                            item.removeClass('filtered');
                        } else {
                            item.hide();
                            item.addClass('filtered');
                        }
                    }
                );
                
                self._trigger(
                    'filter', 
                    null, 
                    {}
                );
            },
            
            _invalidateItemRenderer: function() {
                
                var self = this;
                
                if(self.options.dataProvider.length > 0) {
                    
                    self.element.children(self._resolveItemSelector()).each(
                        
                        function(i, e) {
                            
                            var oldItem = $(e);
                            self.addItem(oldItem[oldItem.data('itemRenderer')]('option', 'data'), i);
                            self.removeItem(oldItem);
                        }
                    );
                } else {
                    
                    $('<li><span class="label"></span></li>')[self.options.nullItemRenderer]({data: {label: "No data available!"}}).appendTo(self.element);
                    
                }
            },
            
            _resolveItemSelector: function() {
                
                return 'li.list-item-renderer';
                
            },
            
            _resolveItemRenderer: function(data) {
                
                var self = this;
                return data.itemRenderer ? data.itemRenderer : self.options.itemRenderer;
                
            },
            
            _resolveItemCount: function() {
                
                var self = this;
                return self.element.children(self._resolveItemSelector()).length;
                
            },
            
            _resolveItemIndex: function(item) {
                
                var self = this;
                return self.element.children(self._resolveItemSelector()).index(item);
                
            },
            
            _resolveItem: function(index) {
                
                var self = this;
                //return self.element.children(self._resolveItemSelector()).eq(self.selectedIndex); // wtf..
                return self.element.children(self._resolveItemSelector()).eq(index);
                
            },
            
            _nudge: function(nudgeType, select) {
                
                var self = this;
                var current = self._resolveItem(select ? self.selectedIndex : self.hoverIndex);
                
                if(current.length && current[nudgeType](self._resolveItemSelector()).length) {
                    
                    if(select) {
                        self.select(current[nudgeType](self._resolveItemSelector()));
                    } else {
                        self.highlight(current[nudgeType](self._resolveItemSelector()));
                    }
                }
                
            },
            
            _triggerChange: function() {
                
                var self = this;
                
                self._trigger(
                    'change',
                    $.Event('change'),
                    {}
                );
            },
            
            _delegateItem: function(item, role) {
                
                var self = this;
                var index = typeof item == "number" ? item : self._resolveItemIndex(item);
                
                if(index < 0 || index >= self._resolveItemCount()) {
                    
                    index = -1;
                    
                    // TODO: There is a bug in IE7 that is causing weird issues when swapping CSS classes..
                    if($.cf.resolveClientTier() < $.cf.clientTier.three) {
                    
                        self.element.children(self._resolveItemSelector()).removeClass(role);
                    }
                    
                } else {
                    
                    // TODO: Ditto..
                    if($.cf.resolveClientTier() < $.cf.clientTier.three) {
                    
                        self.element.children(self._resolveItemSelector()).removeClass(role).eq(index).addClass(role);
                    }
                }
                
                return index;
                
            },
            
            _registerItem: function(item) {
                
                var self = this;
                var show = true;
                
                item.bind(
                    'mouseenter',
                    function(event) {
                        
                        self.highlight(item);
                        
                    }
                ).bind(
                    'click',
                    function(event) {
                        
                        if (!item.hasClass('disabled')) {
                            self.select(item);
                        }
                        
                    }
                );
                
                return item;
                
            },
            
            // TODO: We need an event emitting data provider!!!
            addItem: function(data, index, instant, dpTempFix) {
                
                var self = this;
                var item = self._registerItem(
                    $('<li></li>')[self._resolveItemRenderer(data)](
                        { 
                            data: data,
                            itemaction: function(event, ui) {
                                
                                self._trigger('itemaction', event, ui);
                            }
                        }
                    )
                );
                
                item.bind(
                    'mousedown',
                    function(event) {
                        event.preventDefault();
                        //$.cf.log('Click!');
                    }
                )
                
                var show = true;
                
                
                if(index) {
                    self.element.children(self._resolveItemSelector()).eq(index).after(item);
                    if(dpTempFix !== false) {
                        self.options.dataProvider.splice(index, 0, data);
                    }
                } else {
                    self.element.append(item);
                    if(dpTempFix !== false) {
                        self.options.dataProvider.push(data);
                    }
                }
                
                
                $.each(
                    self.options.filters,
                    function(i, f) {
                        show = show && f(item[item.data('itemRenderer')]('option', 'data'));
                    }
                );
                
                item.hide();
                        
                if(show) {
                    
                    item.removeClass('filtered');
                    if(instant) {
                        
                        item.show();
                        self._triggerChange();
                    } else {
                        
                        self.options.addItemAnimation(
                            item, 
                            function() {
                                self._triggerChange();
                            }
                        );
                    }
                } else {
                    
                    item.addClass('filtered');
                    self._triggerChange();
                }
            },
            
            removeItem: function(item, instant) {
                
                var self = this;
                
                $.cf.log('Removing item ' + item);
                
                var performRemove = function() {
                    
                    var index = typeof item == 'number' ? item : self._resolveItemIndex(item);
                    var actualItem = self._resolveItem(index);
                    
                    $.cf.log('Performing remove! # of items: ' + actualItem.length);
                    
                    actualItem[self.options.itemRenderer]('destroy').remove();
                    self.options.dataProvider.splice(index, 1);
                    
                    self._triggerChange();
                };
                
                instant ? performRemove() : self.options.removeItemAnimation(
                    (typeof item == 'number' ? self._resolveItem(item) : item), 
                    performRemove
                );
                
            },
            
            getItem: function(index) {
                
                return self._resolveItem(index);
            },
            
            countFilteredItems: function() {
                
                var self = this;
                
                return self.element.children(self._resolveItemSelector()).filter('.filtered').length;
            },
            
            countItems: function() {
                
                var self = this;
                
                return self.element.children(self._resolveItemSelector()).length;
            },
            
            empty: function() {
                
                var self = this;
                var oldLength = self.options.dataProvider ? self.options.dataProvider.length : 0;
                
                if(oldLength != 0) {
                    
                    // TODO: Call destroy on list item renderers.. maybe iteratively call removeItem..
                    self.element.children(self._resolveItemSelector())[self.options.itemRenderer]('destroy').remove();
                } else {
                    
                    self.element.children(self._resolveItemSelector()).remove();
                }
                
                if(oldLength != self.options.dataProvider.length) {
                    
                    self._triggerChange();
                }
            },
            
            select: function(index) {
                
                var self = this;
                
                self.selectedIndex = self._delegateItem(index, 'active');
                
                if(self.selectedIndex > -1) {
                    
                    // TODO: _resolveItem should automatically handle index / dom element detection..
                    var item = typeof index == "number" ? self._resolveItemIndex(index) : index;
                    
                    self._trigger(
                        'selected', 
                        $.Event('selected'), 
                        {
                            item: item[item.data('itemRenderer')]('option', 'data'),
                            renderer: item,
                            index: self._resolveItemIndex(item)
                        }
                    );
                }
                
            },
            
            highlight: function(index) {
                
                var self = this;
                
                self.hoverIndex = self._delegateItem(index, 'hover');
                
            },
            
            next: function(select) {
                
                var self = this;
                
                self._nudge('next', select);
                
            },
            
            previous: function(select) {
                
                var self = this;
                
                self._nudge('prev', select);
                
            }
        }
    );
    
})(jQuery);

(function($) {
    
    $.widget(
        'ui.combobox',
        $.ui.cloudflareWidget, {
            
            options: {
                width: null,
                height: '23px',
                fontSize: null,
                comboOptions: null,
                value: null,
                // TODO: Replace with "placeholder"
                hideFirstValue: false
            },
            _setOption: function(key, value) {
                
                var self = this;
                
                self.options[key] = value;
                
                self.invalidateOption(key);
                
            },
            _create: function() {
                
                var self = this;

                // disable for mobile devices, where native control tends to be customized for the device
                if ($.cf.isMobile) { return false; }

                // disable for IE 9+ while funky width bug is funky
                if ($.browser.msie && parseInt($.browser.version.substr(0, 2), 10) >= 9) { return false; }
                
                if(self.element.is('select')) {
                    
                    self.element.addClass('ui-helper-hidden-accessible');
                    self.elementHasFocus = false;
                    
                    self.combo = $('<div class="cf-ui combobox"></div>').insertAfter(self.element);
                    
                    self.title = $('<div class="title"></div>').appendTo(self.combo);
                    self.arrow = $('<div class="arrow"><div class="cf-icon direction down grey"></div></div>').appendTo(self.combo);
                    self.comboOptions = $('<div class="cf-ui combobox comboOptions"></div>').appendTo('body').hide();
                    self.optionList = $('<ul></ul>').appendTo(self.comboOptions).list(
                        {
                            itemRenderer: 'comboboxItemRenderer',
                            selected: function(event, ui) {
                                $.cf.log('Setting value: ' + ui.item.value);
                                self.element.val(ui.item.value);
                                self.element.change();
                                
                                self._trigger(
                                    'selected', 
                                    $.Event('selected'), 
                                    {
                                        item: ui.item
                                    }
                                );
                            }
                        }
                    );
                    
                    self.element.bind(
                        'focus',
                        function(event) {
                            self.combo.addClass('hover');
                            self.elementHasFocus = true;
                        }
                    ).bind(
                        'blur',
                        function(event) {
                            self.combo.removeClass('hover');
                            self.close();
                            self.elementHasFocus = false;
                        }
                    ).bind(
                        'change',
                        function(event) {
                            self._setOption('value', self.element.val());
                        }
                    );
                    
                    self.combo.bind(
                        'mouseenter',
                        function(event) {
                            self.combo.addClass('hover');
                        }
                    ).bind(
                        'mouseleave',
                        function(event) {
                            if(!self.elementHasFocus) {
                                self.combo.removeClass('hover');
                            }
                        }
                    ).bind(
                        'click',
                        function(event) {
                            if(self.combo.hasClass('active')) {
                                self.close();
                            } else {
                                self.open();
                            }
                        }
                    );
                    
                    self.resolveHasFocusProxy = function(event) {
                        self._resolveHasFocus(event.target);
                    }
                    
                    self._invalidateValue();
                    self._invalidateComboOptions();
                    self._invalidateDimensions();
                    
                    return true;
                }
                
                self.destroy();
                return false;
                
            },
            
            _resolveHasFocus: function(clickTarget) {
                
                var self = this;
                
                if(!($.contains(self.combo.get(0), clickTarget) || self.combo.get(0) == clickTarget)) {
                    self.close();
                }
                
            },
            _resolveComboOptionsSize: function() {
                
                var self = this;
                
                var comboOptionsHeight = self.comboOptions.height();
                var maxHeight = Math.max($.cf.windowProperties().height - 300, 200);
                
                return {
                    width: self.element.innerWidth(),
                    height: comboOptionsHeight > maxHeight ? maxHeight : 0
                };
            },
            _invalidateValue: function() {
                
                var self = this,
                    selectedIndex;
                
                if(self.options.value != self.element.val()) {
                    self.element.change();
                } else {
                    
                    selectedIndex = self.element.get(0).selectedIndex >= 0 ? self.element.get(0).selectedIndex : 0;
                    self.title.text($(self.element.get(0).options[selectedIndex]).text());
                }
                
            },
            _invalidateWidth: function() {
                var self = this;
                self._invalidateDimensions();
            },
            _invalidateHeight: function() {
                var self = this;
                self._invalidateDimensions();
            },
            _invalidateDimensions: function() {
                
                var self = this;
                var comboWidth,
                    fontSize;
                
                if(self.options.width) {
                    comboWidth = $.cf.normalizeCSSMeasurement(self.options.width);
                } else {
                    comboWidth = 0;
                    self.comboOptions.show();
                    comboWidth = Math.max(self.comboOptions.width(), comboWidth);
                    self.comboOptions.hide();
                    comboWidth += $.cf.normalizeDigitalMeasurement(self.options.height) * 2.5;// + $.cf.normalizeDigitalMeasurement(self.options.height);
                }

                if(self.options.fontSize) {
                    fontSize = $.cf.normalizeCSSMeasurement(self.options.fontSize);
                } else {
                    fontSize = $.cf.normalizeDigitalMeasurement(self.options.height) / 2 + 'px';
                }
                
                self.combo.css(
                    {
                        width: $.cf.normalizeCSSMeasurement(comboWidth),
                        height: $.cf.normalizeCSSMeasurement(self.options.height)
                    }
                );
                
                self.comboOptions.css(
                    {
                        width: self.combo.css('width')
                    }
                );
                
                self.title.css(
                    {
                        lineHeight: $.cf.normalizeCSSMeasurement(self.options.height),
                        fontSize: fontSize,
                        paddingLeft: $.cf.normalizeDigitalMeasurement(self.options.height) / 3 + 'px',
                        paddingRight: $.cf.normalizeDigitalMeasurement(self.options.height) + $.cf.normalizeDigitalMeasurement(self.options.height) / 3 + 'px'
                    }
                );
                
                self.arrow.css(
                    {
                        width: $.cf.normalizeDigitalMeasurement(self.options.height) + 3 + 'px'
                    }
                );
                
            },
            _invalidateComboOptions: function() {
                
                var self = this;
                var comboOptions = self.options.comboOptions ? self.options.comboOptions : self.element.children('option');
                
                self.optionList.list('empty');
                
                $.each(
                    comboOptions,
                    function(i, o) {
                        
                        if(!(self.options.hideFirstValue && i == 0)) {
                        
                            self.optionList.list(
                                'addItem', 
                                {
                                    label: typeof o == 'string' ? o : ($(o).attr('label') ? $(o).attr('label') : $.trim($(o).text())), 
                                    value: typeof o == 'string' ? o : ($(o).attr('value') ? $(o).attr('value') : $.trim($(o).text())),
                                    itemRenderer: typeof o == 'string' ? 'comboboxItemRenderer' : $(o).attr('itemrenderer') || 'comboboxItemRenderer'
                                }
                            );
                        }
                    }
                );
                
                var dimensions = self._resolveComboOptionsSize();
                
                self.optionList.css(
                    {
                        height: dimensions.height > 0 ? self._resolveComboOptionsSize().height + 'px' : 'auto'
                    }
                );
            },
            open: function() {
                
                var self = this;
                self.combo.addClass('active');
                
                self.comboOptions.css(
                    {
                        left: $.cf.normalizeCSSMeasurement(self.combo.offset().left + 1),
                        top: $.cf.normalizeCSSMeasurement(self.combo.offset().top + self.combo.outerHeight())
                    }
                ).show();
                
                $(document).bind('click', self.resolveHasFocusProxy);
                
            },
            close: function() {
                
                var self = this;
                self.combo.removeClass('active');
                self.comboOptions.hide();
                
                $(document).unbind('click', self.resolveHasFocusProxy);
            }
        }
    );
    
})(jQuery);

/*
 * Wraps jQuery - asmSelect
 */
(function($) {
    
    $.widget(
        'ui.multiSelect',
        $.ui.cloudflareWidget, {
            
            options: {

                removeLabel: "(remove)",
                listItemClass: "asmListItemCustom"
            },

            _setOption: function(key, value) {
                
                var self = this;
                
                self.options[key] = value;

                self._refresh();
            },

            _create: function() {
                
                var select = $(this.element),
                    controlSelect;

                select.addClass(

                    'cf-ui cf-multiselect'
                ).asmSelect(

                    this.options
                ).bind('change', function(event) {

                    var smVal = $(this).val(),
                        controlSelectData = controlSelect.data('combobox').optionList.list('option', 'dataProvider'),
                        disabledLangs = controlSelect.find('option[disabled]').map(function(i, disabledOption) {
                            return $(disabledOption).val();
                        });

                    $.each(controlSelectData, function(i, o) {
                        o.itemRenderer = $.inArray(o.value, disabledLangs) != -1 ?
                            'comboboxDisabledItemRenderer' :
                            'comboboxItemRenderer'
                    });

                    controlSelect.data('combobox').optionList.list('option', 'dataProvider', controlSelectData)
                });

                controlSelect = select.parent().find('select:not([multiple]).asmSelect');
                controlSelect.combobox();
            },

            // mark options matched by selection as unselectable and deselect them if selected
            disableOption: function(selector) {

                var select = $(this.element);
                select.find(selector).attr({
                    disabled: true,
                    selected: false
                });
                select.change();
            },

            // mark options matched by selection as selectable if they were unselectable
            enableOption: function(selector) {

                var select = $(this.element);
                select.find(selector).attr({
                    disabled: false
                });
                select.change();
            },

            // mark any disabled options as selectable
            enableAllOptions: function() {

                this.enableOption('option');
            },

            _refresh: function() {

                var self = this;
                self._destroy();
                self._create();
            },

            _destroy: function() {

                var self = this;
            },

            destroy: function() {

                this._destroy();
                $.Widget.prototype.destroy.apply(this, arguments);
            }
        }
    );
    
})(jQuery);

(function($) {
    
    $.widget(
        'ui.logBook',
        {
            options: {
                
                source: null,
                allowInspection: true,
                itemRenderer: 'listItemRenderer',
                emptyListFeedback: 'No more entries available'
            },
            
            _create: function() {
                
                var self = this;
                
                if(self.element.is('div')) {
                    
                    self.element.empty();
                    self.element.addClass('cf-ui log-book');
                    
                    self.listContainer = $('<div class="list-container"></div>').appendTo(self.element);
                    self.overhead = $('<div class="overhead"></div>').appendTo(self.element);
                    
                    self.list = $('<ul></ul>').appendTo(self.listContainer).list(
                        {
                            itemRenderer: self.options.itemRenderer,
                            removeItemAnimation: function(item, complete) {
                                
                                item.animate(
                                    {
                                        opacity: 0
                                    },
                                    200,
                                    'easeInExpo',
                                    function() {
                                        item.css(
                                            {
                                                height: item.outerHeight() + 'px',
                                                padding: 0,
                                                border: 0
                                            }
                                        ).animate(
                                            {
                                                height: 0
                                            },
                                            200, 
                                            'easeOutExpo', 
                                            function() {
                                                
                                                complete();
                                            }
                                        );
                                    }
                                );
                            },
                            filter: function(event) {
                                
                                self._invalidateVisibility();
                                
                                if(!self.loading) {
                                    self.feedback = [self._resolveStatusText()];
                                    self._invalidateMessages();
                                }
                            },
                            change: function(event, ui) {
                                
                                if(!self.loading) {
                                    self.feedback = [self._resolveStatusText()];
                                    self._invalidateMessages();
                                }
                            },
                            itemaction: function(event, ui) {
                                
                                $.extend(
                                    ui,
                                    {
                                        list: self.list
                                    }
                                );
                                
                                self._trigger('itemaction', event, ui);
                            },
                            selected: function(event, ui) {
                                if(self.options.allowInspection) {
                                    
                                    self.inspect(ui.renderer);
                                }
                            }
                        }
                    );
                    
                    self.feedbackContainer = $('<div class="message-container"></div>').appendTo(self.listContainer);
                    self.feedbackButtons = $('<ul class="buttons"></ul>').appendTo(self.feedbackContainer);
                    
                    self.listContainer.bind(
                        'scroll',
                        function(event) {
                            
                            if(self.listContainer.scrollTop() >= self.listContainer.scrollTopMax()) {
                                self._invalidateVisibility();
                            }
                        }
                    );
                    
                    self.loadMoreButton = $('<li><a>LOAD MORE</a></li>').appendTo(self.feedbackButtons);
                    self.loadMoreButton.bind(
                        'click',
                        function(event) {
                            self.query();
                        }
                    );
                    
                    self.feedbackButtonsVisible = false;
                    self.loading = false;
                    
                    self.handleResultProxy = function() {
                        
                        self._handleResult.apply(self, arguments);
                    }
                    
                    self._invalidateLoading();
                    self._invalidateVisibility();
                    self._invalidateSource();
                    
                    return true;
                    
                }
                
                self.destroy();
                return false;
                
            },
            
            _invalidateLoading: function() {
                
                var self = this;
                
                if(self.loading) {
                    
                    self.feedback = ['Loading more entries...'];
                }
                
            },
            
            _invalidateSource: function() {
                
                var self = this;
                
                self.list.empty();
                self.sourceHasMore = self.shortCircuitFeedback = true;
                
                self.querySource = function(complete) {
                    
                    self.options.source.query(complete);
                };
                
                if(self.options.source) {
                    
                    self.query();
                }
            },
            
            _invalidateVisibility: function() {
                
                var self = this;
                
                if(self.loading) {
                    
                    self._hideFeedbackButtons();
                    
                } else if(self.sourceHasMore) {
                    
                    self.loadMoreButton.show();
                    
                    if(self.feedback.length) {
                        
                        self._hideFeedbackButtons();
                    } else {
                        
                        self._showFeedbackButtons();
                    }
                } else {
                    
                    if(self.loadMoreButton) {
                        self.loadMoreButton.hide();
                    }
                    
                    self._hideFeedbackButtons();
                }
            },
            
            _invalidateMessages: function() {
                
                var self = this;
                
                if(self.feedback.length) {
                    
                    var oldMessages = self.feedbackContainer.find('div.message');
                    var message = $('<div class="message">' + self.feedback.shift() + '</div>').appendTo(self.feedbackContainer);
                    
                    oldMessages.css(
                        {
                            position: 'absolute'
                        }
                    ).animate(
                        {
                            top: '-20px',
                            opacity: 0
                        },
                        800,
                        'easeOutExpo',
                        function() {
                            oldMessages.remove();
                        }
                    );
                    
                    message.animate(
                        {
                            top: '0px'
                        },
                        200,
                        'easeOutExpo',
                        function() {
                            self.messageTimeout = setTimeout(
                                function() {
                                    
                                    self._invalidateVisibility();
                                    self._invalidateMessages();
                                },
                                1500
                            );
                        }
                    );
                    
                } else {
                    
                    if(!self.loading) {
                        
                        self._showFeedbackButtons();
                    }
                }
            },
            
            _resolveStatusText: function() {
                
                var self = this;
                var filtered = self.list.list('countFilteredItems');
                var total = self.list.list('countItems');
                
                var filterString = total && filtered ? 'Your current filters reveal ' + (total - filtered) + ' of ' + total + ' item' + (total > 1 ? 's. ' : '. ') : '';
                var remainingString = self.sourceHasMore ? 'More entries available to load.' : self.options.emptyListFeedback;
                
                return filterString + remainingString;
            },
            
            _handleResult: function(result) {
                
                var self = this;
                
                var listFilters = self.list.list('option', 'filters');
                var matchCount = 0;
                var listHeight = 0;
                
                self.feedback = [];
                self.sourceHasMore = result.moreResults && result.results.length > 0;
                
                $.each(
                    result.results,
                    function(i, r) {
                        
                        self.list.list('addItem', r);
                        
                    }
                );
                
                self.feedback.push(result.results.length + ' more entries loaded.');
                
                if(listFilters.length && result.results.length > 0) {
                    
                    $.each(
                        result.results,
                        function(i, r) {
                            
                            var hasMatch = true;
                            
                            $.each(
                                listFilters,
                                function(i, f) {
                                    hasMatch = f(r) && hasMatch;
                                }
                            );
                            
                            if(hasMatch) {
                                matchCount++;
                            }
                        }
                    );
                    
                    self.feedback.push(matchCount + ' new entries match these filters.');
                }
                
                self.feedback.push(self._resolveStatusText());
                self.loading = false;
                
                self._invalidateLoading();
                self._invalidateVisibility();
                self._invalidateMessages();
            },
            
            _showFeedbackButtons: function() {
                
                var self = this;
                
                if(!self.feedbackButtonsVisible) {
                    
                    self.feedbackButtons.fadeIn(200);
                    self.feedbackButtonsVisible = true;
                }
            },
            
            _hideFeedbackButtons: function() {
                
                var self = this;
                
                if(self.feedbackButtonsVisible) {
                    
                    self.feedbackButtons.fadeOut(200);
                    self.feedbackButtonsVisible = false;
                }
            },
            
            inspect: function(item) {
                
                var self = this;
                
                if($.contains(self.list.get(0), item.get(0))) {
                    
                    var itemRenderer = item.data('itemRenderer');
                    var data = item[itemRenderer]('option', 'data');
                    var originalTop = $.cf.normalizeCSSMeasurement(item.position().top - self.listContainer.scrollTop());
                    var originalHeight = item.css('height');
                    
                    self.listContainer.animate(
                        {
                            opacity: 0
                        },
                        300
                    );
                    
                    self.overhead.show();
                    
                    self.inspection = $('<li></li>').appendTo(self.overhead)[itemRenderer](
                        {
                            data: data,
                            itemaction: function(event, ui) {
                                
                                item[itemRenderer]('triggerAction', ui.action, event);
                            }
                        }
                    ).data(
                        'logBookInspection',
                        {
                            originalTop: originalTop,
                            originalHeight: originalHeight,
                            itemRenderer: itemRenderer
                        }
                    ).bind(
                        'click',
                        function(event) {
                            
                            event.stopImmediatePropagation();
                            
                            self.endInspection();
                        }
                    ).css(
                        {
                            top: $.cf.normalizeCSSMeasurement(item.position().top - self.listContainer.scrollTop()),
                            opacity: 0
                        }
                    ).animate(
                        {
                            top: '0px',
                            height: '100%',
                            opacity: 1
                        },
                        500,
                        'easeOutExpo',
                        function() {
                            
                            self.inspectionDetails = $('<div class="log-book-inspection-details"></div>').appendTo(self.inspection).css(
                                {
                                    top: originalHeight
                                }
                            ).bind(
                                'click',
                                function(event) {
                                    event.stopImmediatePropagation();
                                }
                            );
                            
                            self._trigger(
                                'inspecting',
                                $.Event('inspecting'),
                                {
                                    item: data,
                                    detailContainer: self.inspectionDetails
                                }
                            );
                        }
                    );
                }
            },
            
            endInspection: function() {
                
                var self = this;
                
                if(self.inspection) {
                    
                    var oldInspection = self.inspection;
                    self.inspection = null;
                    
                    self.listContainer.animate(
                        {
                            opacity: 1
                        },
                        700
                    );
                    
                    self.inspectionDetails.fadeOut(
                        200, 
                        function() {
                            
                        }
                    );
                    
                    oldInspection.animate(
                        {
                            height: oldInspection.data('logBookInspection').originalHeight,
                            top: oldInspection.data('logBookInspection').originalTop
                        },
                        500,
                        'easeOutExpo',
                        function() {
                            
                            oldInspection.fadeOut(
                                150,
                                function() {
                                    
                                    if(oldInspection) {
                                        
                                        oldInspection[oldInspection.data('logBookInspection').itemRenderer]('destroy');
                                        oldInspection.remove();
                                        oldInspection = null;
                                        
                                    } else {
                                        
                                        $.cf.log('Something removed the inspection pane before it should be removed! This is not critical, but it should be fixed.', $.cf.logType.warning);
                                    }
                                    
                                    self.overhead.hide();
                                        
                                    self._trigger(
                                        'inspectiondone',
                                        $.Event('inspectiondone'),
                                        {}
                                    );
                                }
                            );
                        }
                    );
                } else {
                    self._trigger(
                        'inspectiondone',
                        $.Event('inspectiondone'),
                        {}
                    );
                }
            },
            
            query: function() {
                
                var self = this;
                self.querySource(self.handleResultProxy);
                self.loading = true;
                self._invalidateLoading();
                
            },
            
            getList: function() {
                
                var self = this;
                $.cf.log('Returning list');
                return self.list;
                
            }
        }
    );
    
})(jQuery);
/*******************************************************************************
 *
 * CloudFlare UI Looking Glass
 * 
 * @author Christopher Joel
 * 
 * Copyright 2010 CloudFlare, Inc.
 * 
 ******************************************************************************/

(function($) {
    
    $.widget(
        'ui.lookingGlass',
        {
            options: {
                
                source: null,
                itemRenderer: 'lookingGlassItemRenderer',
                delay: 500,
                maxHeight: null,
                displayEmptySources: true,
                preserveOrder: false
                
            },
            _setOption: function(key, value) {
                
                var self = this;
                
                self.options[key] = value;
                
                switch(key) {
                    
                    case 'source':
                        self._invalidateSource();
                    default:
                        break;
                }
                
            },
            _create: function() {
                
                var self = this;
                
                if(self.element.is('input[type="text"]')) {
                    
                    self.document = self.element.get(0).ownerDocument;
                    self.keydownTimeout = -1;
                    self.menuHasMouse = false;
                    self.inputHasMouse = false;
                    
                    self.handleResultProxy = function() {
                        
                        self._handleResult.apply(self, arguments);
                        
                    }

                    self.element.addClass('cf-ui looking-glass');
                    
                    self.element.bind(
                        'keyup',
                        function(event) {
                            if(self.element.val() != "") {
                                switch(event.keyCode) {
                                    case $.ui.keyCode.ENTER: {
                                        
                                        clearTimeout(self.keydownTimeout);
                                        self.search(self.element.val());
                                        
                                        break;
                                    }
                                    case $.ui.keyCode.UP:
                                        break;
                                    case $.ui.keyCode.DOWN:
                                        break;
                                    case $.ui.keyCode.ESCAPE:
                                        
                                        self.close();
                                        
                                        break;
                                    case $.ui.keyCode.COMMAND_LEFT:
                                    case $.ui.keyCode.COMMAND_RIGHT:
                                    case $.ui.keyCode.LEFT:
                                    case $.ui.keyCode.RIGHT:
                                    case $.ui.keyCode.CONTROL:
                                    case $.ui.keyCode.ALT:
                                    case $.ui.keyCode.SHIFT:
                                        break;
                                    default: {
                                        
                                        clearTimeout(self.keydownTimeout);
                                        
                                        self.keydownTimeout = setTimeout(
                                            function() {
                                                
                                                self.search(self.element.val());
                                                
                                            },
                                            self.options.delay
                                        );
                                        
                                        break;
                                    }
                                }
                            } else {
                                
                                self.close();
                                
                            }
                        }
                    ).bind(
                        'focus',
                        function(event) {
                            
                            if(self.element.val() != "" && !self.menuHasMouse) {
                                
                                self.search(self.element.val());
                                
                            }
                        }
                    ).bind(
                        'blur',
                        function(event) {
                            
                            if(!self.menuHasMouse) {
                                
                                self.close();
                                
                            } else {
                                
                                event.preventDefault();
                                self.element.focus();
                                
                            }
                        }
                    );
                    
                    self.menu = $('<ul class="cf-ui looking-glass menu"></ul>').hide().appendTo('body').bind(
                        'mouseenter',
                        function(event) {
                            
                            self.menuHasMouse = true;
                            
                        }
                    ).bind(
                        'mouseleave',
                        function(event) {
                            
                            self.menuHasMouse = false;
                            
                        }
                    );
                    
                    self.close();
                    self._invalidateSource();
                    
                } else {
                    
                    return false;
                    
                }
            },
            _invalidateSource: function() {
                
                var self = this;
                
                self.newQuery = true;
                
                self.menu.empty();
                
                self.source = function(query, response) {
                    
                    $.each(
                        self.options.source,
                        function(i, q) {
                            q.data.q = query;
                            q.query(response);
                            //$.cf.log('Querying ' + q.name);
                        }
                    );
                };

                if(self.options.preserveOrder) {

                    self.sourceIndex = {};

                    $.each(
                        self.options.source,
                        function(i, q) {

                            self.sourceIndex[q.name] = i;
                        }
                    );
                }
            },
            _resolveMenuOffset: function() {
                
                var self = this;
                
                return {
                    top: self.element.offset().top + self.element.outerHeight(),
                    left: self.element.offset().left
                };
                
            },
            _resolveMenuSize: function() {
                
                var self = this;
                
                var menuHeight = 0;
                var maxHeight = self.options.maxHeight ? self.options.maxHeight : Math.max($.cf.windowProperties().height - 300, 200);
                
                self.menu.find('ul.list').each(
                    function(i, e) {
                        
                        menuHeight += $(e).height();
                        
                    }
                );
                
                return {
                    width: self.element.innerWidth(),
                    height: menuHeight > maxHeight ? maxHeight : 0
                };
            },
            _handleResult: function(result) {
                
                var self = this;
                var newCategory = true;
                var list;
                //$.cf.log('Handling result for ' + result.name + '! ' + result.results.length);
                
                self.menu.find('ul.list').each(
                    function(i, l) {
                        if($(l).list('option', 'title') == result.name) {
                            
                            list = $(l).list('option', 'dataProvider', result.results).parent();
                            return newCategory = false;
                        }
                    }
                );
                
                if(newCategory) {
                    
                    list = $('<ul></ul>').list(
                        {
                            selected: function(event, ui) {
                                
                                self._trigger('selected', event, {item: ui.item});
                            },
                            dataProvider: result.results,
                            title: result.name,
                            itemRenderer: self.options.itemRenderer
                        }
                    ).appendTo($('<li></li>')).parent();

                    if(self.options.preserveOrder && self.sourceIndex[result.name] < self.menu.children().length) {

                        list.insertBefore(self.menu.children().eq(self.sourceIndex[result.name]));
                        
                    } else {

                        list.appendTo(self.menu);
                    }
                    
                    /*).appendTo(
                        $('<li></li>').appendTo(self.menu)
                    ).parent();*/
                }
                
                if(result.results.length <= 0 && list && !self.options.displayEmptySources) {
                    list.hide();
                } else {
                    list.show();
                }
                
                if(self.element.val() != "") {
                    
                    self.open();
                    
                } else {
                    
                    self.close();
                    
                }
            },
            search: function(query) {
                
                var self = this;
                
                if(query && query.length) {
                    
                    self.source(query, self.handleResultProxy);
                    
                }
            },
            open: function() {
                
                var self = this;
                var offset = self._resolveMenuOffset();
                var size = self._resolveMenuSize();
                
                self.menu.css(
                    {
                        top: offset.top + 'px',
                        left: offset.left + 'px',
                        width: size.width + 'px',
                        height: size.height ? size.height + 'px' : 'auto'
                    }
                ).show();
                
            },
            close: function() {
                
                var self = this;
                
                self.menuHasMouse = false;
                self.menu.hide();
                
                
            }
        }
    );
})(jQuery);

(function($, window, undefined) {
    
    $(function() {
        
        $.widget(
            'ui.progressBar',
            $.ui.cloudflareWidget,
            {
                options: {
                    
                    title: 'Loading',
                    start: 0,
                    timer: false, // If not false, specify number of seconds
                    width: '140px',
                    height: '38px'
                },
                _setOption: function(key, value) {
                    
                    var self = this;
                    
                    if(key == 'timer') {
                        
                        self._timer(value);
                    }
                    
                    self.options[key] = value;
                },
                _create: function() {
                    
                    var self = this;
                    
                    if($(self.element).is('a')) {
                        
                        self.component = $(self.element);
                        self.component.addClass('cf-ui progress-bar');
                        
                        self.background = $('<div class="background"></div>').appendTo(self.component);
                        self.bar = $('<div class="bar"></div>').appendTo(self.component);
                        self.title = $('<span></span>').appendTo(self.component).text(self.options.title);
                        
                        self.progress(self.options.start);
                        
                        if(self.options.timer) {
                            
                            self._timer(self.options.timer);
                        }
                        
                    } else {
                        
                        self.destroy();
                    }
                },
                _timer: function(seconds) {
                    
                    var self = this;
                    
                    self.bar.animate(
                        {
                            width: '100%'
                        },
                        1000 * seconds,
                        'linear',
                        function() {
                            
                            self._trigger('complete');
                        }
                    );
                },
                progress: function(percent) {
                    
                    var self = this;
                    
                    percent = Math.min(Math.abs(percent), 1);
                    
                    self.bar.css(
                        {
                            width: Math.floor(100 * percent) + '%'
                        }
                    );
                    
                    if(percent == 1) {
                        
                        self._trigger('complete');
                    }
                },
                destroy: function() {
                    
                    var self = this;
                    
                    if(self.title) {
                        
                        self.title.remove();
                        self.title = null;
                    }
                    
                    if(self.bar) {
                        
                        self.bar.remove();
                        self.bar = null;
                    }
                    
                    if(self.background) {
                        
                        self.background.remove();
                        self.background = null;
                    }
                    
                    self.component.removeClass('cf-ui progress-bar');
                }
            }
        );
        
    });
})(jQuery, window);
(function($, window, undefined) {

    $(function() {

        $.widget(
            'ui.bitField',
            $.ui.cloudflareWidget,
            {
                options: {
                    title: "Select options",
                    listFormat: false,
                    bits: []
                },
                _setOption: function(key, value) {

                    var self = this;

                    self.options[key] = value;
                    
                    self.invalidate();
                },
                _create: function() {

                    var self = this;

                    if($(self.element).is('div')) {

                        self.component = $(self.element);
                        self.component.addClass('cf-ui bit-field');

                        if(self.options.listFormat) {

                            self.component.addClass('list');
                        }

                        self.title = $('<h1></h1>').appendTo(self.component).text(self.options.title);

                        self.bitList = $('<ul></ul>').appendTo(self.component);

                        self.enabled = true;

                        self.invalidate();
                    }
                },

                enable: function() {

                    this.enabled = true;
                },

                disable: function() {

                    this.enabled = false;
                },

                setBit: function(bitIndex, bitValue) {

                    var self = this,
                        bits = self.options.bits,
                        bit = bits[bitIndex],
                        oldBitValue = bit.value;

                    bit.value = bitValue;

                    if(oldBitValue !== bitValue) {

                        self._trigger('change', null, { value: self.value() });
                    }

                    self.refresh(bitIndex);
                },

                getBit: function(bitIndex) {

                    return this.options.bits[bitIndex].value;
                },

                setValue: function(value) {

                    var self = this,
                        bits = self.options.bits;

                    $.each(
                        bits,
                        function(index, bit) {

                            bit.value = !!(value & Math.pow(2, index));
                        }
                    );
                        
                },

                value: function() {

                    var self = this,
                        bits = self.options.bits,
                        value = 0;

                    $.each(
                        bits,
                        function(index, bit) {

                            if(bit.value === true) {

                                value |= Math.pow(2, index);
                            }
                        }
                    );

                    return value;
                },

                refresh: function(specificIndex) {

                    var self = this,
                        bits = self.options.bits,
                        bitList = self.bitList,
                        refresh = function(index) {

                            var item = bitList.children().eq(index);

                            if(self.getBit(index)) {

                                item.addClass('set');
                            } else {

                                item.removeClass('set');
                            }
                        };

                    if(typeof specificIndex !== "undefined") {

                        refresh(specificIndex);
                    } else {

                        $.each(
                            bits,
                            function(index, bit) {

                                refresh(index);
                            }
                        );
                    }
                },

                invalidate: function() {

                    var self = this,
                        bits = self.options.bits,
                        bitList = self.bitList;

                    bitList.empty();

                    $.each(
                        bits,
                        function(index, bit) {

                            var item = $('<li></li>').addClass(bit.value ? 'set' : '').appendTo(bitList),
                                link = $('<a href="javascript:void(0);"></a>').append($('<span>' + bit.label + '</span>')).appendTo(item);
                            
                            link.append($('<div class="icon"><div></div></div>'));

                            link.bind(
                                'click',
                                function() {

                                    if(self.enabled) {

                                        self.setBit(index, !(self.value() & Math.pow(2, index)));
                                    }
                                }
                            );
                        }
                    );

                    self.refresh();
                }
            }
        );
    });
})(jQuery, window);

(function($, window, undefined) {

    $(function() {

        $.widget(
            'ui.keyCode',
            $.ui.cloudflareWidget,
            {
                options: {

                    maxLength: 10,
                    defaultValue: []
                },
                _setOption: function() {

                    var self = this;

                    self.options[key] = value;

                    self.invalidate();
                },
                _create: function() {

                    var self = this;

                    if($(self.element).is('div')) {

                        self.component = $(self.element);
                        self.component.addClass('cf-ui key-code');

                        self.recordButton = $('<a href="javascript:void(0);"><span>Start recording</span><div class="icon"></div></a>').appendTo(self.component);

                        $('<span>Recorded key code below</span>').appendTo(self.component);

                        self.captureList = $('<ul></ul>').appendTo(self.component);


                        self.recording = false;
                        self.lastRecording = self.options.defaultValue;

                        self.capturedKeys = [];

                        self.specialUp = {
                            37: 'Left',
                            38: 'Up',
                            39: 'Right',
                            40: 'Down'
                        };

                        self.specialPress = {
                            13: 'Enter',
                            32: 'Space'
                        }

                        if(self.options.defaultValue) {

                            self.populate(self.options.defaultValue);
                        }

                        $('body').bind(
                            'keypress',
                            function(event) {

                                if(self.recording) {

                                    event.preventDefault();
                                }

                                var code = event.which || event.keyCode;

                                if(!self.specialUp[code]) {

                                    self.captureKey(code, self.specialPress[code] || String.fromCharCode(code));
                                }
                            }
                        ).bind(
                            'keyup',
                            function(event) {

                                var keyCode = event.which || event.keyCode;

                                if(self.specialUp[keyCode] && !self.specialPress[keyCode]) {

                                    if(self.recording) {

                                        event.preventDefault();
                                    }

                                    self.captureKey(keyCode, self.specialUp[keyCode]);
                                }
                            }
                        );
                        self.recordButton.bind(
                            'click',
                            function() {

                                if(!self.recording) {

                                    self.reset();
                                    self.record();
                                } else {

                                    self.stop();
                                    self.save();
                                }
                            }
                        );
                    }
                },
                populate: function(sequence) {

                    var self = this;

                    self.reset();
                    self.record();

                    $.each(
                        sequence,
                        function(index, code) {

                            self.captureKey(code, self.specialUp[code] || self.specialPress[code] || String.fromCharCode(code));
                        }
                    );

                    self.stop();
                    
                },
                record: function() {

                    var self = this;

                    if(!self.recording) {

                        self.recording = true;
                        self.recordButton.addClass('active');
                        
                        self.recordButton.children('span').eq(0).text('Click to stop');
                    }
                },
                stop: function() {

                    var self = this;

                    if(self.recording) {

                        self.recording = false;
                    
                        self.recordButton.removeClass('active');
                        self.recordButton.children('span').eq(0).text('Start recording');
                    }
                },
                reset: function() {

                    var self = this;

                    if(!self.recording) {

                        self.stop();

                        self.recording = false;

                        self.lastRecording = self.capturedKeys;
                        self.capturedKeys = [];
                        self.captureList.empty();
                    }
                },
                save: function() {

                    var self = this;

                    if(self.capturedKeys.length) {

                        if(!self.recording) {

                            self.stop();
                    
                            self.recording = false;
                            self.lastRecording = self.capturedKeys;
                    
                            self._trigger('commit', null, { value: self.capturedKeys });
                        }
                    } else {

                        self.populate(self.lastRecording);
                    }
                },
                captureKey: function(code, caption) {

                    var self = this;

                    caption = caption.length === 1 ? caption.toUpperCase() : caption;
                    if(self.recording && self.capturedKeys.length < self.options.maxLength) {

                        if (code >= 97) {
                            self.capturedKeys.push(code-32);
                        } else {
                            self.capturedKeys.push(code);
                        }
                        self.captureList.append($('<li>' + (caption || code) + '</li>'));
                    }
                },
                enable: function() {

                    this.enabled = true;
                },
                disable: function() {

                    this.enabled = false;
                }
            }
        );
    });
})(jQuery);

/*******************************************************************************
 *
 * CloudFlare UI DNS Row Component
 * 
 * @author Jason Benterou
 * 
 * Copyright 2010 CloudFlare, Inc.
 *
 * Visualize a DNS record.
 *
 * Populate data directly (options.data) or via lookup (options.load)
 *
 ******************************************************************************/
 
(function($) {

    $.widget(
        'ui.dnsRec', 
        $.ui.cloudflareWidget,
        {
        
        // default options
        options: {

            editable: true,

            // pass data directly to widget
            data: null,

            // in the absence of initialization data,
            // the widget will load itself using this data
            load: null,

            // true -> ignore data, load parameters and render no-data mode
            nodata: false,

            // true -> newrec mode
            newrec: false
        },

        _create: function() {
            
            var self = this,

                baseQuery = new $.cf.Query({ url: '/ajax/rec-management.html' }),

                recQuery = function(act) {

                    return function(data, cb) {

                        baseQuery.data = $.extend({
                            z: self.options.data && self.options.data.zone_name,
                            id: self.options.data && self.options.data.rec_id,
                            act: act
                        }, data);

                        self._trigger('_before_' + act);
                        self.hideAlert();
                        baseQuery.query(cb);
                        self._trigger('_' + act);
                    };
                };

            // self.queries
            // e.g. self.queries.newRec({recdata}, function(json) { ... });
            self.queries = {
                newRec: recQuery('rec_new'),
                loadRec: recQuery('rec_load'),
                editRec: recQuery('rec_edit'),
                deleteRec: recQuery('rec_delete'),
                proxyRec: recQuery('rec_proxy')
            };

            self.typeRe = /type-(\w*)/;

            self.ttlOptions = {
                1:     'Automatic',
                600:   '15 mins',
                900:   '30 mins',
                3600:  '1 hour',
                7200:  '2 hours',
                18000: '5 hours',
                43200: '12 hours',
                86400: '1 day'
            };

            self.outputHistory = [];

            if (self.options) {
                
                if (self.options.nodata || self.options.newrec) {

                    self._renderNoData();
                } else if (self.options.data) {

                    self._render();
                } else if (self.options.load) {

                    self._loadData(function(err, data) {

                        if (err) {

                            self._renderNoData();
                        } else {

                            self._render();
                        }
                    });
                } else {

                    self._renderNoData();
                }

                return this.element;
            }
            
        },

        _render: function() {

            var self = this,
                el = self.element,
                fields = self.getFields(),
                className = self.getClassName(),
                firstRow;

            self.preProcess();

            self.widgetElement = $(
                '<div class="dns-row '+className+'">' +
                    '<div class="row form compact"></div>' +
                    '<div class="row alerts"></div>' +
                '</div>'
            );

            firstRow = self.widgetElement.find('.row:first-child');

            $.each(fields, function(i, field) {
                firstRow.append(self.drawCell(field));
            });

            // draw non-field widget parts
            self.drawAlertPane(
                self.widgetElement.find('.row:last-child')
            );

            self.drawTabCapture();
            self.drawSavingOverlay();
            self.drawNoDataOverlay();
            self.drawDeletePane(firstRow);

            // insert widget into live DOM
            el.replaceWith(self.widgetElement);

            // enhancements
            //self.widgetElement.find('.cell.ttl select').combobox({height: '28px'});
            //self.widgetElement.find('.cell input, .cell select').valid();
            self.sizeOverlays();

            // bind event handlers
            self._attachHandlers();

            self.enable();

            return self.widgetElement;

        },

        _renderNoData: function() {

            var self = this;

            self.options.nodata = true;
            self.options.data = $.extend(self.getEmptyDataset(), self.options.data);

            return self._render();
        },

        getEmptyDataset: function() {
            return {
                zone_name: '',
                rec_id: '',
                type: 'A',
                name: '',
                content: '',
                prio: '',
                ttl: '',
                props: {
                    cloud_on: ''
                }
            };
        },

        // populate widget from API
        _loadData: function(callback) {

            var self = this;
            self.queries.loadRec(

                self.options.load,
                function(result) {

                    if (result['result'] != 'success') {
                        callback(result['msg'], result);
                    } else {
                        self.options.data = result['response']['rec']['obj'];
                        callback(null, result);
                    }
                }
            );
        },

        getFields: function() {
            return [
                'type',
                'alert-icon',
                'name',
                'value',
                'ttl',
                'active',
                'controls'
            ];
        },

        preProcess: function() {

            this.options.data.display_name = this.getDisplayName();
        },

        getClassName: function() {

            var type = this.options.data.type,
                isActive = this.options.data.props.cloud_on,
                editableClass = (this.options.editable ? '' : 'no-') + 'editable',
                hasDataClass = (this.options.nodata ? 'no-' : '') + 'data',
                isNewRecClass = (this.options.newrec ? ' new-rec editing' : ''),
                typeClass = 'type-' + type.toLowerCase(),
                isActiveClass = 'cloud-' + (isActive ? 'on' : 'bypass');

            return editableClass +
                ' ' + hasDataClass + 
                isNewRecClass +
                ' ' + typeClass +
                ' ' + isActiveClass;
        },

        drawCell: function(field) {
            // convert field from to dash-word-breaks to camelCase
            // e.g. alert-icon -> drawAlertIcon
            var self = this,
                drawMethod = "draw" + field.replace(/^(.)|[^a-z]([a-z])/g,function(g){return g.substr(-1).toUpperCase();}),
                cell = $('<div class="cell '+field+'"></div>');

            self[drawMethod](cell);
            return cell;
        },

        drawType: function(cell) {
            var type = this.options.data.type,
                typeOptions = {
                    'a': 'A',
                    'cname':'CNAME',
                    'mx':'MX',
                    'txt':'TXT',
                    'spf':'SPF',
                    'aaaa':'AAAA',
                    'ns':'NS',
                    'srv':'SRV',
                    'loc':'LOC'
                };
            cell.append(
                '<div class="highlight">'+type+'</div>' +
                '<select class="type-picker" tabindex="1"></select>'
            );
            $.cf.buildOptions(cell.find('select'), { data: typeOptions });
        },

        drawAlertIcon: function(cell) {
            var name = this.options.data.display_name;
            if (name == "direct") {
                cell.addClass('alert-info');
            } else if (name == "ssh") {
                cell.addClass('alert-info');
            } else if (name == "ftp") {
                cell.addClass('alert-info');
            }
        },
        
        drawName: function(cell) {
            var name = this.options.data.display_name;
            cell.append(
                '<span class="value-pane output name">'+name+'</span>' +
                '<span class="edit-pane"><input type="text" class="input name" value="'+name+'" tabindex="1" placeholder="e.g. www"/></span>'
            );
        },

        drawValue: function(cell) {
            var data = this.options.data,
                type = data.type,
                value = data.content,
                prio = data.prio;

            cell.append(
                '<span class="value-pane type-a">points to <strong class="output type-a-content">'+value+'</strong></span>' +
                '<span class="edit-pane type-a">points to <input type="text" class="input type-a-content" value="'+value+'" tabindex="1" placeholder"="e.g. 127.0.0.1"/></span>'
            );
            cell.append(
                '<span class="value-pane type-aaaa">points to <strong class="output type-aaaa-content">'+value+'</strong></span>' + 
                '<span class="edit-pane type-aaaa">points to <input type="text" class="input type-aaaa-content" value="'+value+'" tabindex="1" placeholder"="e.g. ::1"/></span>'
            );
            cell.append(
                '<span class="value-pane type-cname">is an ailas of <strong class="output type-cname-content">'+value+'</strong></span>' +
                '<span class="edit-pane type-cname">is an ailas of <input type="text" class="input type-cname-content" value="'+value+'" tabindex="1" placeholder"="e.g. mydomain.com"/></span>'
            );
            cell.append(
                '<span class="value-pane type-mx">mail handled by <strong class="output type-mx-content">'+value+'</strong></span>' +
                '<span class="value-pane type-mx">with priority <strong class="output type-mx-prio">'+prio+'</strong></span>' +
                '<span class="edit-pane type-mx">mail handled by <input type="text" class="input" value="'+value+'" tabindex="1" placeholder"="e.g. mydomain.com"/></span>' +
                '<span class="edit-pane type-mx">with priority <input type="text" class="input type-mx-prio" value="'+prio+'" tabindex="1"/></span>'
            );
            cell.append(
                '<span class="value-pane type-ns">managed by <strong class="output type-ns-content">'+value+'</strong></span>' +
                '<span class="edit-pane type-ns">managed by <input type="text" class="input type-ns-content" value="'+value+'" tabindex="1" placeholder"="e.g. a.nameserver.com"/></span>'
            );
            cell.append(
                '<span class="value-pane type-spf"><span class="output type-spf-content">'+value+'</span></span>' +
                '<span class="edit-pane type-spf"><textarea class="input type-spf-content" tabindex="1" placeholder"="SPF record value">'+value+'</textarea></span>'
            );
            cell.append(
                '<span class="value-pane type-txt"><span class="output type-txt-content">'+value+'</span></span>' +
                '<span class="edit-pane type-txt"><textarea class="input type-txt-content" tabindex="1" placeholder"="Text record value">'+value+'</textarea></span>'
            );
            cell.append(
                '<span class="value-pane type-loc"><span class="output type-loc-content">'+value+'</span></span>' +
                '<span class="edit-pane type-loc"><textarea class="input type-loc-content" tabindex="1" placeholder"="Loc record value">'+value+'</textarea></span>'
            );
        },

        drawTtl: function(cell) {
            var ttl = this.options.data.ttl,
                ttlOptions = this.ttlOptions,
                displayableTtl = ttl == "1" ? "Automatic" : (ttlOptions[ttl] || ttl);

            cell.append('<span class="value-pane output ttl">'+displayableTtl+'</span>');
            cell.append('<span class="edit-pane"><select class="input ttl" selected="'+ttl+'" tabindex="1"></select></span>');
            $.cf.buildOptions(cell.find('select'), { data: ttlOptions });
        },

        drawActive: function(cell) {
            var data = this.options.data,
                type = data.type,
                cloud_on = data.props.cloud_on,
                cloud_case;
            // TODO strip this out, obsolete with CSS rules
            if (type == "A" || type == "AAAA" || type == "CNAME") {
                cloud_case = cloud_on ? "on" : "bypass";
            } else {
                cloud_case = "na";
            }

            cell.append('<div class="cloud"></div>');
        },

        drawControls: function(cell) {
            cell.append(
                '<div class="gear"></div>' +
                '<div class="editing-controls">' +
                    '<a class="cancel" href="javascript:void(0);">Cancel</a>' +
                    '<a class="save button green" href="javascript:void(0);"><span class="label">Save</span></a>' +
                    '<a class="add button green" href="javascript:void(0);"><span class="label">Add</span></a>' +
                '</div>' +
                '<div class="panel gear-tooltip">' +
                    '<ul>' +
                        '<li class="edit">Edit record</li>' +
                        '<li class="delete">Delete record</li>' +
                    '</ul>' +
                '</div>'
            );
        },

        drawAlertPane: function(row) {
            var name = this.options.data.display_name,
                zone = this.options.data.zone_name,
                msg = $('<div class="alert panel"><div class="msg"></div></div>').appendTo(row).find('.msg');

            if (name == "direct") {
                this.showAlert('info', 'We added a subdomain that allows you to access your server directly without passing through the CloudFlare network. You should use this domain to access services like SSH, FTP, and Telnet. You can change the default name of the subdomain to something other than <strong>direct</strong> for enhanced security.');
            } else if (name == "ssh") {
                this.showAlert('info','We added a SSH subdomain for you that does not pass through the CloudFlare network. If in the past you SSHed directly to <strong>'+zone+'</strong>, now you should SSH to <strong>ssh.'+zone+'</strong>. You can change the default name of the subdomain to something other than <strong>ssh</strong> for enhanced security.');
            } else if (name == "ftp") {
                this.showAlert('info', 'We added a FTP subdomain for you that does not pass through the CloudFlare network. If in the past you FTPed directly to <strong>'+zone+'</strong>, now you should FTP to <strong>ftp.'+zone+'</strong>. You can change the default name of the subdomain to something other than <strong>ftp</strong> for enhanced security.');
            }
        },

        showAlert: function(type, message) {

            var el = this.widgetElement,
                alertRow = el.find('.row.alerts'),
                alertIcon = el.find('.cell.alert-icon');
            alertIcon.attr('class', 'cell alert-icon ' + type);
            alertRow.attr('class', 'row alerts active ' + type);
            alertRow.find('.msg').html(message);
        },

        hideAlert: function() {

            var el = this.widgetElement;
            el.find('.cell.alert-icon').attr('class', 'cell alert-icon');
            el.find('.row.alerts').attr('class', 'row alerts');
        },

        drawTabCapture: function() {

            this.widgetElement.append('<div class="hidden-field"><input type="text" class="last-input" tabindex="1"/></div>');
        },

        drawSavingOverlay: function() {

            this.widgetElement.append('<div class="dns-row-overlay saving-overlay"><div class="label"Verifying...</div></div>');
        },

        drawNoDataOverlay: function() {

            this.widgetElement.append('<div class="dns-row-overlay no-data-overlay"><div class="label">No data</div></div>');
        },

        drawDeletePane: function(cellRow) {

            cellRow.append(
                '<div class="cell delete-pane">' +
                    //'<span class="label"><label>Delete this record?</label></span> ' +
                    '<a class="cancel" href="javascript:void(0);">Cancel</a> ' +
                    '<a class="button red delete" href="javascript:void(0);"><span class="label">Delete</span></a>' +
                '</div>'
            );
        },

        sizeOverlays: function() {

            var el = this.widgetElement;
            el.find('.dns-row-overlay').css({
                width: el.width(),
                height: el.height()
            });
        },

        getDisplayName: function() {
            var zone = this.options.data.zone_name;
            var name = this.options.data.name;
            return name.replace('.'+zone, '');
        },

        _attachHandlers: function() {

            var self = this,
                el = self.widgetElement,
                controlsEl = el.find('.cell.controls'),
                deletePane = el.find('.cell.delete-pane'),
                cloudEl = el.find('.cell.active .cloud'),
                typePicker = el.find('.type-picker'),
                inputs = el.find('input[type="text"], input[type="password"], select'),
                lastInput = el.find('.last-input');

            controlsEl.find('.gear').click(function(e) {

                controlsEl.toggleClass('tooltip-active');
            });

            controlsEl.find('.edit').click(function(e) {

                controlsEl.removeClass('tooltip-active');
                el.addClass('editing');
                return false;
            });

            controlsEl.find('.delete').click(function(e) {

                controlsEl.removeClass('tooltip-active');
                el.addClass('confirm-delete');
                return false;
            });

            controlsEl.find('.save').click(function(e) {
                var toSubmittingMode = function() {
                        el.removeClass('editing');
                        el.addClass('submitting');
                    },
                    toEditingMode = function() {
                        el.removeClass('submitting');
                        el.addClass('editing');
                    },
                    inputs = self.findActiveInputs(),
                    data = {
                        type: self.getRowType().toUpperCase(),
                        name: el.find('.input.name').val(),
                        ttl: el.find('.input.ttl').val()
                    };

                self.syncOutputs();
                toSubmittingMode();

                setTimeout(function() {

                self.queries.editRec(data, function(json) {

                    console.log(json);
                    if (json['result'] != 'success') {

                        self.restoreOutputs()
                        toEditingMode();
                        self.showAlert('error', json['msg']);
                    } else {
                        el.removeClass('submitting');
                    }
                });

                }, 1000);
                return false;
            });

            controlsEl.find('.add').click(function(e) {
                var toSubmittingMode = function() {
                        el.removeClass('no-data new-rec editing');
                        el.addClass('data submitting');
                    },
                    toNewRecMode = function() {
                        el.removeClass('data submitting');
                        el.addClass('no-data new-rec editing');
                    };

                self.syncOutputs();
                toSubmittingMode();

                setTimeout(function() {

                self.queries.newRec({
                    type: self.getRowType().toUpperCase()

                }, function(json) {

                    console.log(json);
                    if (json['result'] != 'success') {

                        self.restoreOutputs();
                        toNewRecMode();
                        self.showAlert('error', json['msg']);
                    } else {
                        el.removeClass('submitting');
                    }
                });

                }, 1000);
                return false;
            });

            controlsEl.find('.cancel').click(function(e) {
                el.removeClass('editing');
                self.hideAlert();
                return false;
            });

            deletePane.find('.delete').click(function(e) {

                var timerDone = false, deleted = false;

                el.addClass('deleting');

                // don't hide row until timer done and API success
                setTimeout(function() {
                    timerDone = true;
                    if (deleted) { el.addClass('deleted'); }
                }, 1000);
                /*
                self.queries.deleteRec({}, function(json){

                    if (json['result'] == 'success') {
                        deleted = true;
                        if (timerDone) { el.addClass('deleted'); }
                    } else {
                        el.removeClass('deleting');
                    }
                });
                */
                return false;
            });

            deletePane.find('.cancel').click(function(e) {

                el.removeClass('confirm-delete');
                self.hideAlert();
                return false;
            });

            cloudEl.click(function(e) {

                var el = self.widgetElement,
                    cloud  = 'cloud',
                    on = cloud + '-on',
                    bypass = cloud + '-bypass',
                    toOn = function() {
                        el.removeClass(bypass);
                        el.addClass(on);
                    },
                    toBypass = function() {
                        el.removeClass(on);
                        el.addClass(bypass);
                    };

                if (el.hasClass(on)) {

                    toBypass();
                    self.queries.proxyRec({ service_mode: 0 }, function(json){
                        if (json['result'] != 'success') {
                            toOn();
                            self.showAlert('error', json['msg']);
                        }
                    });
                } else if (el.hasClass(bypass)) {

                    toOn();
                    self.queries.proxyRec({ service_mode: 1 }, function(json){
                        if (json['result'] != 'success') {
                            toBypass();
                            self.showAlert('error', json['msg']);
                        }
                    });
                }
            });

            // new record type picker: update type class on change
            typePicker.bind('change', function(e) {

                var target = $(e.target),
                    newType = 'type-' + target.val(),
                    oldClassName = el.attr('class');

                el.attr('class', oldClassName.replace(/(^| ) *type-(\w*) */g, " ") + ' ' + newType);
            });

            // Update the selection cursor as user tabs around
            inputs.bind('blur', function(e) {

                el.removeClass('selected')
            }).bind('focus', function(e) {

                el.addClass('selected')
            });

            // Hidden text input for keyboard control
            lastInput.bind('focus', function(e) {

                var isEditing = el.hasClass('editing'),
                    isNewRec = el.hasClass('new-rec'),
                    isSubmitting = el.hasClass('submitting');

                if (isNewRec && !isSubmitting) {
                    if (!self.findActiveInputs().filter(function(){ return $(this).val() == '' }).length) {
                        controlsEl.find('.add').click();
                    }
                } else if (isEditing) {
                    // fast-edit feature is disabled for now
                    //controlsEl.find('.save').click();
                }
            }).bind('keyup', function(e) {

                var code = e.keyCode || e.which,
                    isEditing = el.hasClass('editing'),
                    isNewRec = el.hasClass('new-rec'),
                    isDeletePromptMode = el.hasClass('confirm-delete'),
                    isBasicMode = !isEditing && !isNewRec && !isDeletePromptMode;

                switch (code) {
                    case 13 : // Enter
                    case 32 : // Space
                    case 69 : // e
                        isBasicMode && controlsEl.find('.edit').click();
                        break;
                    case 68 : // d
                        isBasicMode && controlsEl.find('.delete').click();
                        break;
                    case 27 : // Esc
                        !isNewRec && isEditing && controlsEl.find('.cancel').click();
                        isDeletePromptMode && deletePane.find('.cancel').click();
                        break;
                    case 38 : // Up
                    case 74 : // j
                        el.prev().find('.last-input').focus();
                        break;
                    case 40 : // Down
                    case 75 : // k
                        el.next().find('.last-input').focus();
                        break;
                }
            });
        },

        getRowType: function() {

            var className = this.widgetElement.attr('class');
            return this.typeRe.test(className) && this.typeRe.exec(className)[1] || '';
        },

        findActiveInputs: function() {

            var el = this.widgetElement,
                type = this.getRowType();
                isEditing = el.hasClass('editing'),
                isNewRec = el.hasClass('new-rec');

            if (isNewRec || isEditing) {

                return el.find('.cell.name input, .cell.value .edit-pane.type-'+type+' input');
            } else {

                return $();
            }
        },

        // state e.g. {
        //   'name': 'www',
        //   'type-a-content': '4.4.4.4'
        // }
        _setOutputState: function(state) {

            var self = this,
                el = self.widgetElement;

            // .input.* -> .output.*
            console.log('outputstate', state);
            $.each(state, function(key, value) {
                el.find('.output.'+key).text( value );
            });
        },

        syncOutputs: function() {

            var self = this,
                el = self.widgetElement,
                type = self.getRowType(),
                ttl = el.find('.input.ttl').val(),
                ttlOptions = self.ttlOptions,
                stateObj;
            self.backupOutputs();

            stateObj = {
                'name': el.find('.input.name').val(),
                'ttl': ttlOptions[ttl] || ttl
            };

            el.find('.edit-pane.type-'+type+' .input').each(function(i, input) {

                var $input = $(input),
                    className = $input.attr('class'),
                    re = new RegExp('type-'+type+'-\\w*'),
                    field = re.test(className) && re.exec(className)[0] || 'confused';

                stateObj[field] = $input.val();
            });

            self._setOutputState(stateObj);
        },

        backupOutputs: function() {

            var self = this,
                el = self.widgetElement,
                type = self.getRowType(),
                stateObj = {
                    'name': el.find('.output.name').text(),
                    'ttl': el.find('.output.ttl').text()
                };

            el.find('.value-pane.type-'+type+' .output').each(function(i, input) {

                var $input = $(input),
                    className = $input.attr('class'),
                    re = new RegExp('type-'+type+'-\\w*'),
                    field = re.test(className) && re.exec(className)[0] || 'confused';

                stateObj[field] = $input.text();
            });

            console.log('backup', stateObj);
            self.outputHistory.push(stateObj);
        },

        restoreOutputs: function() {

            var self = this;
            if (self.outputHistory.length) {
                self._setOutputState(self.outputHistory.pop());
            }
        },

        widget: function() {
            
            return this.widgetElement;
            
        },
        
        enable: function() {
            
            this.enabled = true;
            
        },
        
        disable: function() {
            
            this.enabled = false;
            
        },
        
        _cancel: function() {

            this.options.complete(false);

            this.destroy();
        },

        _done: function() {

            this.options.complete(true);

            this.destroy();
        },
            
        destroy: function() {

            $.Widget.prototype.destroy.apply(this, arguments); // default destroy

            this.widgetElement.remove();
            
        }
        
    });

})(jQuery);

/*******************************************************************************
 *
 * CloudFlare UI DNS Table Component
 * 
 * @author Jason Benterou
 * 
 * Copyright 2010 CloudFlare, Inc.
 *
 * Visualize all DNS records for a zone.
 *
 * Populate data via lookup (options.load)
 *
 ******************************************************************************/
 
(function($) {

    $.widget(
        'ui.dnsTable', 
        $.ui.cloudflareWidget,
        {
        
        // default options
        options: {
            editable: true,
            load: null
        },
        
        _create: function() {
            
            if (this.options) {
                
                var self = this;

                self._renderFrame();

                if (!self.options.data && self.options.load) {

                    self.zone_name = self.options.load.z;

                    self._loadData(function(err, data) {

                        if (err || !data.response.recs.objs) {

                            self._renderNoData();
                        } else {

                            self._renderData();
                        }
                    });
                } else if (self.options.data) {

                    self.zone_name = self.options.data.zone_name;

                    self._renderData();
                } else {

                    self._renderNoData();
                }

                return this.element;
            }
            
        },

        _renderFrame: function() {

            // iterate through data records
            var self = this,
                el = self.element,
                header,
                fields = [
                    'Type',
                    'Name',
                    'Value',
                    'TTL',
                    'Active'
                ];

            self.widgetElement = $('<div class="dns-table"><div class="dns-table-header"></div></div>');

            header = self.widgetElement.find('.dns-table-header');

            $.each(fields, function(i, field) {
                header.append('<div class="cell header header-'+field.toLowerCase()+'"><span>'+field+'</span></div>');
            });

            self.widgetElement.appendTo(self.element);
            self.enable();

            return self.widgetElement;

        },

        _renderData: function() {

            var self = this;

            $.each(self.options.data, function(i, rec) {

                var row = $('<div></div>').appendTo(self.widgetElement);
                row.dnsRec({ data: rec });
            });

            self.addNewRecRow();
        },

        addNewRecRow: function() {

            var self = this,
                lastRow;

            lastRow = $('<div></div>').appendTo(self.widgetElement);
            lastRow.dnsRec({ newrec: true, data: { zone_name: self.zone_name } });
            lastRow.bind(
                'dnsrec_rec_new',
                function(e) {
                    self.addNewRecRow();
                }
            );
        },

        _renderNoData: function() {

            var self = this,

            // create a rec row with no data
                row = $('<div></div>').appendTo(self.widgetElement);

            row.dnsRec();
        },

        // populate widget from API
        _loadData: function(callback) {

            var self = this,
                query = new $.cf.Query({

                url: '/ajax/rec-management.html',
                data: { act: 'rec_load_all' },

                mapResponse: function(result) {
                    if (result['result'] != 'success') {
                        callback(result['msg'], result);
                    } else {
                        self.options.data = result['response']['recs']['objs'];
                        callback(null, result);
                    }
                }
            });

            $.extend(query.data, this.options.load);
            query.query();
        },

        widget: function() {
            
            return this.widgetElement;
            
        },
        
        enable: function() {
            
            this.enabled = true;
            
        },
        
        disable: function() {
            
            this.enabled = false;
            
        },
        
        _cancel: function() {

            this.options.complete(false);

            this.destroy();
        },

        _done: function() {

            this.options.complete(true);

            this.destroy();
        },
            
        destroy: function() {

            $.Widget.prototype.destroy.apply(this, arguments); // default destroy

            this.widgetElement.remove();
            
        }
        
    });
    
})(jQuery);

/*******************************************************************************
 *
 * CloudFlare Universal Support Search Component
 * 
 * @author Christopher Joel
 * 
 * Copyright 2010 CloudFlare, Inc.
 * 
 ******************************************************************************/

(function($) {
    
    $(function() {
        
        $('#UniversalSearch').lookingGlass(
            {
                selected: function(event, ui) {
                    
                    window.location = ui.item.link;
                    
                },
                preserveOrder: true,
                displayEmptySources: false,
                source: [
                    new $.cf.Query(
                        {
                            name: 'Frequently Asked Questions',
                            url: '/ajax/search-3rd.html',
                            mapQuery: function(query) {
                                return { q: query.data.q.split(' ').join(','), faq: 1 };
                            },
                            mapResponse: function(response) {
                                
                                return {
                                    name: this.name,
                                    results: response.result != "error" && response.faq.count > 0 ? $.map(
                                        response.faq.objs,
                                        function(r, i) {
                                            
                                            return {
                                                type: 'faq',
                                                label: r.title, 
                                                summary: r.excerpt.substr(0, 100) + "...",
                                                link: r.link,
                                                data: r
                                            };
                                        }
                                    ) : []
                                }
                            }
                        }
                    ),
                    new $.cf.Query(
                        {
                            name: 'Knowledge Base',
                            url: '/ajax/search-3rd.html',
                            mapQuery: function(query) {
                                return { q: query.data.q.split(' ').join(',') };
                            },
                            mapResponse: function(response) {
                                
                                return {
                                    name: this.name,
                                    results: response.result != "error" && response.tender.count > 0 ? $.map(
                                        response.tender.objs,
                                        function(r, i) {
                                            
                                            return {
                                                type: 'kb',
                                                label: r.title,
                                                summary: r.excerpt.substr(0, 100) + "...",
                                                link: r.link,
                                                data: r
                                            };
                                        }
                                    ) : []
                                }
                            }
                        }
                    ),
                    new $.cf.Query(
                        {
                            name: 'Wiki',
                            url: '/wiki/api.php',
                            mapQuery: function(query) {
                                
                                return {
                                    srsearch: escape(query.data.q),
                                    action: "query",
                                    list: "search",
                                    srwhat: "text",
                                    format: "json"
                                };
                            },
                            mapResponse: function(response) {
                                
                                return {
                                    name: this.name,
                                    results: response.query && response.query.search.length > 0 ? $.map(
                                        response.query.search,
                                        function(r, i) {
                                            
                                            return {
                                                type: 'wiki',
                                                label: r.title,
                                                summary: "",
                                                link: "/wiki/index.php?title=" + r.title,
                                                data: r
                                            };
                                        }
                                    ) : []
                                }
                            }
                        }
                    )
                ]
            }
        );
    });
})(jQuery);

/* @depends ../javascripts/library/cloudflare.core.js
 * @depends ../javascripts/library/cloudflare.client.js
 * @depends ../javascripts/library/cloudflare.media.js
 * @depends ../javascripts/library/cloudflare.tracking.js
 * @depends ../javascripts/library/cloudflare.statichash.js
 * @depends ../javascripts/library/cloudflare.validation.js
 * @depends ../javascripts/library/ui/cloudflare.ui.js
 * @depends ../javascripts/library/ui/cloudflare.ui.billing.js
 * @depends ../javascripts/library/ui/cloudflare.ui.rowtray.js
 * @depends ../javascripts/library/ui/cloudflare.ui.toggle.js
 * @depends ../javascripts/library/ui/cloudflare.ui.datalist.js
 * @depends ../javascripts/library/ui/cloudflare.ui.markedselector.js
 * @depends ../javascripts/library/ui/cloudflare.ui.dashboardmodule.js
 * @depends ../javascripts/library/ui/cloudflare.ui.dashboard.js
 * @depends ../javascripts/library/ui/cloudflare.ui.listitemrenderer.js
 * @depends ../javascripts/library/ui/cloudflare.ui.list.js
 * @depends ../javascripts/library/ui/cloudflare.ui.combobox.js
 * @depends ../javascripts/library/ui/cloudflare.ui.multiselect.js
 * @depends ../javascripts/library/ui/cloudflare.ui.logbook.js
 * @depends ../javascripts/library/ui/cloudflare.ui.lookingglass.js
 * @depends ../javascripts/library/ui/cloudflare.ui.progressbar.js
 * @depends ../javascripts/library/ui/cloudflare.ui.bitfield.js
 * @depends ../javascripts/library/ui/cloudflare.ui.keycode.js
 * @depends ../javascripts/library/ui/cloudflare.ui.dnsrec.js
 * @depends ../javascripts/library/ui/cloudflare.ui.dnstable.js
 * @depends ../javascripts/library/cloudflare.support.js
 */

