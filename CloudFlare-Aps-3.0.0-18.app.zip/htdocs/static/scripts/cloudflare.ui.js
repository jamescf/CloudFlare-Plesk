/*******************************************************************************
 *
 * CloudFlare UI core classes and utility methods.
 * 
 * @author Christopher Joel
 * 
 * Copyright 2010 CloudFlare, Inc.
 * 
 ******************************************************************************/

(function($) {

/*******************************************************************************
 *
 * Helper functions for determining dimensions, positions and other properties
 *
 ******************************************************************************/
    $.extend(
        $.cf,
        {
            windowProperties: function() {
                
                // TODO: X & Y are not reporting properly across all browsers..
                // TODO: Determine which properties to check based on cloudflare.client.js
                var width = 0;
                var height = 0;
                var x = 0;
                var y = 0;
                
                if (window.document.innerHeight && window.document.innerHeight > 0) {
                    width = window.document.innerWidth;
                    height = window.document.innerHeight;
                    x = window.pageXOffset;
                    y = window.pageYOffset;
                } else if (window.document.documentElement.clientHeight && window.document.documentElement.clientHeight > height) {
                    width = window.document.documentElement.clientWidth;
                    height = window.document.documentElement.clientHeight;
                    x = document.documentElement.scrollLeft;
                    y = document.documentElement.scrollTop;
                } else if (window.document.body.clientHeight && window.document.body.clientHeight > height) {
                    width = window.document.body.clientWidth;
                    height = window.document.body.clientHeight;
                    x = document.body.scrollLeft;
                    y = document.body.scrollTop;
                }
                
                return { width: width, height: height, x: x, y: y };
            },
            normalizeCSSMeasurement: function(measure) {
                
                measure = $.isFunction(measure) ? measure() : measure;
                
                if(typeof measure == 'number' || (typeof measure == 'string' && !(measure.substr(measure.length - 2, 2) == "px" || measure.substr(measure.length - 1, 1) == "%"))) {
                    
                    return measure + "px";
                    
                }
                
                return measure;
                
            },
            normalizeDigitalMeasurement: function(measure) {
                
                measure = $.isFunction(measure) ? measure() : measure;
                
                if(typeof measure == 'string') {
                    
                    if(measure.substr(measure.length - 2, 2) == "px") {
                        
                        return parseInt(measure.substr(0, measure.length - 2));
                        
                    } else if(measure.substr(measure.length - 1, 1) == "%") {
                        
                        return -1;
                        
                    }
                    
                    return parseInt(measure);
                    
                }
                
                return measure;
                
            }
        }
    );
    
    $.extend(
        $.fn,
        {
            margin: function() {
                
                var marginTop = this.css('marginTop').substr(0, this.css('marginTop').length - 2);
                var marginBottom = this.css('marginBottom').substr(0, this.css('marginBottom').length - 2);
                var marginLeft = this.css('marginLeft').substr(0, this.css('marginLeft').length - 2);
                var marginRight = this.css('marginRight').substr(0, this.css('marginRight').length - 2);
                
                return {
                    
                    top: marginTop,
                    bottom: marginBottom,
                    left: marginLeft,
                    right: marginRight,
                    horizontal: marginLeft + marginRight,
                    vertical: marginTop + marginBottom
                    
                };
            },
            
            marginalWidth: function() { return this.width() + this.margin().horizontal; },
            marginalInnerWidth: function() { return this.innerWidth() + this.margin().horizontal; },
            marginalOuterWidth: function() { return this.outerWidth() + this.margin().horizontal; },
            marginalHeight: function() { return this.height() + this.margin().vertical; },
            marginalInnerHeight: function() { return this.innerHeight() + this.margin().vertical; },
            marginalOuterHeight: function() { return this.outerHeight() + this.margin().vertical; },
            scrollTopMax: function() { return this.get(0).scrollHeight - this.innerHeight(); }
        }
    );
    
/*******************************************************************************
 *
 * CloudFlare Request & Multi-request
 *
 * Helper classes for containing information pertaining to ajax requests.
 * 
 ******************************************************************************/
    
    $.cf.Request = function(options) {
        
        $.extend(this, options);
        
    };
    
    $.cf.Request.prototype = {
        name: "",
        url: "",
        data: {},
        type: "GET",
        formatQuery: function(query) { 
            return query; 
        },
        formatResponse: function(response) { 
            this.lastResult = response; 
            return response; 
        },
        clone: function() {
            return $.extend({}, this);
        }
    };
    
    // TODO: Remove dependencies on this class, since it is useless...
    $.cf.MultiRequest = function(requests) {
        this.requests = requests ? requests : [];
    };
    
    $.cf.MultiRequest.prototype = {
        
        requests: [],
        addRequest: function(request) {
            if(request instanceof $.cf.Request) {
                
                this.requests.push(nameOrRequest);
                
            } else {
                
                this.requests.push(new $.cf.Request(request));
                
            }
        },
        clone: function() {
            return $.extend({}, this);
        }
    };

/*******************************************************************************
 *
 * CloudFlare Query
 *
 * The Query is an evolved version of the Request class, which acts as a
 * portable, fully self-contained AJAX mechanism to simplify and standardize
 * the calling of remote CloudFlare services. For the sake of simplicity, 
 * only JSON services are currently supported.
 * 
 ******************************************************************************/

    $.cf.Query = function(options) {
        var self = this;
        $.extend(self, options);
    };
    
    $.cf.Query.prototype = {
        id: "",
        url: "",
        data: {},
        type: "GET",
        async: true,
        cache: true,
        lastResponse: null,
        mapQuery: function(query) {
            return query.data;
        },
        mapResponse: function(response) {
            return response;
        },
        query: function(complete) {
            
            var self = this,
                atok = $('#ActionToken').length ? $('#ActionToken').val() : false;

            complete = complete ? complete : $.noop;

            if(self.url && self.url != "") {
                $.ajax(
                    {
                        url: self.url,
                        type: self.type,
                        async: self.async,
                        data: (function() {

                            var data = self.mapQuery(self);

                            if(atok) {
                                $.extend(
                                    data,
                                    {
                                        atok: atok
                                    }
                                );
                            }

                            return data;
                        })(),
                        dataType: 'json',
                        error: function() {
                            $.cf.log('There was an error making an AJAX call to ' + self.url, $.cf.logType.error);
                            complete(false);
                        },
                        success: function(json, status, xhr) {
                            
                            self.lastResponse = json;

                            if(json.result === 'error' && 'redirect' in json && json.redirect.details === 'invalid_atok') {

                                $.cf.notify('Your session needs to be refreshed, or your network settings have changed. Please refresh the page and try again. If the problem continues, please contact support!', $.cf.noteType.alert);
                                complete(false);
                            } else {

                                complete(self.mapResponse(json), self);
                            }
                        }
                    }
                );
            } else {
                
                complete(self.mapResponse(self.mapQuery(self)));
                
            }
        }
    };


/*******************************************************************************
 *
 * CloudFlare Widget
 * 
 * An abstract base class for all future CloudFlare UI Widgets.
 *
 ******************************************************************************/

    $.widget(
        'ui.cloudflareWidget',
        {
            invalidateOption: function(key) {
                
                var self = this;
                var property = '_invalidate' + key.substr(0, 1).toUpperCase() + key.substr(1, key.length - 1);
                
                if(property in self) {
                    
                    self[property]();
                    
                }
            }
        }
    );
    
})(jQuery);
