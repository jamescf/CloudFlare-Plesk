/**
* Copywrite 2011 CloudFlare, Inc.
*
* @author Ian Pye, Jason Benterou, Ramakrishna Nadella 
*/

var OPEN_HELP = -1;
var VALID = [];

/*
 * Cached data describing the DNS zone table
 */
// Set of DNS entries with CF enabled
var CF_RECS = {};

// Total number of records, CNAME + A
var NUM_RECS = 0;

// Tooltips for each DNS record
var REC_TEXT = [];

// Record info for the WWW record
var WWW_DOM_INFO = [];

// Placeholder for when we are in stats mode.
var DNS_HTML = "";

// Quick first stab at localization - some strings are still in the wild
var CF_LANG = {

    'creating_account' : "Creating Your CloudFlare Account. This may take several minutes.",

    'signup_welcome' : "Welcome to CloudFlare",

    'signup_info' : "Generate a CloudFlare password <a href=\"https://www.cloudflare.com/forgot-password.html\" target=\"_blank\">here</a>. Your CloudFlare email is curently set to {email}. Click <a href=\"\">here</a> to continue.",

    'tooltip_zone_cf_off' : "CloudFlare is currently off. Click to enable",

    'tooltip_zone_cf_on' : "CloudFlare is currently on. Click to disable"
};

// args is optional, only for strings which need params
var get_lang_string = function(keyname, args) {

    var translation = CF_LANG[keyname],
        args = args || {};

    if (translation) {

        try {
            return YAHOO.lang.substitute(translation, args);
        } catch (e) {}

    }
    return '';
}

var signup_to_cf = function() {

    var signup_welcome, signup_info, creating_account;
	var spin_url          = "../static/images/wait26trans.gif";
    var signup_html       = '<input type="submit" class="input-button" value="Login Now!" id="USER_submit" />';

    // build the call
    var query = new $.cf.Query({
        url: "ajax/cf.php",
        type: 'post',
        data: {        
            act:           'user_auth',
            user_email:    $('#USER_email').val(),
            user_pass:     $('#USER_pass').val(),
            domain_name:   CURRENT_ZONE_NAME,   
        }
    });

    $('#USER_email_error').html('<img src='+spin_url+'>');
    $('#add_USER_record_button').css("display", "none");
    
    query.query(function(json) {
        if(json && json.result != "error") {

            if (json.need_update) {
                $.cf.notify('There is a new version of CloudFlare availible. Contact your hosting provider to get the latest code.');
            }

            $.cf.notify('Login OK, continuing in two seconds.');
            setTimeout('window.location.reload(true)', 2000);
            $('#add_USER_record_button').css("display", "none");
            $('#USER_email_error').html('');
        } else {

            $('#USER_email_error').html('');            
            $('#add_USER_record_button').css("display", "block");
            if(json) {
				$.cf.notify(json.msg, $.cf.noteType.error);
	            $('tr#cf_pass_noshow').show();
				$("div#add_USER_record_button input").attr("value", "Login");
			} else {
                $.cf.notify('There was an error submitting your request. If the problem persists, please contact support@cloudflare.com', $.cf.noteType.error);
            }
        }
    });
};

// Activate a product licence.
var activate_licence = function() {

    var signup_welcome, signup_info, creating_account;
	var spin_url          = "../static/images/wait26trans.gif";
    var signup_html       = '<input type="submit" class="input-button" value="Submit Licence" id="ZONE_lic_submit" />';
    var psa_key           = $('#ZONE_lic').val();

    if (!psa_key) {
        $.cf.notify("Invalid Licence", $.cf.noteType.error);
        return false;
    }

    // build the call
    var query = new $.cf.Query({
        url: "ajax/cf.php",
        type: 'post',
        data: {        
            act:           'reseller_sub_new',
            zone_name:     CURRENT_ZONE_NAME,
            user_email:    USER_EMAIL,
            user_name:     USER_NAME,
            user_key:      USER_KEY,
            user_api_key:  USER_API_KEY,
            dom_id:        DOM_ID,
            psa_key:       $('#ZONE_lic').val()
        }
    });

    $('#ZONE_lic_submit').css("display", "none");
    
    query.query(function(json) {
        if(json && json.result != "error") {
            $.cf.notify('Activation Successful');
            // Remember this for a while.
            document.cookie = "CF_PSA_LIC" + '=' + "YES" + '; expires=' + (new Date((new Date()).getTime() + 1 * 24 * 60 * 60 * 1000)).toUTCString() + '; path=/';
                        
            $('#cf_def_show_lic').css('display', "none"); 
            $('#cf_def_noshow_lic').css('display', "none"); 
        } else {
            $('#ZONE_lic_submit').css("display", "block");
            if(json) {
				$.cf.notify(json.msg, $.cf.noteType.error);
			} else {
                $.cf.notify('There was an error submitting your request. If the problem persists, please contact support@cloudflare.com', $.cf.noteType.error);
            }
        }
    });
};

// Handle a click on the cloud
// Enable or disable CloudFlare for the domain

var zone_change_status = function(zone_name, zone_content) {
	
	var spin_url          = "../static/images/wait26trans.gif";
	var orange_cloud_url  = "../static/images/solo_cloud-55x25.png";
	var grey_cloud_url    = "../static/images/solo_cloud_off-55x25.png";
    var complete_url;
    var complete_text;

	// change status of the clicked domain
	for (var i=0; i < CF_AVAILABLE_RECS.length; i++) {
		if (CF_AVAILABLE_RECS[i]["name"] === zone_name) {
			CF_AVAILABLE_RECS[i]["on_cf"] = CF_AVAILABLE_RECS[i]["on_cf"]? 0 : 1;
		}
	}
	
	// build the enabled zones object
	var enabled_zones = [];
	for (var i=0; i < CF_AVAILABLE_RECS.length; i++) {
		if (CF_AVAILABLE_RECS[i]["on_cf"] == 1) {
            enabled_zones.push(CF_AVAILABLE_RECS[i]["name"]);
		}
	}

    // Set the correct spinning icon.
	if ($("td.cloudflare_status img[data-name='"+zone_name+"']").attr("src") == orange_cloud_url) {
		complete_url  = grey_cloud_url;
        complete_text = 'CloudFlare disabled for ' + zone_name;
	} else {
        complete_url  = orange_cloud_url;
        complete_text = 'CloudFlare enabled for ' + zone_name;
	}	
	$("td.cloudflare_status img[data-name='"+zone_name+"']").attr("src", spin_url);

	// send the zone change request to the server
	var query = new $.cf.Query({
        url: "ajax/cf.php",
        type: 'post',
        data: {        
            act:           'zone_set',
			subdomains:    enabled_zones.join(","),
            zone_name:     CURRENT_ZONE_NAME,
            user_email:    USER_EMAIL,
            user_name:     USER_NAME,
            user_key:      USER_KEY,
            user_api_key:  USER_API_KEY,
            dom_id:        DOM_ID
        }
    });

	query.query(function(json) {
		if(json && !json.error) {
			$("td.cloudflare_status img[data-name='"+zone_name+"']").attr("src", complete_url);
			$.cf.notify(complete_text);
		} else {
            if (json && json.msg) {
			    $.cf.notify(json.msg, $.cf.noteType.error);
            } else {
                $.cf.notify('There was an error making the zone change you requested', $.cf.noteType.error);

                // Change the status up again.
                for (var i=0; i < CF_AVAILABLE_RECS.length; i++) {
		            if (CF_AVAILABLE_RECS[i]["name"] === zone_name) {
			            CF_AVAILABLE_RECS[i]["on_cf"]  = CF_AVAILABLE_RECS[i]["on_cf"]? 0 : 1;
		            }
	            }
            }
		}
	});
};

var reset_form = function(type) {
    VALID = [];
    CF_RECS = {};
    NUM_RECS = 0;
    REC_TEXT = [];
    WWW_DOM_INFO = [];
};

var add_validation = function() {
     
};

var handleShowLic = function (show) {
    if (show) {
        $('#cf_def_show_lic').css('display', "none"); 
        $('#cf_def_noshow_lic').css('display', "block"); 
    } else {
        $('#cf_def_show_lic').css('display', "block"); 
        $('#cf_def_noshow_lic').css('display', "none"); 
    }
    return false;
}

var handleLearnMore = function (show) {
    if (show) {
        $('#cf_def_show').css('display', "none"); 
        $('#cf_def_noshow').css('display', "block"); 
    } else {
        $('#cf_def_show').css('display', "block"); 
        $('#cf_def_noshow').css('display', "none"); 
    }
    return false;
}

var showHelp = function(type) {

    var help_contents = {
        "devmode" : "CloudFlare makes your website load faster by caching static resources like images, CSS and Javascript. If you are editing cachable content (like images, CSS, or JS) and want to see the changes right away, you should enter <b>Development mode</b>. This will bypass CloudFlare's cache. Development mode will automatically toggle off after <b>3 hours</b>. Hint: Press shift-reload if you do not see your changes immediate. If you forget to enter Development mode, you should log in to your CloudFlare.com account and use Cache Purge.",
        "seclvl" : " CloudFlare provides security for your website and you can adjust your security setting for each website. A <b>low</b> security setting will challenge only the most threatening visitors. A <b>high</b> security setting will challenge all visitors that have exhibited threatening behavior within the last 14 days. We recommend starting with a high or medium setting.",
        "uniques" : "Visitors are classified by regular traffic, search engine crawlers and threats. Unique visitors is defined by unique IP addresses.",
        "visits" : "Traffic is classified by regular, search engine crawlers and threats. Page Views is defined by the number of requests to your site which return HTML.",
        "pageload" : "CloudFlare visits the home page of your website from several locations around the world from shared hosting. We do the same request twice: once through the CloudFlare system, and once directly to your site, so bypassing the CloudFlare system. We report both page load times here. CloudFlare improves the performance of your website by caching static resources like images, CSS and Javascript closer to your visitors and by compressing your requests so they are delivered quickly.",
        "hits" : "CloudFlare sits in front of your server and acts as a proxy, which means your traffic passes through our network. Our network nodes are distributed all over the world. We cache your static resources like images, CSS and Javascript at these nodes and deliver them to your visitors in those regions. By serving certain resources from these nodes, not only do we make your website load faster for your visitors, but we save you requests from your origin server. This means that CloudFlare offsets load so your server can perform optimally. CloudFlare does not cache html.",
        "bandwidth" : "Just like CloudFlare saves you requests to your origin server, CloudFlare also saves you bandwidth. By serving cached content from CloudFlare's nodes and by stopping threats before they reach your server, you will see less bandwidth usage from your origin server.",       
        "fpurge_ts":"Immediately purge all cached resources for your website. This will force CloudFlare to expire all static resources cached prior to the button click and fetch a new version.",
        "ipv46":"Automatically enable IPv6 networking for all your orange-clouded websites. CloudFlare will listen to <a href='http://en.wikipedia.org/wiki/IPv6'>IPv6</a> even if your host or server only supports IPv4. In safe mode, support will be limited to websites under ipv6." + CURRENT_ZONE_NAME + ".",
        "ob":"Automatically enable always online for web pages that lose connectivity or time out. Seamlessly bumps your visitors back to normal browsing when your site comes back online.",
        "cache_lvl":"Adjust your caching level to modify CloudFlare's caching behavior. The <b>basic</b> setting will cache most static resources (i.e., css, images, and JavaScript). The <b>aggressive</b> setting will cache all static resources, including ones with a query string.<br /><br />Basic: http://supertriceratops.com/pic.jpg<br />Aggressive: http://supertriceratops.com/pic.jpg?with=query",
        "pro":"Choose a paid plan to get more out of CloudFlare! Contact your hosting provider for more information."
    };

    if ('DN' in window) {

        var help_lightbox;
        if ('CF' in window && 'lightbox' in window.CF) {
            help_lightbox = window.CF.lightbox;
            help_lightbox.cfg.contentString = help_contents[type];
        } else {
            window.CF = window.CF || {};
            window.CF.lightbox = help_lightbox = new DN.Lightbox({
                contentString: help_contents[type],
                animate: false,
                maxWidth: 500
            });
        }
        help_lightbox.show.call(help_lightbox, this);
    }

    return false;
}

var change_cf_accnt = function() {
    window.open('https://www.cloudflare.com/cloudflare-settings.html?z='+CURRENT_ZONE_NAME,'_blank');    
}

var get_dns = function(domain) {
    $('#user_records_div').html(DNS_HTML);
    return false;
}

var cf_api_error = function() {
    $.cf.notify('There was an error retrieving the requested data', $.cf.noteType.error);
};
var change_cf_setting = function (domain, action, value) {

    var set_val = value;
    if (value == "SecurityLevelSetting") {
        set_val = $('#SecurityLevelSetting').val();
    } else if (value == "AlwaysOnline") {
        set_val = $('#AlwaysOnline').val();
    } else if (value == "AutomaticIPv6") {
        set_val = $('#AutomaticIPv6').val();
    } else if (value == "CachingLevel") {
        set_val = $('#CachingLevel').val();
    }

    var data =  {        
        a:           action,
        v:           set_val,
        z:           CURRENT_ZONE_NAME,
        u:           USER_EMAIL,
        t:           USER_API_KEY
    };

    $.ajax({
        type:      'post',
        url:       CF_USER_API_ENDPOINT + "?callback=?",
        dataType:  'json',
        data:      data,
        success:   function(data, textStatus, jqXHR) {
            $.cf.notify('Setting Updated');
        },
	error:     cf_api_error
    });
    return false;
}

var get_stats = function(domain) {
    
    var success = function(data, textStatus, jqXHR) {

        if (data.result != "success") {
            
            cf_api_error();

	    } else {

            // Display stats here.
            var result = data.response.result;
            var stats = result.objs[0];

            var numberFormat = {decimalPlaces:0, decimalSeparator:".", thousandsSeparator:","};
            var numberFormatFloat = {decimalPlaces:2, decimalSeparator:".", thousandsSeparator:","};
            var start = new Date(parseInt(result.timeZero));
            var end = new Date(parseInt(result.timeEnd));
            var html;

            html = '<h3><a href="javascript:void(0);" onclick="return get_dns(false);">Your DNS Records</a> | Analytics and Settings  | <a href="?logout=1">Log Out</a></h3>';

            if (false) { // start > end
                html += "<p>Basic statistics update every 24 hours for the free service. For 15 minute statistics updates, advanced security and faster performance, upgrade to the <a href=\"https://www.cloudflare.com/pro-settings.html\" target=\"_blank\">Pro service</a>.</p>";
            } else {
                var start_fm = YAHOO.util.Date.format(start, {format:"%B %e, %Y"});
                var end_fm = YAHOO.util.Date.format(end, {format:"%B %e, %Y"});
		html += '<div id="basic-stats">';
                if (start_fm === end_fm) {
                    html += "<p><h4>Basic Statistics for " + CURRENT_ZONE_NAME +
                        " &middot; " + start_fm + "</h4></p>";
                } else {
                    html += "<p><h4>Basic Statistics for " + CURRENT_ZONE_NAME +
                        " &middot; " + start_fm 
                        + " to "+ end_fm + "</h4></p>";
                }
	            html += '<table id="table_dns_zone" class="dynamic_table" border="0" cellspacing="0" width="1000">';
                html += '<tr align="left">';
                html += 	'<th width="100">&nbsp;</th>';
                html += 	'<th>regular traffic</th>';
                html += 	'<th>crawlers/bots</th>';
                html += 	'<th>threats</th>';
                html += 	'<th>info</th>';
                html += '</tr>';
                
                html += '<tr>';
                html += 	'<td width="100">Page Views</td>';
                html += 	'<td style="text-align:center;">'+YAHOO.util.Number.format(parseInt(stats.trafficBreakdown.pageviews.regular), numberFormat)+'</td>';
                html += 	'<td style="text-align:center;">'+YAHOO.util.Number.format(parseInt(stats.trafficBreakdown.pageviews.crawler), numberFormat)+'</td>';
                html += 	'<td style="text-align:center;">'+YAHOO.util.Number.format(parseInt(stats.trafficBreakdown.pageviews.threat), numberFormat)+'</td>';
                html +=     '<td style="text-align:center;"><image src="../static/images/Info_16x16.png" width="13" height="13" class="info-icon" onclick="showHelp(\'visits\')"></td>';
                html += '</tr>';
                
                html += '<tr>';
                html += 	'<td width="100">Unique Visitors</td>';
                html += 	'<td style="text-align:center;">'+YAHOO.util.Number.format(parseInt(stats.trafficBreakdown.uniques.regular), numberFormat)+'</td>';
                html += 	'<td style="text-align:center;">'+YAHOO.util.Number.format(parseInt(stats.trafficBreakdown.uniques.crawler), numberFormat)+'</td>';
                html += 	'<td style="text-align:center;">'+YAHOO.util.Number.format(parseInt(stats.trafficBreakdown.uniques.threat), numberFormat)+'</td>';
                html +=     '<td style="text-align:center;"><image src="../static/images/Info_16x16.png" width="13" height="13" class="info-icon" onclick="showHelp(\'uniques\')"></td>';
                html += '</tr>';
                html += '</table>';
		html += '</div>';
                
                //html += '<p><table id="table_dns_zone" class="dynamic_table" border="0" cellspacing="0" cellpadding="0">';
                //html += '<tr><td>';
                
                var total_reqs = YAHOO.util.Number.format(parseInt(stats.requestsServed.cloudflare + stats.requestsServed.user), 
                    numberFormat);
                var saved_reqs = YAHOO.util.Number.format(parseInt(stats.requestsServed.cloudflare), numberFormat);
                var percent_reqs = (parseInt(stats.requestsServed.cloudflare) / parseInt(stats.requestsServed.cloudflare + stats.requestsServed.user) * 100); 
                if (isNaN(percent_reqs)) {
                    percent_reqs = 0;
                }
                
                var total_bw = parseFloat(stats.bandwidthServed.cloudflare) + parseFloat(stats.bandwidthServed.user);
                var saved_bw = parseFloat(stats.bandwidthServed.cloudflare);
                var percent_bw = (saved_bw / total_bw) * 100.;
                if (isNaN(percent_bw)) {
                    percent_bw = 0;
                }
                
                var total_units_bw = " KB";
                var saved_units_bw = " KB";
                if (total_bw >= 102.4) {
                    total_bw /= 1024.0;
                    total_units_bw = " MB";
                }
                if (saved_bw >= 102.4) {
                    saved_bw /= 1024.0;
                    saved_units_bw = " MB";
                }
                total_bw = YAHOO.util.Number.format(total_bw, numberFormatFloat);
                saved_bw = YAHOO.util.Number.format(saved_bw, numberFormatFloat);
                
                var without_time = 0;
                var cloudflare_time = 0;
                var percent_time = 0;
                
                if (stats.pageLoadTime) {
                    without_time = parseFloat(stats.pageLoadTime.without);
                    cloudflare_time = parseFloat(stats.pageLoadTime.cloudflare);
                    percent_time = Math.floor((1 - (cloudflare_time / without_time)) * 100) + '%';
                }
                //html += '</tr></td>';
                //html += '</table></p>';
                
                
                html += '<div id="analytics-stats">';
  
                //html += '<div class="analytics-speed-column analytics-right-rail">';
                html += '<div class="analytics-speed-column" id="analytics-speed-request"><h4 class="analytics-chartTitle"><span class="analytics-chartTitle-inner">Requests Saved <image src="../static/images/Info_16x16.png" width="13" height="13" class="info-icon" onclick="showHelp(\'hits\')"></span></h4> <table><tr><td> <div class="analytics-chart" id="analytics-speed-requs-chart"> <img src="https://chart.googleapis.com/chart?cht=p&chco=ed7200|505151&chs=80x80&chd=t:'+percent_reqs+','+(100.0 - percent_reqs)+'" width="80" height="80"> </div> </td><td> <div class="analytics-speed-savedByCF"><span id="analytics-speed-reqs-savedByCF">'+saved_reqs+'</span> requests saved by CloudFlare</div> <div class="analytics-speed-total"><span id="analytics-speed-reqs-total">'+total_reqs+'</span> total requests</div>  </td></tr></table></div>';
                
                html += '<div class="analytics-speed-column" id="analytics-speed-bandwidth"><h4 class="analytics-chartTitle"><span class="analytics-chartTitle-inner">Bandwidth Saved <image src="../static/images/Info_16x16.png" width="13" height="13" class="info-icon" onclick="showHelp(\'bandwidth\')"></span></h4> <table><tr><td> <div class="analytics-chart" id="analytics-speed-bandwidth-chart"> <img src="https://chart.googleapis.com/chart?cht=p&chco=ed7200|505151&chs=80x80&chd=t:'+percent_bw+','+(100.0 - percent_bw)+'" width="80" height="80"> </div> </td><td> <div class="analytics-speed-savedByCF"><span id="analytics-speed-bandwidth-savedByCF">'+saved_bw + saved_units_bw+'</span> bandwidth saved by CloudFlare</div> <div class="analytics-speed-total"><span id="analytics-speed-bandwidth-total">'+total_bw + total_units_bw + '</span> total bandwidth</div>  </td></tr></table> </div>';
                
                //html += '</div></div></div>';
                 
                html += '<p class="subtitle">Note: Basic statistics update every 24 hours. For 15 minute statistics updates, advanced security and faster performance, upgrade to a higher level of serivce. Contact your hosting provider for details.</p>';
                html += '</div>';
                
            } // END if (end < start)
            
		    html += '<div id="cf-settings">';
            html += '<A NAME="infobox"></A>';
            html += '<p><h4>Cloudflare Settings for ' + CURRENT_ZONE_NAME + '</h4></p>';
            html += '<p><table id="table_dns_zone" class="dynamic_table" border="0" cellspacing="0" cellpadding="0" width="1000">';
            
            var security    = stats.userSecuritySetting;
            var cachelvl    = stats.cache_lvl;
            var ip46lvl     = stats.ipv46;
            var dev_mode    = stats.dev_mode * 1000;
            var ob          = stats.ob;
            var server_time = stats.currentServerTime;
			var local_time  = new Date();
			var timeOffset  = local_time.getTimezoneOffset() * 60 * 1000;                    
            var accntType   = ((stats.pro_zone)? 'Paid': 'Free');

            html += '<tr>';
            html += 	'<td width="280">CloudFlare Account Type</td>';
            html += 	'<td>'+accntType+'</td><td>&nbsp;</td>';
            html +=     '<td style="text-align:center;"><image src="../static/images/Info_16x16.png" width="13" height="13" class="info-icon" onclick="showHelp(\'pro\')"></td></tr>';

            html += '<tr>';
            html += 	'<td width="280">CloudFlare security setting</td>';
            html += 	'<td><select name="SecurityLevelSetting" id="SecurityLevelSetting" onChange="change_cf_setting(\''
                + domain+'\', \'sec_lvl\', \'' + 'SecurityLevelSetting' + '\')">';
            html += '<option value="high"'+((security == "High")? 'selected': '')+'>High</option>'
            html += '<option value="med"'+((security == "Medium")? 'selected': '')+'>Medium</option>'
            html += '<option value="low"'+((security == "Low")? 'selected': '')+'>Low</option>'
            html += '<option value="help"'+((security == "I&#39;m under attack!")? 'selected': '')+'>I&#39;m under attack!</option>'
            html += '</select></td><td>&nbsp;</td>';
            html +=     '<td style="text-align:center;"><image src="../static/images/Info_16x16.png" width="13" height="13" class="info-icon" onclick="showHelp(\'seclvl\')"></td></tr>';
            
            html += '<tr>';
            if (dev_mode > server_time) {
                html += 	'<td width="280">Development Mode will end at</td><td>' 
                    + YAHOO.util.Date.format(new Date(dev_mode), {format: "%D %T"}) + 
                    '</td><td>Click <a href="javascript:void(0);" onclick="change_cf_setting(\''+domain+'\', \'devmode\', 0)">here</a> to disable</td>';
                html += '<td style="text-align:center;"><image src="../static/images/Info_16x16.png" width="13" height="13" class="info-icon" onclick="showHelp(\'devmode\')"></td>';
            } else {
                html += 	'<td width="280">Development Mode is currently</td><td>off'
                    + '</td><td>Click <a href="javascript:void(0);" onclick="change_cf_setting(\''+domain+'\', \'devmode\', 1)">here</a> to enable</td>';
                html +=     '<td style="text-align:center;"><image src="../static/images/Info_16x16.png" width="13" height="13" class="info-icon" onclick="showHelp(\'devmode\')"></td>';
            };
         
            html += '</tr>';

        html += '<tr>';
        html += 	'<td width="280">Cache Purge</td><td>&nbsp;'
                + '</td><td>Click <a href="javascript:void(0);" onclick="change_cf_setting(\''+domain+'\', \'fpurge_ts\', 1)">here</a> to purge</td>';
        html +=     '<td style="text-align:center;"><image src="../static/images/Info_16x16.png" width="13" height="13" class="info-icon" onclick="showHelp(\'fpurge_ts\')"></td>';
        html += '</tr>';
  
        html += '<tr>';
        html += 	'<td width="280">Always Online</td>';
        html += 	'<td><select name="AlwaysOnline" id="AlwaysOnline" onChange="change_cf_setting(\''
                + domain+'\', \'ob\', \'' + 'AlwaysOnline' + '\')">';
        html += '<option value="0"'+((ob == "0")? 'selected': '')+'>Off</option>'
        html += '<option value="1"'+((ob == "1")? 'selected': '')+'>On</option>'
        html += '</select></td><td>&nbsp;</td>';
        html +=     '<td style="text-align:center;"><image src="../static/images/Info_16x16.png" width="13" height="13" class="info-icon" onclick="showHelp(\'ob\')"></td></tr>';

        html += '<tr>';
        html += 	'<td width="280">Automatic IPv6</td>';
        html += 	'<td><select name="AutomaticIPv6" id="AutomaticIPv6" onChange="change_cf_setting(\''
                + domain+'\', \'ipv46\', \'' + 'AutomaticIPv6' + '\')">';
        html += '<option value="0"'+((ip46lvl == "0")? 'selected': '')+'>Off</option>'
        html += '<option value="3"'+((ip46lvl == "3")? 'selected': '')+'>Full</option>'
        html += '<option value="5"'+((ip46lvl == "5")? 'selected': '')+'>Safe</option>'
        html += '</select></td><td>&nbsp;</td>';
        html +=     '<td style="text-align:center;"><image src="../static/images/Info_16x16.png" width="13" height="13" class="info-icon" onclick="showHelp(\'ipv46\')"></td></tr>';
                    
        html += '<tr>';
        html += 	'<td width="280">CloudFlare caching level</td>';
        html += 	'<td><select name="CachingLevel" id="CachingLevel" onChange="change_cf_setting(\''
            + domain+'\', \'cache_lvl\', \'' + 'CachingLevel' + '\')">';
        html += '<option value="agg"'+((cachelvl == "agg")? 'selected': '')+'>Aggressive</option>'
        html += '<option value="basic"'+((cachelvl == "basic")? 'selected': '')+'>Basic</option>'
        html += '</select></td><td>&nbsp;</td>';
        html +=     '<td style="text-align:center;"><image src="../static/images/Info_16x16.png" width="13" height="13" class="info-icon" onclick="showHelp(\'cache_lvl\')"></td></tr>';
        html += '<tr>';
        
        html += '</table></p>';
        html += '<p class="subtitle">For more statistics and settings, sign into your account at <a href="https://www.cloudflare.com/analytics.html" target="_blank">CloudFlare</a>.</p>';
        
        DNS_HTML = $('#user_records_div').html();
        $('#user_records_div').html(html);
    }
    };
       
    var data =  {        
        a:           'stats',
        z:           CURRENT_ZONE_NAME,
        u:           USER_EMAIL,
        t:           USER_API_KEY
    };

    $.ajax({
        type:       'post',
        url:        CF_USER_API_ENDPOINT + "?callback=?",
        dataType:   'json',
        data:       data,
        success:    success,
	    error:      cf_api_error
    });

    return false;
}

var init_page = function() {

    // New signups
    var oUserSub = document.getElementById("USER_submit");
    YAHOO.util.Event.addListener(oUserSub, "click", signup_to_cf);

    // Subs
    var oActSub = document.getElementById("ZONE_lic_submit");
    YAHOO.util.Event.addListener(oActSub, "click", activate_licence);
    
    // change domain
    YAHOO.util.Event.on("domain", "change", toggle_domain);
    
    add_validation();
    
    // load the table
    if (YAHOO.util.Dom.get("domain").value != "_select_") {
        update_user_records_table();
    }
};

YAHOO.util.Event.onDOMReady(init_page);

//this style rule must be independent of external style sheets
(function() {
    var _stylesheet = [
        //other rules can be added to this array
        ['div.dt_module', 'display:none']
    ];
    var inserter;
    var first_stylesheet = document.styleSheets[0];
    if ('insertRule' in first_stylesheet) { //W3C DOM
        _stylesheet.forEach( function(rule) {
            first_stylesheet.insertRule( rule[0] + ' {'+rule[1]+'}', 0 );
        } );
    }
    else { //IE
        _stylesheet.forEach( function(rule) {
            first_stylesheet.addRule( rule[0], rule[1], 0 );
        } );
    }
})();
